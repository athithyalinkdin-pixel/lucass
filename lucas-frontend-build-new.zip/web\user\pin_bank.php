<?php include "include/header.php"?>
<?php include "include/navbar.php";

if($_GET['id']==0){
    $var='AND status=0';
    $head='Available Pins';
}
elseif($_GET['id']==1){

    $head='Used Pins';
    $var='AND status=1';
}
elseif($_GET['id']==10){

    $head='Total Pins';
    $var='';
}
?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title"><?php echo  $head?></h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th >Sl.No</th>
                                <th>Date</th>
								<th>Pins</th>
								<th>Amount</th>
								
								<th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
						
                        $res_pin=mysqli_query($con,"SELECT * FROM pin WHERE u_id='$user_id' $var ORDER BY pin_id DESC  ")or die("Query error");
                        $i=1 ;
                        while($row_pin=mysqli_fetch_array($res_pin))
                        {
                            if($row_pin['status']==0)
                            $st='<span class="badge bg-success">Available</span>';
                            else
                            $st='<span class="badge bg-danger">Used</span>'
                        ?>
                        <tr>
                        
                            <td><?php echo $i++; ?></td>
                            <td><?php echo $row_pin['pin_date'] ?></td>
                            <td><?php echo $row_pin['pin'] ?></td>
                            <td><?php echo $row_pin['amount'] ?></td>
                            <td><?php echo $st ?></td>
                            
                            
                        </tr>	
                        <?php
                        }
                        
                        ?>
                                                                    </tbody>
                            </table>

                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>