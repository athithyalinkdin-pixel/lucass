<?php
  function checkReward($user_id,$cnt){
	global $con;
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `tree1` WHERE `user_id`='$user_id'"));

		if($row['pair']>=$cnt){
			return true;
		}
		else return false;

  }



  function placement_id_free_reg($user_id,$s_id,$pos,$plan){
	global $con;
	$spons_data=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `tree$plan` WHERE `user_id`='$s_id'"))or die("SELECT placement_id Quuery error");
	if ($pos==1) {
	  if (empty($spons_data['1_place'])) {
		mysqli_query($con,"UPDATE `tree$plan` SET `1_place`='$user_id' WHERE `user_id`='$s_id'")or die("placement_id query 1 error");
		mysqli_query($con,"UPDATE `tree$plan` SET `placement_id`='$s_id'  WHERE `user_id`='$user_id'")or die("placement_id query 2 error") ;
		binary_count_inactive($user_id,$pos,$user_id,$plan);
	  } else {
		placement_id_free_reg($user_id,$spons_data['1_place'],$pos,$plan);
	  }
	}else {
	  if (empty($spons_data['2_place'])) {
		mysqli_query($con,"UPDATE `tree$plan` SET `2_place`='$user_id' WHERE `user_id`='$s_id'")or die("placement_id query 2 error");
		mysqli_query($con,"UPDATE `tree$plan` SET `placement_id`='$s_id'  WHERE `user_id`='$user_id'")or die("placement_id query 2 error") ;
		binary_count_inactive($user_id,$pos,$user_id,$plan);
	  } else {
		placement_id_free_reg($user_id,$spons_data['2_place'],$pos,$plan);
	  }
	}
  }

  function binary_count_inactive($spons,$pos,$user_id,$plan){ 
	global $con;
	if ($pos==1) {
	  $pos="1_count";
	} else {
	  $pos="2_count";
	}
	$spons=find_placement_id($spons,$plan);
	while (!empty($spons)) {
	 mysqli_query($con,"UPDATE `tree$plan` SET `$pos`=`$pos`+1 WHERE `user_id`='$spons'")or die("binary_count Qyert error");
	 mysqli_query($con,"INSERT INTO `binary_team`(`user_id`, `pos`, `tree_id`,`pack`) VALUES ('$spons','$pos','$user_id',$plan) ")or die('error2');
	$treeManager=treeManager($spons,1);
	   $pos=$treeManager['count'];
	  $next_id=find_placement_id($spons,$plan);
	  $spons=$next_id; 
	 
	}
  }

  function binary_count_for_topup($spons,$pos,$plan_amount){
	global $con;
	 
	if ($pos==1) {
	  $pos="1_count";
	  $biz='1_biz';
	  $carry='1_carry';
	
	} else {
	  $pos="2_count";
	  $biz='2_biz';
	  $carry='2_carry';
	} 

	$spons=find_placement_id($spons,1);
	while (!empty($spons)) {
		
	 mysqli_query($con,"UPDATE `tree1` SET `$carry`=`$carry`+$plan_amount,`$biz`=`$biz`+$plan_amount WHERE `user_id`='$spons'")or die("binary_count Qyert error");
		$treeManager=treeManager($spons,1);
	  $pos=$treeManager['count'];
	  $biz=$treeManager['biz'];
	  $carry=$treeManager['carry'];
	  $next_id=find_placement_id($spons,1);
	  $spons=$next_id;
	}
  }

  function binary_count_for_activation($spons,$pos,$plan_amount){
	global $con;
	 mysqli_query($con,"UPDATE `binary_team` SET `tree_status`=1 WHERE `user_id`='$spons' AND pack=1");
	if ($pos==1) {
	  $pos="1_count";
	  $biz='1_biz';
	  $carry='1_carry';
	 
	
	} else {
	  $pos="2_count";
	  $biz='2_biz';
	  $carry='2_carry';
	
	} 

	$spons=find_placement_id($spons,1);
	while (!empty($spons)) {
		
	 mysqli_query($con,"UPDATE `tree1` SET `$carry`=`$carry`+$plan_amount,`$biz`=`$biz`+$plan_amount WHERE `user_id`='$spons'")or die("binary_count Qyert error");
		$treeManager=treeManager($spons,1);
	  $pos=$treeManager['count'];
	  $biz=$treeManager['biz'];
	  $carry=$treeManager['carry'];
	  $next_id=find_placement_id($spons,1);
	  $spons=$next_id;
	}
  }

function referralCount($user_id){
                                global $con;
                                $cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM reg WHERE sponsor_id='$user_id'"));
                                return $cnt;
                            }
							
 function treeManager($user_id,$plan){
	global $con;
	$row=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `tree$plan` WHERE `user_id`='$user_id'"));
	$pos=$row['position'];
	if ($pos==1) {
		  $count="1_count";
		 $biz="1_biz";
	  $carry="1_carry";

	} else{
		 $count="2_count";
	$biz="2_biz";
	  $carry="2_carry";
	 
	}
	return [
        'count' => $count,
        'biz' => $biz,
        'carry' => $carry
    ];
  }



    function find_placement_id($s_id,$plan){
	global $con;
	$data1=mysqli_query($con,"SELECT * FROM `tree$plan` WHERE `user_id`='$s_id'")or die("find_placement_idQuyre error");
	$data=mysqli_fetch_assoc($data1);
  
	if(!empty($data['placement_id']))
	return $data['placement_id'];
  }



  function is_pair_generate($spons,$pos,$user_id,$amount1){
	global $con;
	global $date; 
	$amount=200;
	$type='pair_match_income';
	$comment='Binary Income';
	$compare_pos=($pos=="1_count")?"2_count":"1_count";
   
	$pla_data=mysqli_fetch_array(mysqli_query($con,"SELECT * FROM `tree` WHERE `user_id`='$spons'"));
  
	if($pla_data[$pos]!=0 && $pla_data[$compare_pos]!=0)
	$zero_check=1;
	else
	$zero_check=0;
  
	
	if($pla_data['1_count']>=$pla_data['2_count'])
	$dif=$pla_data['1_count']-$pla_data['2_count'];
	else
	$dif=$pla_data['2_count']-$pla_data['1_count'];

  
	if( $dif==1 && $zero_check==1){
		
			
				mysqli_query($con,"UPDATE `reg` SET `celing`=`celing`+1,`pair`=`pair`+1 WHERE  `user_id`='$spons'")or die("pair match income1 query error");
		
		
	}

	
  }



function level_team($user_id)
{
	global $con;
 
	mysqli_query($con,"INSERT INTO level(`user_id`) VALUES ('$user_id')")or die('insert error');
	
  $ref_id=find_sponsor_id($user_id);
  $s_id=find_sponsor_id($user_id);
  

  $a=0;
  $level=['level_1','level_2','level_3','level_4','level_5','level_6','level_7','level_8','level_9','level_10','level_11','level_12'];


    while ($a < 5 AND !empty($s_id)) {
    mysqli_query($con,"UPDATE level SET $level[$a]=$level[$a]+1 WHERE user_id='$s_id'")or die("level_distribution Query error");

	mysqli_query($con,"UPDATE reg SET  level_count=level_count+1 WHERE user_id='$s_id' ")or die("reg level  Query error1");

	down_insert($s_id,$user_id,0,$level[$a],$ref_id);

    $next_id=find_sponsor_id($s_id);
    $s_id=$next_id;
    $a++;
  }
	
}

function down_insert($s_id,$user_id,$plan_amount,$level,$ref_id)
{
	global $con;
	global $dt;

	
	mysqli_query($con,"INSERT INTO `down_line_insert`( `user_id`, `plan_amount`, `down_s_id`, `down_ref_id`, `down_level`) VALUES ('$user_id','$plan_amount','$s_id','$ref_id','$level')")or die("down_line_insert query error");
}




function checkDownlineInvestment($user_id,$amount){
	global $con;
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='$user_id'"));
	if($row['downline_investment']>=$amount)
	return true;
	else 
	return false;

  }

function checkUserId($user_id){ 
	global $con;
	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `reg` WHERE `user_id`='$user_id'"));
	if($cnt>=1)
	return true;
	else
	return false;
  }




function checkPurchaseWallet($user_id,$amount){
	global $con;
  $sql=mysqli_query($con,"SELECT * FROM reg WHERE user_id='$user_id'")or die('error');
	$row=mysqli_fetch_assoc($sql);

	if($row['purchase_wallet']>=$amount){
		mysqli_query($con,"UPDATE reg SET purchase_wallet=purchase_wallet-$amount WHERE user_id='$user_id'")or die('purchae wallet deduction error');
		return true;
	}
	else
	return false;
}

function check_pin($pin)
{
	global $con;
	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM pin WHERE pin='$pin' AND status=0"));
	if($cnt>=1)
	{
		mysqli_query($con,"UPDATE pin SET status=1 WHERE pin='$pin'")or die('pin update error');
		return true;
	}
	else
	return false;
}


function find_sponsor_id($user_id)
{
  global $con;
  $data1=mysqli_query($con,"SELECT * FROM `reg` WHERE `user_id`='$user_id'")or die("find_placement_idQuyre error");
  $data=mysqli_fetch_assoc($data1);
  if(!empty($data['sponsor_id']))
  return $data['sponsor_id'];
}
function ref_income($user_id,$amount){
	global $con;
	$s_id=find_sponsor_id($user_id);
	mysqli_query($con,"UPDATE reg SET  ref_income=ref_income+$amount , total_income=total_income+$amount , wallet=wallet+$amount WHERE user_id='$s_id' AND status=1")or die("ref Query error1");

	   $comment='Referrel income added ID OF : '.$user_id.' Amount OF '.$amount;
	    transaction_history($s_id,'credit','ref_income',$comment,$amount);
		
}



function find_user_name($user_id)
{
	global $con;
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='$user_id'"));
	if(!empty($row['name']))
	return $row['name'];
}


function cuttOff(){
	global $con;
$sql=mysqli_query($con,"SELECT * FROM tree1 WHERE 1_carry>0 AND 2_carry>0")or die('error');
while($row=mysqli_fetch_array($sql)){
  $left=$row['1_carry'];
  $right=$row['2_carry'];
  $user_id=$row['user_id']; 


  $amount=0;
 if($left>$right){
  $pair=$right;
  $carry=$left-$right;
  $pos='1_carry';
 }
 elseif($right>$left){ 
  $pair=$left;
  $carry=$right-$left;
  $pos='2_carry';
 }
 elseif($right==$left){
 $pair=$left;
  $carry=0; 
  $pos='1_carry'; 

 }
 

 echo '<br>Pair is '.$pair;

 echo '<br>Carry is '.$carry;
 echo '<br>Pos is '.$pos;
 
 $cutt_off_time=$row['cutt_off_time'];
 if($cutt_off_time==0)
	$income_percentage=25;
else if($cutt_off_time==1)
	$income_percentage=10;
else if($cutt_off_time==2)
	$income_percentage=7.5;
else if($cutt_off_time==3)
	$income_percentage=5;
else 
	$income_percentage=2.5;




  $amount=$pair*($income_percentage/100);

  if($amount>0){
    mysqli_query($con,"UPDATE reg SET total_income=total_income+$amount,wallet=wallet+$amount,binary_income=binary_income+$amount WHERE user_id='$user_id' ")or die("ref Query error1");

    $comment='Binary Income added   Income Percentage of '.$income_percentage. ' %';

      transaction_history($user_id,'credit','binary_income',$comment,$amount);
  } 

  mysqli_query($con,"UPDATE tree1 SET pair=pair+$pair,cutt_off_time=cutt_off_time+1 WHERE user_id='$user_id' ")or die("ref Query error1");
  mysqli_query($con,"UPDATE tree1 SET 1_carry=0,1_carry=0 WHERE user_id='$user_id'")or die('error 1');
  mysqli_query($con,"UPDATE `tree1` SET `$pos`=$carry WHERE `user_id`='$user_id'")or die('error 2');
}
}

function getFirtstProImage($pro_code){
	global $con;
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM pro_images WHERE `pro_code`='$pro_code'"));
	return !empty($row['pi_pic'])?$row['pi_pic']:'';
 }

function getProductDetails($pro_ai){
	global $con;
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM product WHERE pro_ai='$pro_ai'"));
	return $row;
} 

function success($msg){
	echo"<h1 style='text-align: center; color:green;'>Successfully ".$msg." <br> <button onclick='goBack()' style='background-color: #4CAF50; color: white; display: inline-block;  padding: 15px 32px; text-align: center;'>Go Back</button></h1>";
		echo "
				<script>
				function goBack() {
				  window.history.back();
				}

				</script>";
}

function fail($msg){
	echo"<h1 style='text-align: center; color:red;'>Error: ".$msg." .<br> <button onclick='goBack()' style='background-color: #4CAF50; color: white; display: inline-block;  padding: 15px 32px; text-align: center;'>Go Back</button></h1>";
		echo "
				<script>
				function goBack() {
				  window.history.back();
				}

				</script>";
}

function transaction_history($user_id,$transaction_type,$wallet_type,$comment,$passAmount){
	global $con,$strtime,$deduction;
	$amount=$passAmount-($passAmount*($deduction/100));
	$dedcuct=$passAmount-$amount;
	mysqli_query($con,"INSERT INTO `transaction_histroy`(`jdate`, `user_id`, `transaction_type`, `wallet_type`,`comment`, `deduction`, `amount`) VALUES ('$strtime','$user_id','$transaction_type','$wallet_type','$comment','$dedcuct','$amount')")or die("transcation_history Query erro");
}
 
function mail_label($to,$subject,$msg){
	
	
	$headers = 'From: service@'       .domain. "\r\n" .
             'Reply-To: servie@' .domain. "\r\n" .
             'X-Mailer: PHP/' . phpversion();

	mail($to, $subject, $msg, $headers);
}
function select_query($table,$where,$column,$result)
{
	global $con;
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM $table WHERE $where='$column' "));
	return $row[$result];
}
function img_validate($picture_type,$picture_size,$picture_tmp_name,$destination)
{
	if($picture_size<=50000000)
	{
		if($picture_type=="image/jpeg")
		{
			$img=imagecreatefromjpeg($picture_tmp_name);
		}
		elseif($picture_type=="image/png")
		{
			$img=imagecreatefrompng($picture_tmp_name);
		}
        elseif($picture_type=="image/jpg")
		{
			$img=$picture_tmp_name;
		}
		else{
			fail('Upload Image File Only');
			exit();
		}


		if(isset($img))
		{
			$op_img=time().rand(11,99).'.jpg';
			imagejpeg($img,$destination.$op_img,40);
		
			return $op_img;
		}
		else{
			fail('Upload Image File Only');
			exit();
		}
	}
	else{
		fail('Upload Below 1 MB');
		exit();
	}
}


function amountToWords($amount) {
	$words = '';
	$rupees = floor($amount);
	$paise = round(($amount - $rupees) * 100);
  
	if ($rupees > 0) {
	  $words .= convertToWords($rupees) . ' Rupees';
	}
  
	if ($paise > 0) {
	  $words .= ' and ' . convertToWords($paise) . ' Paise';
	}
  
	return $words;
  }
  
  function convertToWords($num) {
	$words = '';
	$ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
	$teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
	$tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
	$thousands = ['', 'Thousand', 'Lakh', 'Crore'];
  
	if ($num < 10) {
	  $words = $ones[$num];
	} elseif ($num < 20) {
	  $words = $teens[$num - 10];
	} elseif ($num < 100) {
	  $words = $tens[floor($num / 10)] . ' ' . $ones[$num % 10];
	} elseif ($num < 1000) {
	  $words = $ones[floor($num / 100)] . ' Hundred' . ($num % 100 > 0 ? ' and ' . convertToWords($num % 100) : '');
	} elseif ($num < 100000) {
	  $words = convertToWords(floor($num / 1000)) . ' ' . $thousands[1] . ($num % 1000 > 0 ? ' ' . convertToWords($num % 1000) : '');
	} elseif ($num < 10000000) {
	  $words = convertToWords(floor($num / 100000)) . ' ' . $thousands[2] . ($num % 100000 > 0 ? ' ' . convertToWords($num % 100000) : '');
	} else {
	  $words = convertToWords(floor($num / 10000000)) . ' ' . $thousands[3] . ($num % 10000000 > 0 ? ' ' . convertToWords($num % 10000000) : '');
	}
  
	return $words;
  }
?>