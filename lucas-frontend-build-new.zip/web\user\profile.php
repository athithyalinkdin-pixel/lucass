<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Update Profile</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"  enctype="multipart/form-data" >
                                            <input type="hidden" class="form-control" name="id" value="<?php echo$row['id']?>">
											<input type="hidden" class="form-control" name="unlink" value="../profile/<?php echo $row['profile_pic']?>">
							<div class="form-group">
							<label>User ID</label>
								<input type="text" class="form-control" value="<?php echo$row['user_id']?>" readonly >
							</div>
							<div class="form-group">
							<label>Join Date</label>
								<input type="text" class="form-control"   value="<?php echo  date('d-m-Y',$row['jdate'])?>" readonly>
							</div>
							<div class="form-group">
							<label>Name</label>
								<input type="text" class="form-control" value="<?php echo$row['name']?>" name="name" readonly>
							</div>
							<div class="form-group">
							<label>Mobile Number</label>
								<input type="text" class="form-control" value="<?php echo$row['mobile']?>" name="mobile" readonly>
							</div>
							
							<div class="form-group">
							<label>Full Address</label>
								<textarea name="address" class="form-control"><?php echo$row['address']?></textarea>
							</div>
							<div class="form-group">
							<label>City</label>
								<input type="text" class="form-control" name="city" value="<?php echo$row['city']?>" >
							</div><div class="form-group">
							<label>State</label>
								<input type="text" class="form-control" name="state" value="<?php echo$row['state']?>">
							</div>
							<div class="form-group">
							<label>Pin Code</label>
								<input type="text" class="form-control" name="pin_code" value="<?php echo$row['pin_code']?>">
							</div>
							<div class="form-group">
							<label>Mail ID</label>
								<input type="text" class="form-control" name="mail" value="<?php echo$row['mail']?>">
							</div>
							<div class="form-group">
							<label>Profile Update</label>
							<input type="file" class="form-control" name="pic" accept="image/*" onchange="loadFile(event)" >
								   <img id="output" src="../profile/<?php echo $row['profile_pic']?>" style="width:200px; height:200px" />
										<script>
										  var loadFile = function(event) {
											var output = document.getElementById('output');
											output.src = URL.createObjectURL(event.target.files[0]);
											output.onload = function() {
											  URL.revokeObjectURL(output.src) // free memory
											}
										  };
										</script>
							</div>
							 
					 <hr>
					 <div class="form-group text-center">
                     <button name="update_profile" class="btn btn-primary">Update</button>
					 </div>
                                               </form>
                                            
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>