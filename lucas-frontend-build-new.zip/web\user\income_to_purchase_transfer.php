<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle"> 
            <h1><?php echo $user_id?></h1> 
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2"> 
                    <div class="card-header">
                    <h5 class=" card-title">Main Wallet to Fund wallet Transfer</h5>
                    </div>
                                             
                                            <div class="card-body">

                                            <form action="action.php" method="post">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
                                               		
					<div class="form-group">
							<label> Wallet <?php echo currency?></label>
								<input type="text" class="form-control" name="wallet" value="<?php echo $row['wallet']?>" readonly>
							</div>
					 <div class="form-group">
							<label> Deduction 0%</label>
								<input type="text" class="form-control" name="tds" value="<?php echo $row['wallet']*(0/100)?>" readonly>
							</div>
					<div class="form-group">
							<label> Eligible <?php echo currency?></label>
								<input type="text" class="form-control" name="eligible_amount" value="<?php echo $row['wallet']-$row['wallet']*(0/100)?>" readonly>
							</div>
		
				
	
							 <hr>
					 <div class="form-group text-center">
                     <button name="wallet_to_purchase_transfer" class="btn btn-success">Transfer</button>
					 </div>  
                                               </form> 
                                               <script>
						$("#s_id").keyup(function(){
			
			var to_id=$('#s_id').val();
			var check_user_name='';
			 $.ajax({
				url : "action.php",
				type: "POST",
				chache :false,
				data:{check_user_name:check_user_name, to_id:to_id  },
				success:function(response){
		
					 $("#sponosr_name").val(response);
				}
			  });
			 
			});

				$("#user_id").keyup(function(){
			
					var to_id=$('#user_id').val();
					var check_user_name='';
					 $.ajax({
						url : "action.php",
						type: "POST",
						chache :false,
						data:{check_user_name:check_user_name, to_id:to_id  },
						success:function(response){
				
							 $("#to_name").val(response);
						}
					  });
					 
					});
					
				
					
						 $('#pin').change(function () {
							 var pin=$('#pin').val();
									var check_pin_value='';
								$.ajax({
										url : "action.php",
										type: "POST",
										chache :false,
										data:{check_pin_value:check_pin_value, pin:pin  },
										success:function(response){
											 document.getElementById("pin_value").value = response;
										
										}
									  }); 
						});
									
</script>
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>