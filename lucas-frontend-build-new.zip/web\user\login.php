<?php echo include "../db.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content="EVEverGreen"/>
  <meta name="author" content="EVEverGreen"/>
  <title><?php echo company_name?> :: login</title>
  <!--favicon-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="icon" href="../<?php echo fevi?>" type="image/x-icon">
  <!-- Bootstrap core CSS-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- animate CSS-->
  <link href="auth/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="auth/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Custom Style-->
  <link href="auth/style.css" rel="stylesheet"/>


<style>
			.wrapper-inline { 
  background: url(https://cdn.pixabay.com/photo/2020/12/23/14/41/forest-5855196_1280.jpg) no-repeat center center fixed; 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
 } 
			</style>
</head>

<body class="authentication-bg wrapper-inline">
 <!-- Start wrapper-->
 <div id="wrapper">
	<div class="card card-authentication1 mx-auto my-5 animated zoomIn">
		<div class="card-body">
		 <div class="card-content p-2">
		  <div class="text-center">
		 		<img src="../<?php echo logo?>" style="width:100px"/>
		 	</div>
		  <div class="card-title text-uppercase text-center py-2">Sign In</div>
		  				
		    <form action="action.php" method="post" name="loginform" id="loginform">
			  <div class="form-group m-2">
			   <div class="position-relative has-icon-left">
				  <label for="exampleInputUsername" class="sr-only">Username</label>
				  <input type="text" class="form-control" name="u_id" id="username" required placeholder="Username">
				  <div class="form-control-position">
					  <i class="fa fa-user-o" aria-hidden="true" ></i>
				  </div>
			   </div>
			  </div>
			  <div class="form-group m-2">
			   <div class="position-relative has-icon-left">
				  <label for="exampleInputPassword" class="sr-only">Password</label>
				  <input type="password" name="pass" id="password" required class="form-control" placeholder="Password">
				  <div class="form-control-position">
					  <i class="fa fa-lock "  aria-hidden="true" ></i>
				  </div>
			   </div>
			  </div>
			 <div class="form-row mr-0 ml-0">
			 <div class="form-group col-6">
			   <!-- <div class="demo-checkbox">
                <input type="checkbox" id="user-checkbox" class="filled-in chk-col-danger" checked="" />
                <label for="user-checkbox">Remember me</label>
			  </div> -->
			 </div>
			 <div class="form-group col-6 text-right m-2">
			  <a href="forgot_password.php">Reset Password</a>
			 </div>
			</div> 
			
			 <div class="form-group m-2">
 			   <input type="submit" name="login" id="submit" value="Sign In" class="btn btn-danger shadow-danger btn-block " />
			 </div>
			<!--  <div class="form-group text-center">
			   <p class="text-muted">Not a Member ? <a href="authentication-signup.html"> Sign Up here</a></p>
			 </div> -->
			 <div class="form-group text-center">
			    <hr>
				<h5>OR</h5>
			 </div>
			  <div class="form-group text-center">
				<a href="reg.php?id=NVV123123" class="btn btn-info shadow-info text-white btn-block waves-effect waves-light"><i class="fa fa-handshake-o"></i> Sign up for a New Account</a>
			  </div>
			 </form>
		   </div>
		  </div>
	     </div>
    
     <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	</div><!--wrapper-->
	
  <!-- Bootstrap core JavaScript-->
  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
  <script src="auth/"></script>

  <!-- waves effect js -->
  <script src="auth/waves.js"></script>
  <!-- Custom scripts -->
  <script src="https://evevergreen.com/earn/public/assets/js/app-script.js"></script>
	
</body>

</html>
