
<?php include "include/header.php" ?>

<div class="wrapper">

    <?php include "include/navbar.php" ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <?php
        if(!isset($_GET['id']))
        {
            $head='Total Users';
            $where='';
        }
        elseif($_GET['id']==1)
        {
            $head='Active Users';
            $where='WHERE status=1';
        }
        elseif($_GET['id']==2)
        {
            $head='Inactive Users';
            $where='WHERE status=0';
        }
        else
        {
            $head='Total Users';
            $where='';
        }
        ?>
       <section class="content-header">
            <h1><?php echo $head?>
                <small>advanced tables</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#"> <?php echo $head?></a></li>
                <li class="active"> <?php echo $head?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title" style="color:#FF0000;"><b><?php echo $head?></b></h3>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                             <table id="data_table" class="table table-bordered table-striped">  
                          <thead>  
                               <tr>  
                                   <th style="text-align:center;">S.No.</th>
                                        <th style="text-align:center;">User Id</th>
                                        <th style="text-align:center;">Name</th>
                                        <th style="text-align:center;">Mobile</th>
                                        <th style="text-align:center;">Join Date</th>
                                      
                                        <th style="text-align:center;">Sponsor Details </th>
                                   
                                      
                                        <th style="text-align:center;">Panel</th>
                                        <th style="text-align:center;">View</th>
                               </tr>  
                          </thead>  
                             <tbody>
									<?php  
					
				
							$res_pin=mysqli_query($con,"SELECT * FROM reg  $where ")or die("Query error");
							$i=1;
							while($row_pin=mysqli_fetch_array($res_pin))
							{
			
					$row_span=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$row_pin['sponsor_id']."'"))
					?>
						<tr>
							<td><?php echo $i++; ;?></td>
							<td><?php echo$row_pin['user_id'];?></td>
							<td><?php echo$row_pin['name'];?></td>
							<td><?php echo$row_pin['mobile'];?></td>
							<td><?php echo date("d-m-Y",($row_pin['jdate']));?></td>
                           
                          
                        
                            <td><?php echo !empty($row_span['user_id'])?$row_span['user_id'].' - '.$row_span['name']:'' ?></td>
                            <td>
                                <form action="../user/action.php" target="_blank"    method="post">
                                    <input type="hidden" name="u_id" value="<?= $row_pin['user_id'] ?>">
                                    <input type="hidden" name="pass" value="<?= $row_pin['password'] ?>">
                                    <button class="btn-danger btn" name="login">Goto Panel</button>
                                </form>
                            </td>
							<td>
                                <a href="view.php?id=<?php echo$row_pin['user_id'];?>" class="btn btn-primary">View</a>
                            </td>
						</tr>
						<?php
					}
							
						?>
                                </tbody>
                     </table> 
                        </div>
                        <!-- /.box-body -->
                    </div>
					 
		  
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php include "include/footer.php" ?>

