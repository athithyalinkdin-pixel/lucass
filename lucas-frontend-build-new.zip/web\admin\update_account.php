
<?php include "include/header.php" ?>

<div class="wrapper">

    <?php include "include/navbar.php" ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
           Update Company Account
            </h1>
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="manage_user.php">E-Pin</a></li>
                <li class="active">Message</li>
            </ol>
        </section>

      
        <script src="scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
   

        <!-- Main content -->
        <section class="content">
         
			<div class="row">
                <!-- left column -->
                <div class="col-md-8 col-xs-12" style="margin-left:10%;margin-right:10%;">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title success_msg">Company Account Update</h3>
                       </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                     
                        <form method="POST" action="action.php" enctype="multipart/form-data">
                    
                                <div class="box-body">

									<input type="hidden" class="form-control" name="unlink" value="../assets/<?php echo $row_admin['qr_code']?>">
                                   
										
										<div class="form-group">
                                            <label for="">Account No</label>
											<input type="text" class="form-control" value="<?php echo $row_admin['acc_no']?>" name="acc_no" >
										</div>
										<div class="form-group">
                                            <label for="">Account Name</label>
											<input type="text" class="form-control" value="<?php echo $row_admin['acc_name']?>" name="acc_name" >
										</div>
                                        <div class="form-group">
                                            <label for="">IFSC Code</label>
											<input type="text" class="form-control" value="<?php echo $row_admin['ifsc']?>" name="ifsc" >
										</div>
                                        <div class="form-group">
                                            <label for="">Bank </label>
											<input type="text" class="form-control" value="<?php echo $row_admin['bank']?>" name="bank" >
										</div>
                                        <div class="form-group">
                                            <label for="">Branch</label>
											<input type="text" class="form-control"  value="<?php echo $row_admin['branch']?>"name="branch" >
										</div>
                                        <div class="form-group">
                                            <label for="">Google Pay</label>
											<input type="text" class="form-control" value="<?php echo $row_admin['gpay']?>"   name="gpay" >
										</div>
                                        <div class="form-group">
                                            <label for="">Phone Pe</label>
											<input type="text" class="form-control" value="<?php echo $row_admin['phone_pe']?>" name="phone_pe" >
										</div>
                                        <div class="form-group">
                                            <label for="">UPI ID</label>
											<input type="text" class="form-control" value="<?php echo $row_admin['upi_id']?>" name="upi_id" >
										</div>
                                        <div class="form-group">
                                            <label for="">Qr Code</label>
											<input type="file" class="form-control" name="pic" accept="image/*" onchange="loadFile(event)" >
								   <img id="output" src="../assets/<?php echo $row_admin['qr_code']?>" style="width:200px; height:200px" />
										<script>
										  var loadFile = function(event) {
											var output = document.getElementById('output');
											output.src = URL.createObjectURL(event.target.files[0]);
											output.onload = function() {
											  URL.revokeObjectURL(output.src) // free memory
											}
										  };
										</script>
										</div>
										
					
                                </div>
                                <div class="box-footer text-center">
                                <div class="form-group">
											<button name="update_account" class="btn btn-success">Update</button>
										</div>
									
                                </div>
                                </form>
                    </div>
                    <!-- /.box -->

                </div>

            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include "include/footer.php" ?>
