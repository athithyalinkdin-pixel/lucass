<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle"> 
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Dirstributor Activate</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post">
                                               <input type="hidden" name="activator_id" value="<?php echo $user_id?>"  >
                                               		
					<div class="form-group">
							<label>Purchase Wallet <a href="pin_request.php">Purchase Wallet</a></label>
								<input type="text" class="form-control" name="purchase_wallet" value="<?php echo $row['purchase_wallet']?>" readonly>
							</div>
					 
					 <div class="form-group">
					 <label>Distribute ID</label>
						<input type="text" class="form-control" id="user_id" name="user_id" required>
					 </div>	
					 
					 <div class="form-group">
					 <label> Name</label>
						<input type="text" class="form-control" id="to_name"  readonly required>
					 </div>	
				
			   <div class="form-group">
					 <label>Plan Amount</label>
						<input type="text" class="form-control" name="plan_amount" value="<?= $planAmount[1] ?>" required readonly>
					 </div>
					
						<!-- <div class="form-group">
							<label>SELECT Pin <a href="pin_request.php">Purchase Pin</a></label>
								<select name="pin" id="pin" class="form-control"   required>
									<option value="">--SELECT PIN--</option>
									<?php
									$res_pin=mysqli_query($con,"SELECT * FROM pin WHERE u_id='".$user_id."' AND status=0 ")or die("Query error");
									
									while($row_pin=mysqli_fetch_array($res_pin))
									{
									?>
									<option value="<?php echo $row_pin['pin'] ?>"><?php echo $row_pin['pin'] ?></option>
									<?php
									}
									?>
								</select>
							</div>
							<div class="form-group">
							<label>E-Pin Value</label>
								<input type="text" class="form-control" name="plan_amount" id="pin_value" readonly>
							</div> -->
                     
                       
					 <hr>
					 <div class="form-group text-center">
                     <button name="top_up_submit" class="btn btn-success">Activate</button>
					 </div>
                                               </form> 
                                               <script>
						$("#s_id").keyup(function(){
			
			var to_id=$('#s_id').val();
			var check_user_name='';
			 $.ajax({
				url : "action.php",
				type: "POST",
				chache :false,
				data:{check_user_name:check_user_name, to_id:to_id  },
				success:function(response){
					var data=JSON.parse(response);
		
					 $("#sponosr_name").val(data.name);
				}
			  });
			 
			});

				$("#user_id").keyup(function(){
			
					var to_id=$('#user_id').val();
					var check_user_name='';
					 $.ajax({
						url : "action.php",
						type: "POST",
						chache :false,
						data:{check_user_name:check_user_name, to_id:to_id  },
						success:function(response){
				
							var data=JSON.parse(response);
		
					 $("#to_name").val(data.name);
						}
					  });
					 
					});
					
				
					
						 $('#pin').change(function () {
							 var pin=$('#pin').val();
									var check_pin_value='';
								$.ajax({
										url : "action.php",
										type: "POST",
										chache :false,
										data:{check_pin_value:check_pin_value, pin:pin  },
										success:function(response){
											 document.getElementById("pin_value").value = response;
										
										}
									  }); 
						});
									
</script>
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>