<?php include "include/header.php"?>
<?php include "include/navbar.php"?>

<!-- Add this in your header section for Font Awesome if not already included -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<!-- Add Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
:root {
    --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --success-gradient: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);
    --warning-gradient: linear-gradient(135deg, #fad0c4 0%, #ff9a9e 100%);
    --info-gradient: linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%);
    --danger-gradient: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
}

* {
    font-family: 'Poppins', sans-serif;
}

/* News Ticker Styles */
.news-ticker {
    background: linear-gradient(45deg, #FF6B6B, #4ECDC4, #45B7D1, #96C93D);
    background-size: 300% 300%;
    animation: gradientMove 8s ease infinite;
    border-radius: 10px;
    padding: 5px 0;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.news-ticker marquee {
    color: white;
    padding: 8px;
    font-weight: 600;
    font-size: 16px;
    letter-spacing: 1px;
}

/* Dashboard Cards */
.dashboard-card {
    background: white;
    border-radius: 20px;
    padding: 25px 20px;
    margin-bottom: 25px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    border: none;
    position: relative;
    overflow: hidden;
}

.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.1);
}

.dashboard-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: var(--primary-gradient);
}

.card-income::before { background: linear-gradient(90deg, #FF8008, #FFC837); }
.card-wallet::before { background: linear-gradient(90deg, #00B09B, #96C93D); }
.card-binary::before { background: linear-gradient(90deg, #FF416C, #FF4B2B); }
.card-purchase::before { background: linear-gradient(90deg, #4776E6, #8E54E9); }

.card-icon {
    width: 60px;
    height: 60px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    color: white;
    background: var(--primary-gradient);
}

.card-income .card-icon { background: linear-gradient(135deg, #FF8008, #FFC837); }
.card-wallet .card-icon { background: linear-gradient(135deg, #00B09B, #96C93D); }
.card-binary .card-icon { background: linear-gradient(135deg, #FF416C, #FF4B2B); }
.card-purchase .card-icon { background: linear-gradient(135deg, #4776E6, #8E54E9); }

.card-value {
    font-size: 32px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 5px;
}

.card-label {
    font-size: 14px;
    color: #7f8c8d;
    font-weight: 500;
}

/* Profile Card */
.profile-card {
    background: white;
    border-radius: 20px;
    padding: 30px 20px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
}

.profile-image {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    border: 5px solid #fff;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    margin-bottom: 15px;
}

.profile-name {
    font-size: 24px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 5px;
}

.profile-id {
    font-size: 14px;
    color: #7f8c8d;
    background: #f8f9fa;
    padding: 5px 15px;
    border-radius: 20px;
    display: inline-block;
    margin-bottom: 15px;
}

/* Group Cards */
.group-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
}

.group-header {
    padding: 15px 20px;
    color: white;
    font-weight: 600;
    font-size: 18px;
}

.group-left .group-header { background: linear-gradient(135deg, #FF416C, #FF4B2B); }
.group-right .group-header { background: linear-gradient(135deg, #00B09B, #96C93D); }

.group-body {
    padding: 20px;
}

.group-table {
    width: 100%;
}

.group-table tr {
    border-bottom: 1px solid #ecf0f1;
}

.group-table tr:last-child {
    border-bottom: none;
}

.group-table th {
    text-align: left;
    padding: 12px 0;
    color: #7f8c8d;
    font-weight: 500;
    font-size: 14px;
}

.group-table td {
    text-align: right;
    padding: 12px 0;
    color: #2c3e50;
    font-weight: 600;
}

/* Awards Table */
.awards-card {
    background: white;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
}

.awards-table {
    width: 100%;
    border-collapse: collapse;
}

.awards-table th {
    background: #f8f9fa;
    padding: 12px;
    font-weight: 600;
    color: #2c3e50;
    font-size: 14px;
}

.awards-table td {
    padding: 12px;
    border-bottom: 1px solid #ecf0f1;
    color: #2c3e50;
    font-size: 14px;
}

.awards-table tr:hover {
    background: #f8f9fa;
}

.eligible-badge {
    background: #2ecc71;
    color: white;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
}

.not-eligible-badge {
    background: #e74c3c;
    color: white;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
}

/* Referral Links */
.referral-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
}

.referral-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 15px 20px;
    font-weight: 600;
    font-size: 18px;
}

.referral-body {
    padding: 20px;
}

.referral-input {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #ecf0f1;
    border-radius: 10px;
    font-size: 14px;
    color: #2c3e50;
    margin-bottom: 15px;
    transition: all 0.3s ease;
      border-color: #667eea;
}

.referral-input:focus {
    border-color: #667eea;
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.copy-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 12px 30px;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 100%;
    font-size: 16px;
}

.copy-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

/* KYC Status */
.kyc-verified {
    background: linear-gradient(135deg, #2ecc71, #27ae60);
    color: white;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    display: inline-block;
}

.kyc-unverified {
    background: linear-gradient(135deg, #e74c3c, #c0392b);
    color: white;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    display: inline-block;
}

/* Responsive */
@media (max-width: 768px) {
    .dashboard-card {
        margin-bottom: 15px;
    }
    
    .card-value {
        font-size: 24px;
    }
    
    .profile-image {
        width: 120px;
        height: 120px;
    }
}
</style>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <!-- News Ticker -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="news-ticker">
                    <marquee behavior="scroll" direction="left" scrollamount="5">
                        <?php echo $row_admin['news']; ?>
                    </marquee>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row g-4">
            <div class="col-xxl-3 col-md-6">
                <div class="dashboard-card card-income">
                    <div class="d-flex align-items-center">
                        <div class="card-icon me-3">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <div>
                            <div class="card-value"><?php echo number_format($row['total_income'], 2); ?></div>
                            <div class="card-label">Total Income</div>
                            <small class="text-muted"><?php echo currency; ?></small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-3 col-md-6">
                <div class="dashboard-card card-wallet">
                    <div class="d-flex align-items-center">
                        <div class="card-icon me-3">
                            <i class="fas fa-credit-card"></i>
                        </div>
                        <div>
                            <div class="card-value"><?php echo number_format($row['wallet'], 2); ?></div>
                            <div class="card-label">Wallet Balance</div>
                            <small class="text-muted"><?php echo currency; ?></small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-3 col-md-6">
                <div class="dashboard-card card-binary">
                    <div class="d-flex align-items-center">
                        <div class="card-icon me-3">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div>
                            <div class="card-value"><?php echo number_format($row['binary_income'], 2); ?></div>
                            <div class="card-label">Binary Income</div>
                            <small class="text-muted"><?php echo currency; ?></small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-3 col-md-6">
                <div class="dashboard-card card-purchase">
                    <div class="d-flex align-items-center">
                        <div class="card-icon me-3">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div>
                            <div class="card-value"><?php echo number_format($row['purchase_wallet'], 2); ?></div>
                            <div class="card-label">Purchase Wallet</div>
                            <small class="text-muted"><?php echo currency; ?></small>
                        </div>
                    </div>
                </div>
            </div>

          
        </div>

        <!-- Profile and Groups Section -->
        <div class="row mt-4 g-4">
            <!-- Profile Card -->
            <div class="col-xxl-4 col-md-4 card" >
                <div class="profile-card" style="background-color: #9ce7bc;">
                    <img src="<?php echo !empty($row['profile_pic']) ? '../profile/'.$row['profile_pic'] : 'https://png.pngtree.com/png-vector/20230928/ourmid/pngtree-young-indian-man-png-image_10149659.png'; ?>" 
                         alt="Profile" class="profile-image">
                    <h3 class="profile-name"><?php echo $row['name']; ?></h3>
                    <span class="profile-id">ID: <?php echo $row['user_id']; ?></span>
                    
                    <div class="mt-3">
                        <table class="group-table">
                            <tr>
                                <th>Join Date</th>
                                <td><?php echo date('d-m-Y', $row['jdate']); ?></td>
                            </tr>
                            <tr>
                                <th>Activate Date</th>
                                <td><?php echo date('d-m-Y', $row['activate_date']); ?></td>
                            </tr>
                            <tr>
                                <th>Investment</th>
                                <td><?php echo ($row['plan_amount']); ?></td>
                            </tr>
                            
                        </table>
                    </div>
                </div>
            </div>

            <!-- Left Group -->
            <div class="col-xxl-4 col-md-4">
                <div class="group-card group-left" >
                    <div class="group-header">
                        <i class="fas fa-users me-2"></i> Left Group
                    </div>
                    <div class="group-body">
                        <table class="group-table">
                            <tr>
                                <th>Total Team</th>
                                <td><?php echo mysqli_num_rows(mysqli_query($con, "SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=1")); ?></td>
                            </tr>
                            <tr>
                                <th>Active Team</th>
                                <td><?php echo mysqli_num_rows(mysqli_query($con, "SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=1 AND reg.plan_amount!=0")); ?></td>
                            </tr>
                            <tr>
                                <th>Inactive Team</th>
                                <td><?php echo mysqli_num_rows(mysqli_query($con, "SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=1 AND reg.plan_amount=0")); ?></td>
                            </tr>
                            <tr>
                                <th>Carry Forward</th>
                                <td><?php echo number_format($row_tree['1_carry']); ?></td>
                            </tr>
                            <tr>
                                <th>Total Business</th>
                                <td><?php 
                                    $left_biz = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(reg.plan_amount) AS left_tot FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=1")); 
                                    echo number_format($left_biz['left_tot']) . ' ' . currency;
                                ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Right Group -->
            <div class="col-xxl-4 col-md-4">
                <div class="group-card group-right">
                    <div class="group-header">
                        <i class="fas fa-users me-2"></i> Right Group
                    </div>
                    <div class="group-body">
                        <table class="group-table">
                            <tr>
                                <th>Total Team</th>
                                <td><?php echo mysqli_num_rows(mysqli_query($con, "SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=2")); ?></td>
                            </tr>
                            <tr>
                                <th>Active Team</th>
                                <td><?php echo mysqli_num_rows(mysqli_query($con, "SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=2 AND reg.plan_amount!=0")); ?></td>
                            </tr>
                            <tr>
                                <th>Inactive Team</th>
                                <td><?php echo mysqli_num_rows(mysqli_query($con, "SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=2 AND reg.plan_amount=0")); ?></td>
                            </tr>
                            <tr>
                                <th>Carry Forward</th>
                                <td><?php echo number_format($row_tree['2_carry']); ?></td>
                            </tr>
                            <tr>
                                <th>Total Business</th>
                                <td><?php 
                                    $right_biz = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(reg.plan_amount) AS right_tot FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$user_id' AND binary_team.pos=2")); 
                                    echo number_format($right_biz['right_tot']) . ' ' . currency;
                                ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Referral Links Section -->
        <div class="row mt-4 g-4">
            <div class="col-md-6">
                <div class="referral-card">
                    <div class="referral-header">
                        <i class="fas fa-link me-2"></i> Left Referral Link
                    </div>
                    <div class="referral-body">
                        <input type="text" class="referral-input" id="leftLink" value="<?php echo url; ?>/user/reg.php?id=<?php echo $user_id; ?>&pos=LEFT" readonly>
                        <p id="p1" style="display:none"><?php echo url; ?>/web/user/reg.php?id=<?php echo $user_id; ?>&pos=LEFT</p>
                        <button class="copy-btn" onclick="copyToClipboard('#p1', 'Left')">
                            <i class="fas fa-copy me-2"></i>Copy Left Link
                        </button>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="referral-card">
                    <div class="referral-header">
                        <i class="fas fa-link me-2"></i> Right Referral Link
                    </div>
                    <div class="referral-body">
                        <input type="text" class="referral-input" id="rightLink" value="<?php echo url; ?>/user/reg.php?id=<?php echo $user_id; ?>&pos=RIGHT" readonly>
                        <p id="p2" style="display:none"><?php echo url; ?>/web/user/reg.php?id=<?php echo $user_id; ?>&pos=RIGHT</p>
                        <button class="copy-btn" onclick="copyToClipboard('#p2', 'Right')">
                            <i class="fas fa-copy me-2"></i>Copy Right Link
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function copyToClipboard(element, side) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    
    // Show modern toast notification
    showNotification(side + ' referral link copied to clipboard!', 'success');
    
    $temp.remove();
}

function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
        ${message}
    `;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#2ecc71' : '#3498db'};
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 9999;
        font-weight: 500;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add animation keyframes
const style = document.createElement('style');
style.innerHTML = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
</script>

<?php include "include/footer.php"?>