<?php include "include/header.php"?>
<?php include "include/navbar.php";

?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header"> 
                    <h5 class=" card-title">Referral Team</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th>SL.No</th>
					<th>ID</th>
					<th>Name</th>
					<th>Mobile</th>
					<th>Investment</th>
					
					
					<th>Join Date</th>
					<th>Status</th>
					<th>View</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
				
                $s_id=isset($_GET['id'])?$_GET['id']:$user_id;
    
                        $res=mysqli_query($con,"SELECT * FROM reg WHERE sponsor_id='$s_id'");
                        $i=0;
                        
                        while($row=mysqli_fetch_array($res))
                        {
                            $i++;
                            if($row['status']==1)
                                    $st='Activated';
                                elseif($row['status']==2)
                                $st='InActivated';
                    ?>
                    <tr>
                        <td><?php echo$i;?></td>
                        <td><?php echo$row['user_id'];?></td>
                        <td><?php echo$row['name'];?></td>
                        <td><?php echo$row['mobile'];?></td>
                        <td><?php echo$row['plan_amount'];?></td>
                
                        
                        <td><?php echo date('d-m-Y',$row['jdate']);?></td>
                        <td><?php echo$st;?></td>
                        <td><a href="referral_team.php?id=<?php echo$row['user_id'];?>" class="btn btn-primary">View</a></td>
                    </tr>
                    <?php
                        }
                        
                    ?>
                                                                    </tbody>
                            </table>

                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>