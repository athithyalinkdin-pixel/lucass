<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Depoist</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"  enctype="multipart/form-data">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
                                               <div class="form-group">
							<label>My ID</label>
								<input type="text" class="form-control" value="<?php echo $user_id?>" readonly>
							</div>
							<div class="form-group">
							<label>name</label>
								<input type="text" class="form-control" name="name" value="<?php echo $row['name']?>" readonly>
							</div>
							<div class="form-group">
							<label>Transaction ID / Ref ID</label>
								<input type="text" class="form-control" name="ref_id" placeholder="Transaction ID / Ref ID" required>
							</div>
							<div class="form-group">
							<label>Proof Image</label>
								<input type="file" class="form-control" name="pic"  required>
							</div>
							<div class="form-group">
							<label>Amount</label>
								<input type="number" class="form-control" name="amount"  required>
							</div>
						
                      
					 <hr>
					 <div class="card-footer text-center">
                     <button name="deposit_amount" class="btn btn-primary btn-lg">Submit</button>
					 </div> 
                                               </form>
                                                </div>
                </div>


            </div>

            <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Company Account Details</h5>
                    </div>
                                            
                                            <div class="card-body">

                                           <?php if(!empty($row_admin['qr_code'])) {?>
                                               <div class="form-group">
							<label>QR Code</label><br>
                            <img  src="../assets/<?php echo $row_admin['qr_code']?>" style="width:200px; height:200px" class="img-thumbnail" />
							</div>
                            <?php 
                                           }
                            ?>

                             <?php if(!empty($row_admin['acc_no'])) {?>
                                               <div class="form-group">
							<label>Account Number</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['acc_no']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                             <?php if(!empty($row_admin['acc_name'])) {?>
                                               <div class="form-group">
							<label>Account Name</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['acc_name']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                             <?php if(!empty($row_admin['ifsc'])) {?>
                                               <div class="form-group">
							<label>IFSC Code</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['ifsc']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                             <?php if(!empty($row_admin['bank'])) {?>
                                               <div class="form-group">
							<label>Bank</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['bank']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                             <?php if(!empty($row_admin['branch'])) {?>
                                               <div class="form-group">
							<label>Branch</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['branch']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                             <?php if(!empty($row_admin['gpay'])) {?>
                                               <div class="form-group">
							<label>Google Pay</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['gpay']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                            <?php if(!empty($row_admin['phone_pe'])) {?>
                                               <div class="form-group">
							<label>Phone Pe</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['phone_pe']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
                            <?php if(!empty($row_admin['upi_id'])) {?>
                                               <div class="form-group">
							<label>UPI ID</label>
                            <input type="text" class="form-control" value="<?php echo $row_admin['upi_id']?>" readonly>
							</div>
                            <?php 
                                           }
                            ?>
							

							
				
					
                                               </form>
                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>