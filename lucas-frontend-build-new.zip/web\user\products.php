<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
            <?php 
            $sql_pro=mysqli_query($con,"SELECT * FROM product "); 
            while($row_pro=mysqli_fetch_array($sql_pro)){
            ?>
            <div class="col-xs-12 col-md-4">
                <div class="card text-center shadow">
                    <div class="card-header">
                        <h3><?= $row_pro['pro_name'] ?></h3>
                       
                    </div>
                    <div class="card-body">
                         <img src="../product_image/<?= getFirtstProImage($row_pro['pro_code'])?>" class="img-thumbnail" style="width:300px;height:400px" alt="" srcset="">
                    </div>
                    <div class="card-footer">
                        <a href="activate.php?id=<?= $row_pro['pro_ai'] ?>&&amount=<?= $row_pro['price'] ?>" class="btn btn-success btn-sm">Purchase</a>
                    </div>
                </div>
            </div>
            <?php }?>

    
            </div> 

        </section>
 
    </main><!-- End #main -->
    <?php include "include/footer.php"?>