<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Change Password</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"   onsubmit="return matchpass()" name="f1" >
					<input type="hidden" class="form-control" name="id" value="<?php echo$row['id']?>">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
                                               <div class="form-group">
                                    <label for="exampleInputEmail1">Current Password</label>
                                   <input type="password" name="old_pass"  class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label>New Password</label>
                                   <input type="password" name="npwd" id="npwd" class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label>Confirm Password</label>
                                   <input type="password" name="cpwd" id="cpwd"  class="form-control" required>
                                </div>
                    
                      
					 <hr>
					 <div class="form-group text-center">
                     <button class="btn btn-primary" name="change_pass">Change Passowrd</button>
					 </div>
                                               </form>
                                               <script type="text/javascript">  
				function matchpass(){  
				var firstpassword=document.f1.npwd.value;  
				var secondpassword=document.f1.cpwd.value;  
				  
				if(firstpassword==secondpassword){  
				return true;  
				}  
				else{  
				alert("password must be same!");  
				return false;  
				}  
				}  
				</script>  
                                            
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>