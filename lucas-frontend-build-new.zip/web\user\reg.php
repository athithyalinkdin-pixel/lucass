<?php echo include "../db.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content="EVEverGreen"/>
  <title><?php echo company_name?> :: login</title>
  <!--favicon-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="icon" href="../<?php echo fevi?>" type="image/x-icon">
  <!-- Bootstrap core CSS-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
  <!-- animate CSS-->
  <link href="auth/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="auth/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Custom Style-->
  <link href="auth/style.css" rel="stylesheet"/>


<style>
			.wrapper-inline { 
  background: url(https://cdn.pixabay.com/photo/2020/12/23/14/41/forest-5855196_1280.jpg) no-repeat center center fixed; 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;
 } 
			</style>
</head>

<body class="authentication-bg wrapper-inline">
 <!-- Start wrapper-->
 <div id="wrapper">
	<div class="card card-authentication1 mx-auto my-5 animated zoomIn">
		<div class="card-body">
		 <div class="card-content p-2">
		  <div class="text-center">
		 		<img src="../<?php echo logo?>" style="width:100px"/>
		 	</div>
		  <div class="card-title text-uppercase text-center py-2">Sign In</div>
		  				
		  <form action='action.php' class="register-form"  method='post' name="f1">
     <input type="hidden" name="pos" value="<?php echo $_GET['pos']=='LEFT'?1:2;?>">
              <div class="form-group m-2">
                <label class="control-label">Sponsor ID *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#673ab7; color:#FFFFFF;height:38px" class="input-group-text">
                      <i class="fa fa-user-circle">
                      </i>
                    </span>
                  </div>
                  <input type="text" name="s_id" class="form-control" id="s_id"  required value="<?php echo isset($_GET['id'])?$_GET['id']:'' ;?>"   />
                </div>
              </div>
              <div class="form-group m-2">
                <label class="control-label">Sponsor Name *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#9c27b0; color:#FFFFFF;height:38px" class="input-group-text">
                      <i class="fa fa-address-book">
                      </i>
                    </span>
                  </div>
                  <input  type="text" class="form-control"  id="to_name" readonly />	
                </div>
              </div>		
              <div class="form-group m-2">
                <label class="control-label">Position *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#9c27b0; color:#FFFFFF;height:38px" class="input-group-text">
                      <i class="fa fa-sitemap">
                      </i>
                    </span>
                  </div>

                  <?php if(isset($_GET['pos'])){?>
                  <input  type="text" class="form-control"  value="<?php echo $_GET['pos']?>" readonly />	
                  <?php }
                  else{
                    echo '<select class="form-control" name="pos">
<option value="">--SELECT--</option>
<option value="1">LEFT</option>
<option value="2">RIGHT</option>
                    </select>';
                  }
                  ?>
                </div>
              </div>
	 
              <div class="form-group m-2">
                <label class="control-label">Your Name *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#2196f3; color:#FFFFFF;height:38px" class="input-group-text">
                      <i class="fa fa-user">
                      </i>
                    </span>
                  </div>
                  <input type="text"  class="form-control" required name="name" id="firstname" />
                </div>
              </div>
         
        
              <div class="form-group m-2">
                <label class="control-label">Mobile *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#ff9800; color:#FFFFFF;height:38px" class="input-group-text">
                      <i class="fa fa-phone">
                      </i>
                    </span>
                  </div>
                  <input type="text"  class="form-control" name="mobile" required id="mobile" maxlength="10" required/>
                </div>
              </div>

              <div class="form-group m-2">
                <label class="control-label">e-Mail
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#f44336; color:#FFFFFF;height:38px" class="input-group-text">
                      <i class="fa fa-envelope">
                      </i>
                    </span>
                  </div>
                  <input type="text"  class="form-control" name="mail" id="email" required />
                </div>
              </div>
 
              <div class="form-group m-2">
                <label class="control-label">Password *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#795548 ; color:#FFFFFF; height:38px" minlength="6" class="input-group-text">
                      <i class="fa fa-lock">
                      </i>
                    </span>
                  </div>
                  <input type="password" required class="form-control" name="password" />
                </div>
              </div>
              <!-- <div class="form-group m-2">
                <label class="control-label">Confirm Password *
                </label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span style="background-color:#d82436; color:#FFFFFF; height:38px"  minlength="6" class="input-group-text">
                      <i class="fa fa-lock">
                      </i> 
                    </span>
                  </div>
                  <input type="password" required class="form-control" name="confirmpassword" id="confirmpassword"/>
                </div>
              </div> -->
   
              <div class="form-group m-2"> 
              
       
              <button class="btn btn-info btn-block" name="register_from_website">Submit</button>
                
              </div>
              <hr/>
              <div class="form-group m-2">
                <div class="row">
                  <div class="col-md-6" align="center">  
                    <a href="login.php"  class="btn btn-success btn-round btn-sm"> 
                      <i class="fa fa-lock">
                      </i> Go To Login
                    </a>
                  </div>
                  <div class="col-md-6"  align="center"> 
                    <a href="../../" class="btn btn-warning btn-round btn-sm" > 
                      <i class="fa fa-home">
                      </i> Back to Home
                    </a>
                  </div>
                </div>
              </div>					 
            </form>
		   </div>
		  </div>
	     </div>
    <script>

$("#s_id").keyup(function(){
			
      var to_id=$('#s_id').val();
        check_name(to_id);
       
      });
      
      $( document ).ready(function() {
                  
        var to_id=$('#s_id').val();
        check_name(to_id);
        });

      function check_name(to_id)
      {
        var check_user_name='';
       $.ajax({
        url : "action.php",
        type: "POST",
        chache :false,
        data:{check_user_name:check_user_name, to_id:to_id  },
        success:function(response){
      var data=JSON.parse(response);
           $("#to_name").val(data.name);
        }
        });
      }

 
    //  function matchpass(){  
		// 		var firstpassword=document.f1.password.value;  
		// 		var secondpassword=document.f1.confirmpassword.value;  
				  
		// 		if(firstpassword==secondpassword){  
		// 		return true;  
		// 		}  
		// 		else{  
		// 		alert("password must be same!");  
		// 		return false;  
		// 		}  
		// 		}  
    </script>
     <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	</div><!--wrapper-->
	
  <!-- Bootstrap core JavaScript-->
  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
  <script src="auth/"></script>

  <!-- waves effect js -->
  <script src="auth/waves.js"></script>
  <!-- Custom scripts -->
  <script src="auth/app-script.js"></script>
	
</body>

</html>
