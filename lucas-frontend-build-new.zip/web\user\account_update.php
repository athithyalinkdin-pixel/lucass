<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns --> 
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Account Update</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"   >
                                            <input type="hidden" class="form-control" name="id" value="<?php echo$row['id']?>">
				
							
							<div class="form-group">
							<label>Ac Number</label>
								<input type="text" class="form-control" name="acc_num" value="<?php echo$row['acc_num']?>">
							</div>
							<div class="form-group">
							<label>Ac Holder Name</label>
								<input type="text" class="form-control" name="acc_name" value="<?php echo$row['acc_name']?>">
							</div>
							<div class="form-group">
							<label>IFSC Code</label>
								<input type="text" class="form-control" name="ifsc" value="<?php echo$row['ifsc']?>">
							</div>
							<div class="form-group">
							<label>Bank Name</label>
								<input type="text" class="form-control" name="bank" value="<?php echo$row['bank']?>">
							</div>
							<div class="form-group">
							<label>Branch</label>
								<input type="text" class="form-control" name="branch" value="<?php echo$row['branch']?>">
							</div>
						
							<div class="form-group">
							<label>Google Pay</label>
								<input type="text" class="form-control" name="google_pay" value="<?php echo$row['google_pay']?>">
							</div>
						<div class="form-group">
							<label>Phone Pe</label>
								<input type="text" class="form-control" name="phone_pe" value="<?php echo$row['phone_pe']?>">
							</div>
						
							<div class="form-group">
							<label>Paytm</label>
								<input type="text" class="form-control" name="pay_tm" value="<?php echo$row['pay_tm']?>">
							</div>
						<div class="form-group">
							<label>UPI id</label>
								<input type="text" class="form-control" name="upi" value="<?php echo$row['upi']?>">
							</div>
						<div class="form-group">
							<label>Aadhar Card</label>
								<input type="text" class="form-control" name="aadhar_number" value="<?php echo$row['aadhar_number']?>">
							</div>
						<div class="form-group">
							<label>pan Card</label>
								<input type="text" class="form-control" name="pan_number" value="<?php echo$row['pan_number']?>">
							</div>
					 <hr>
					 <div class="form-group text-center">
                     <button name="update_account" class="btn btn-primary">Update</button>
					 </div>
                                               </form>
                                            
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>