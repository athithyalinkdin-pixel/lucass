<?php include "include/header.php";?>

<div class="wrapper">

    <?php include "include/navbar.php" ;
	
	
	?>
 
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
              Wallet
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#"> Wallet</a></li>
                <li class="active"> Wallet</li>
            </ol>
        </section>


        <!-- Main content -->
        <section class="content"> 
            <div class="row">
                <!-- left column -->
                <div class="col-md-9" >
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Add/Deduct Money from Customer</h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <form action="action.php" method="post" >
                            <div class="box-body">
                                <div class="form-style-agile" >
                                    <div class="row">
                                    <div class="form-group col-md-4"> 
                                        <label for="inputPassword4">User ID</label>
                    <input type="text" class="form-control" id="user_id" value="<?= isset($_GET['id'])?$_GET['id']:''?>" name="user_id" required>
                    <p id="to_name" style="color: green;"></p>
                    </div>
                    <div class="form-group col-md-4">
                    <label for="inputPassword4">Wallet Type</label>
                  <select name="wallet_type" id="" class="form-control" required>
                    <option value="">--SELECT--</option>
                    <option value="2">Purchase Wallet</option>
                    <option value="5">Tour Wallet</option>
                  </select>
                    </div>
                 
                   
                </div>
                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Add/Deduct</label>
                                        <select name="transaction_type" id="" class="form-control" required>
                    <option value="">--SELECT--</option>
                    <option value="credit">Add</option>
                    <option value="debit">Deduct</option>
                  </select>
                    </div>
                    <div class="form-group col-md-6">
                    <label for="inputPassword4">Amount</label>
                    <input type="number" class="form-control" name="amount" required value="0" step="0.01">
                    </div>
                   
                </div>
                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Admin Note</label>
                   <textarea name="admin_note" class="form-control" id=""></textarea>
                    </div>
                    <div class="form-group col-md-6">
                    <label for="inputPassword4">User Note</label>
                  
                   <textarea name="user_note" class="form-control" id=""></textarea>
                    </div>
                   
                </div>
                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Enter Password</label>
                    <input type="password" class="form-control " name="password" required>
                    </div>
                    
                   
                </div>
									
                                    
                                        <div class="box-footer" style="text-align: center;">
										<button  name="add_deduct_wallet"  class="btn btn-primary">Submit </button>
                                            
                                        </div>
                                    </div>
                                </div>
                        </form>

                        <script>
                            $(document).ready(function() {
                                var to_id=$('#user_id').val();
                                check_name(to_id);
});

                            	$("#user_id").keyup(function(){
			
			var to_id=$('#user_id').val();
			  check_name(to_id);
			 
			});

			function check_name(to_id)
					{
						var check_user_name='';
					 $.ajax({
						url : "action.php",
						type: "POST",
						chache :false,
						data:{check_user_name:check_user_name, to_id:to_id  },
						success:function(res){
					
                             var data=jQuery.parseJSON(res);
							if(data['res']=='true')
							 $("#to_name").html(data['user_id']);
							else
							$("#to_name").html('Wrong Sponsor Id');
						}
					  });
					}
                        </script>
                    </div>
                    <!-- /.box -->

                </div>
                <div class="col-md-9" >
                <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Wallet History</h3>
                        </div>
                        <div class="box-body">
                        <table class="table"  id="data_table">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Date</th>
                                <th>User Id</th>
                                <th>Admin Note</th>
                                <th>Customer Note</th>
                                <th>Wallet Type</th>
                                <th>Type</th>
                                <th>Amount</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                           <?php 
                           $i=1;
                           $balance = 0;
                           $sql=mysqli_query($con,"SELECT * FROM wallet_histroy ");
                           while($row=mysqli_fetch_array($sql)){

                            $transaction_type = $row['transaction_type'];
                            $amount = $row['amount'];
                        
                    
                            // Adjust balance
                            if ($transaction_type == 'credit') {
                                $balance += $amount;
                            } else {
                                $balance -= $amount;
                            }
                            $st=$transaction_type == 'credit'?'<p class="badge " style="background-color:green">Credit</p>':'<p class="badge " style="background-color:red">Debit</p>';

                            //number_format($balance, 2)
                            echo '<tr>';
                            echo '<td>'.$i++.'</td>';
                            echo '<td>'. date('d-m-Y',$row['jdate']) .'</td>';
                            echo '<td>'.$row['user_id'].'</td>';
                            echo '<td>'.$row['admin_note'].'</td>';
                            echo '<td>'.$row['user_note'].'</td>';
                            echo '<td>'.$row['wallet_type'].'</td>';
                            echo '<td>'.$st.'</td>';
                            echo '<td>'. number_format($amount, 2) .'</td>';
                    
                            echo '</tr>';
                           }
                           ?>
                        </tbody>
                    </table>
                        </div>
                </div>      
                   
                </div>

            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include "include/footer.php" ?>
