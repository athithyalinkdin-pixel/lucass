<?php include "include/header.php" ?>

<div class="wrapper">

    <?php include "include/navbar.php" ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
		<?php  $tree_id=$_GET['id'];
						function check_tree_img($user_id)
						{
							global $con;
							$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree INNER JOIN reg ON reg.user_id=tree.user_id WHERE reg.user_id='$user_id'"));

						$color=$row['status']==1?'green':'yellow';
						$img='green.png';
							return '<a href="tree.php?id='.$user_id.'" class="basic treenode" data-username="'.$user_id.'">
							
							<img src="'.$img.'" class="tree_show"" alt="" style="width:50px">
						</a>
						<p class="user-id">'.$user_id.'<br>'.(!empty($row['name'])?$row['name']:'').' <a class="popoverdata" data-username="'.$user_id.'"></a></p>';
						}

						function empty_tree($user_id,$pos)
						{
							echo '<a href=#?pid='.$user_id.'&&pos='.$pos.'"  >
						<img src="red.png" class="tree_show"" alt="" style="width:50px">
							<p class="notavailable">
								Vacant
							</p>
						</a>';
						}
						function check_tree_leg($user_id,$leg)
						{
							global $con;
							$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree INNER JOIN reg ON reg.user_id=tree.user_id WHERE reg.user_id='$user_id'"));
							return $row[$leg];
						}

?>
        <section class="content-header">
            <h1>
               User ID: <?php echo $tree_id?> 
            </h1>
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="manage_user.php">User info</a></li>
                <li class="active">User info</li>
            </ol>
        </section>

      
        <script src="scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
        <script type="text/javascript" language="javascript">
        $("#success_msg").delay(4000).fadeOut(100);
        </script>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12" >
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Tree</h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                       
                            <div class="box-body">

                            <div style="overflow-x: scroll; height:500px" >
                          <table class="table">
					<tr>
						<td class="text-center" colspan="9">
						<?php echo check_tree_img($tree_id)?>
						</td>
						
					</tr>
					<tr>
	
 
 

						<td class="text-center" colspan="3">
						<?php if(!empty(check_tree_leg($tree_id,'id1'))) 
												{
													$id1=check_tree_leg($tree_id,'id1');
													echo check_tree_img($id1);
												}
												else
												{
													echo empty_tree($tree_id,1);
												}
										?>
						</td>
						<td class="text-center" colspan="3">
						<?php if(!empty(check_tree_leg($tree_id,'id2'))) 
												{
													$id2=check_tree_leg($tree_id,'id2');
													echo check_tree_img($id2);
												}
												else
												{
													echo empty_tree($tree_id,2);
												}
										?>
						</td>
                        <td class="text-center" colspan="3">
						<?php if(!empty(check_tree_leg($tree_id,'id3'))) 
												{
													$id3=check_tree_leg($tree_id,'id3');
													echo check_tree_img($id3);
												}
												else
												{
													echo empty_tree($tree_id,3);
												}
										?>
						</td>
					
								    
					</tr>	
					<tr>
						<td class="text-center">
						<?php if(!empty($id1))
														{
															if(!empty(check_tree_leg($id1,'id1'))) 
															{
																$id11=check_tree_leg($id1,'id1');
																echo check_tree_img($id11);
															}
															else
															{
																echo empty_tree($id1,1);
															}
														} 
														
												?>
						</td>
						
						<td class="text-center">
						<?php if(!empty($id1))
														{
															if(!empty(check_tree_leg($id1,'id2'))) 
															{
																$id12=check_tree_leg($id1,'id2');
																echo check_tree_img($id12);
															}
															else
															{
																echo empty_tree($id1,2);
															}
														} 
														
												?>
						</td>
                        <td class="text-center">
						<?php if(!empty($id1))
														{
															if(!empty(check_tree_leg($id1,'id3'))) 
															{
																$id13=check_tree_leg($id1,'id3');
																echo check_tree_img($id13);
															}
															else
															{
																echo empty_tree($id1,3);
															}
														} 
														
												?>
						</td>
						
					
						
						<td class="text-center">
						<?php if(!empty($id2))
														{
															if(!empty(check_tree_leg($id2,'id1'))) 
															{
																$id21=check_tree_leg($id2,'id1');
																echo check_tree_img($id21);
															}
															else
															{
																echo empty_tree($id2,1);
															}
														} 
														
												?>
						</td>
						
						<td class="text-center">
						<?php if(!empty($id2))
														{
															if(!empty(check_tree_leg($id2,'id2'))) 
															{
																$id22=check_tree_leg($id2,'id2');
																echo check_tree_img($id22);
															}
															else
															{
																echo empty_tree($id2,2);
															}
														} 
														
												?>
						</td>
                        <td class="text-center">
						<?php if(!empty($id2))
														{
															if(!empty(check_tree_leg($id2,'id3'))) 
															{
																$id23=check_tree_leg($id2,'id3');
																echo check_tree_img($id23);
															}
															else
															{
																echo empty_tree($id2,3);
															}
														} 
														
												?>
						</td>

                        <td class="text-center">
						<?php if(!empty($id3))
														{
															if(!empty(check_tree_leg($id3,'id1'))) 
															{
																$id31=check_tree_leg($id3,'id1');
																echo check_tree_img($id31);
															}
															else
															{
																echo empty_tree($id3,1);
															}
														} 
														
												?>
						</td>
						<td class="text-center">
						<?php if(!empty($id3))
														{
															if(!empty(check_tree_leg($id3,'id2'))) 
															{
																$id32=check_tree_leg($id3,'id2');
																echo check_tree_img($id32);
															}
															else
															{
																echo empty_tree($id3,2);
															}
														} 
														
												?>
						</td>
                        <td class="text-center">
						<?php if(!empty($id3))
														{
															if(!empty(check_tree_leg($id3,'id3'))) 
															{
																$id33=check_tree_leg($id3,'id3');
																echo check_tree_img($id33);
															}
															else
															{
																echo empty_tree($id3,3);
															}
														} 
														
												?>
						</td>
						
					
						
						
						
					
						
				
						
					</tr>	
					</table>
                    
                    </div>
						
                       
                    </div>   


                </div>

            </div>
		   
			
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include "include/footer.php" ?>
