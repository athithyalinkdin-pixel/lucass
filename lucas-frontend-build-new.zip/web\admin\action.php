<?php session_start();

include "../db.php";
include "../user/function.php";

if(isset($_POST['level_income_update'])){
	mysqli_query($con,"UPDATE `level_product_value` SET `level_1`='".$_POST['level_1']."', `level_2`='".$_POST['level_2']."', `level_3`='".$_POST['level_3']."', `level_4`='".$_POST['level_4']."' WHERE `pro_code`='".$_POST['pro_code']."'")or die("error 2");

	echo "<script>alert('Level Updated Successfully')</script>";
		echo "<script>location.href='level_income_set.php'</script>";
}
if(isset($_POST['level_add'])){
	mysqli_query($con,"INSERT INTO `level_product_value`(`pro_code`, `level_1`, `level_2`, `level_3`, `level_4`) VALUES ('".$_POST['pro_code']."','".$_POST['level_1']."','".$_POST['level_2']."','".$_POST['level_3']."','".$_POST['level_4']."')")or die("error");
	echo "<script>alert('Level Added Successfully')</script>";
		echo "<script>location.href='level_income_set.php'</script>";
}
if(isset($_POST['delete_order'])){
	mysqli_query($con,"DELETE FROM cart WHERE cart_ai_id='".$_POST['cart_ai_id']."'")or die("Error");
	echo "<script>alert('Order Deleted Successfully')</script>"; 
		echo "<script>location.href='order_status.php?id=4'</script>";
}

if(isset($_POST['user_update'])){ 
mysqli_query($con,"UPDATE reg SET `is_blockid`='".$_POST['is_blockid']."',`name`='".$_POST['name']."',`mobile`='".$_POST['mobile']."',mail='".$_POST['mail']."',password='".$_POST['password']."' WHERE  `user_id`='".$_POST['user_id']."'")or die('error');

echo "<script>alert('Update Successfully')</script>";
		echo "<script>location.href='view.php?id=".$_POST['user_id']."'</script>";
}
if(isset($_POST['update_account'])){

	if(!empty($_FILES['pic']['name']))
	{
		unlink($_POST['unlink']);
		$destination='../assets/';
		$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);
		mysqli_query($con,"UPDATE `admin` SET `qr_code`='$pic_name' ");
	}

	mysqli_query($con,"UPDATE `admin` SET `acc_no`='".$_POST['acc_no']."',`acc_name`='".$_POST['acc_name']."',`ifsc`='".$_POST['ifsc']."',`bank`='".$_POST['bank']."',`branch`='".$_POST['branch']."',`gpay`='".$_POST['gpay']."',`phone_pe`='".$_POST['phone_pe']."',`upi_id`='".$_POST['upi_id']."' ")or die('error');
	success('Update ');
}

if(isset($_POST['add_deduct_wallet'])){
	
		$amount=$_POST['amount'];
		$user_id=$_POST['user_id'];
		switch ($_POST['wallet_type']) {
			case 2:
				$wallet_type = 'purchase_wallet';
				break;
			case 3:
				$wallet_type = 'ref_income';
				break;
			case 4:
				$wallet_type = 'level_income';
				break;
			case 5:
				$wallet_type = 'tour_wallet';
				break;
			case 6:
				$wallet_type = 'activity_bonus';
				break;
			case 7:
				$wallet_type = 'performance_bonus';
				break;
			default:
				$wallet_type = 'total_income';
				break;
		}
		
	
		$sign=$_POST['transaction_type']=='credit'?'+':'-';

		mysqli_query($con,"INSERT INTO `wallet_histroy`( `jdate`, `user_id`, `transaction_type`, `amount`, `admin_note`, `user_note`,`wallet_type`) VALUES ('$strtime','$user_id','".$_POST['transaction_type']."','$amount','".$_POST['admin_note']."','".$_POST['user_note']."','$wallet_type')")or die('error');

			mysqli_query($con, "UPDATE `reg` SET `$wallet_type` = `$wallet_type` " . $sign . " $amount WHERE `user_id` = '$user_id'") or die('wallet update error');
		
		echo "<script>alert('Wallet Added Successfully')</script>";
		echo "<script>location.href='wallet_add.php'</script>";

	
}

if(isset($_POST['check_product_name']))
{
	$sql=mysqli_query($con,"SELECT * FROM product WHERE pro_code='".$_POST['to_id']."'");
	$cnt=mysqli_num_rows($sql);
	if($cnt==0)
	$arr = array('res' => 'false' );
else
{
	$row=mysqli_fetch_assoc($sql);
	$arr = array('res' => 'true','user_id'=>$row['pro_name'] );
}
	
echo json_encode($arr);
}

if(isset($_POST['check_user_name']))
{
	$sql=mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$_POST['to_id']."'");
	$cnt=mysqli_num_rows($sql);
	if($cnt==0)
	$arr = array('res' => 'false' );
else
{
	$row=mysqli_fetch_assoc($sql);
	$arr = array('res' => 'true','user_id'=>$row['name'] );
}
	
echo json_encode($arr);
}

if(isset($_POST['place_order_from_admin_reject'])){
	$client_txn_id=$_POST['client_txn_id'];


	mysqli_query($con,"UPDATE order_entries SET status=2  WHERE client_txn_id='$client_txn_id' ");
	echo "<script>alert('Reject Successfully')</script>";
	echo "<script>location.href='index.php'</script>";
}

if(isset($_POST['place_order_from_admin'])){
	$client_txn_id=$_POST['client_txn_id'];
$row_order=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM order_entries WHERE client_txn_id='$client_txn_id'"));
$user_id=$row_order['user_id'];
	$inv_number = rand(1111, 9999) . mysqli_num_rows(mysqli_query($con, "SELECT * FROM invoice"));

	$sql=mysqli_query($con,"SELECT * FROM cart WHERE  user_id='$user_id' AND cart_status=2")or die('error 1');
	while($row2=mysqli_fetch_array($sql))
	{
		
	}

	$row = mysqli_fetch_assoc(mysqli_query($con, "SELECT SUM(cart_mrp) AS inv_price,SUM(cart_gst) AS inv_tax , SUM(cart_discount) AS inv_discount, SUM(cart_pro_selling_price) AS inv_total FROM cart WHERE  user_id='$user_id' AND cart_status=2"));
	mysqli_query($con, "INSERT INTO `invoice`(`inv_jdate`, `inv_user`, `inv_number`, `inv_price`, `inv_tax`, `inv_discount`, `inv_total`) VALUES ('$strtime','$user_id','$inv_number','" . $row['inv_price'] . "','" . $row['inv_tax'] . "','" . $row['inv_discount'] . "','" . $row['inv_total'] . "')") or die('invoice insert error');
	mysqli_query($con, "UPDATE reg SET total_purchase=total_purchase+" . $row['inv_total'] . ",status=1 WHERE user_id='$user_id'") or die('purchase wallet update error');
	$sql = mysqli_query($con, "UPDATE cart SET cart_inv_no='$inv_number',cart_status=1 WHERE cart_status=2 AND user_id='$user_id' ") or die('cart update error');


	mysqli_query($con,"UPDATE order_entries SET status=1  WHERE client_txn_id='$client_txn_id' ");
	echo "<script>alert('Accept Successfully')</script>";
	echo "<script>location.href='index.php'</script>";
}
if(isset($_POST['is_best_submit'])){
	$sql=mysqli_query($con,"UPDATE product SET is_best='".$_POST['is_best']."' WHERE pro_ai='".$_POST['pro_ai']."'")or die('error');

	if($sql) {
        echo 'success';
    } else {
        echo 'error';
    }
}

if(isset($_POST['is_offer_submit'])){
	$sql=mysqli_query($con,"UPDATE product SET is_offer='".$_POST['is_offer']."' WHERE pro_ai='".$_POST['pro_ai']."'")or die('error');

	if($sql) {
        echo 'success';
    } else {
        echo 'error';
    }
}


if(isset($_POST['is_today_submit'])){
	$sql=mysqli_query($con,"UPDATE product SET is_today='".$_POST['is_today']."' WHERE pro_ai='".$_POST['pro_ai']."'")or die('error');

	if($sql) {
        echo 'success';
    } else {
        echo 'error';
    }
}

if(isset($_POST['is_flash_submit'])){
	$sql=mysqli_query($con,"UPDATE product SET is_flash='".$_POST['is_flash']."' WHERE pro_ai='".$_POST['pro_ai']."'")or die('error');

	if($sql) {
        echo 'success';
    } else {
        echo 'error';
    }
}

if(isset($_POST['is_new_submit'])){
	$sql=mysqli_query($con,"UPDATE product SET is_new='".$_POST['is_new']."' WHERE pro_ai='".$_POST['pro_ai']."'")or die('error');

	if($sql) {
        echo 'success';
    } else {
        echo 'error';
    }
}
if(isset($_POST['getProImageByCode'])){
	$sql=mysqli_query($con,"SELECT * FROM `pro_images` WHERE `pro_code`='".$_POST['getProImageByCode']."'")or die('error');
	while($row=mysqli_fetch_array($sql)){
		echo '<tr>
		<td> <img src="../product_image/'.$row['pi_pic'].'" style="width:70px;height:70px"></td>
		
		<td> <a href="#" class="btn btn-danger delete_pro_image"  data-id="'.$row['pi_ai'].'">Delete</a></td>
		</tr>
		';
	}
}

if(isset($_POST['delete_pro_image'])){
	$pi_ai=$_POST['delete_pro_image'];
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `pro_images` WHERE `pi_ai`='$pi_ai'"));
	unlink('../product_image/'.$row['pi_pic']);
	mysqli_query($con,"DELETE FROM `pro_images` WHERE `pi_ai`='$pi_ai'")or die('delete error');
}
if(isset($_POST['getProImage'])){
	$sql=mysqli_query($con,"SELECT * FROM `pro_images` WHERE `pro_code`='' ")or die('error');
	while($row=mysqli_fetch_array($sql)){
		echo '<tr>
		<td> <img src="../product_image/'.$row['pi_pic'].'" style="width:70px;height:70px"></td>
		
		
		<td> <a href="#" class="btn btn-danger delete_pro_image"  data-id="'.$row['pi_ai'].'">Delete</a></td>
		</tr>
		';
	}
}
if(isset($_POST['cut_off'])){ 
	$sql=mysqli_query($con,"SELECT * FROM withdraw_request WHERE wr_status=1")or die('error 1 cuttoff');
	while($row=mysqli_fetch_array($sql)){
		$sql2=mysqli_query($con,"SELECT * FROM cutt_off WHERE user_id='".$row['user_id']."' AND cutt_status=1")or die('error 2');
		$cnt=mysqli_num_rows($sql2);
		if($cnt>=1){
			mysqli_query($con,"UPDATE cutt_off SET wr_date='$strtime',amount=amount+".$row['amount'].",tds=tds+".$row['tds'].",service=service+".$row['service'].",repurchase=repurchase+".$row['repurchase'].",net_deduction=net_deduction+".$row['net_deduction'].",eligible_withdraw=eligible_withdraw+".$row['eligible_withdraw']." WHERE user_id='".$row['user_id']."' ")or die('error 3');
		}
		else{
			mysqli_query($con,"INSERT INTO `cutt_off`(`user_id`, `wr_date`, `amount`, `tds`, `service`, `repurchase`, `net_deduction`, `eligible_withdraw`) VALUES ('".$row['user_id']."','$strtime','".$row['amount']."','".$row['tds']."','".$row['service']."','".$row['repurchase']."','".$row['net_deduction']."','".$row['eligible_withdraw']."' )")or die('error 4');
		}
		mysqli_query($con,"UPDATE withdraw_request SET wr_status=2 WHERE user_id='".$row['user_id']."'") or die('error 5');
	}
	echo "<script>alert('Cutt-Off Successfully')</script>";
	echo "<script>location.href='cutt_off.php'</script>";
}
if(isset($_POST['wallet_remove'])){
	unlink($_POST['unlink']);
	mysqli_query($con,"DELETE  FROM deposit WHERE ai='".$_POST['ai']."'")or die('eror 2');
	echo "<script>alert('Remove Successfully')</script>";
	echo "<script>location.href='deposit_new.php'</script>";
}


if(isset($_POST['wallet_accept'])){

	mysqli_query($con,"UPDATE deposit SET status=1 WHERE ai='".$_POST['ai']."'")or die('eror 2');

	

	echo "<script>alert('Accept Successfully')</script>";
	echo "<script>location.href='deposit_new.php'</script>";
}

if(isset($_POST['order_status_change'])){
	mysqli_query($con,"UPDATE cart SET order_status='".$_POST['status']."' WHERE id='".$_POST['id']."'")or die('change status error');


	echo "<script>location.href='".$_POST['currunt_url']."'</script>";
}
if(isset($_POST['upate_vid_url']))
{
	
	$video=getYoutubeEmbedUrl($_POST['video']);
	mysqli_query($con,"UPDATE admin SET youtube_url='$video'")or die('error');
	echo "<script>alert('Video Added')</script>";
	echo "<script>location.href='vid_add.php'</script>";
}
if(isset($_POST['send_e_pin']))
{
	$send_e_pin=$_POST['send_e_pin'];
	$u_id=$_POST['u_id'];
	$count=$_POST['count'];
	
	for($i=0;$i<$count;$i++)
	{
	$length = 10;
				$getNumber = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, $length).$_POST['amount'];
				mysqli_query($con,"INSERT INTO `pin`(`pin`, `amount`, `u_id`, `pin_date`, `status`) VALUES ('$getNumber','".$_POST['amount']."','$u_id','$strtime',0)")or die("Query Error Pin");
	}
	
	echo "<script>alert('E-pin send Successfully')</script>";
	echo "<script>location.href='view.php?id=$u_id'</script>";
}
if(isset($_POST['accept_withdraw_request']))
{
	$user_id=$_POST['user_id']; 
	$ai =$_POST['ai'];
	$net_amount=$_POST['net_amount'];
	mysqli_query($con,"UPDATE withdraw SET status=1 WHERE	ai ='$ai'" )or die("withdraw_request update query error");
	
	
		$comment='Amount of '.$net_amount.' Credit Your local Account';
	
		 transaction_history($user_id,'credit','wallet',$comment,$net_amount); 
		
		echo "<script>alert('Accetpt Withdraw Request')</script>";
	echo "<script>location.href='withdraw_new.php'</script>";
}
if(isset($_POST['delete_user']))
{
	mysqli_query($con,"DELETE FROM `cart` WHERE user_id='".$_POST['delete_user']."'")or die('error 1 cart delete');
	mysqli_query($con,"DELETE FROM `invoice` WHERE inv_user='".$_POST['delete_user']."'")or die('error 2');
	mysqli_query($con,"DELETE FROM `level` WHERE user_id='".$_POST['delete_user']."'")or die('error 3');
	mysqli_query($con,"DELETE FROM `reg` WHERE user_id='".$_POST['delete_user']."'")or die('error 4');
	mysqli_query($con,"DELETE FROM `transcation_history` WHERE u_id='".$_POST['delete_user']."'")or die('error 5');
	mysqli_query($con,"DELETE FROM `withdraw_request` WHERE u_id='".$_POST['delete_user']."'")or die('error 6');
	echo "<script>alert('Delete ID Successfully')</script>";
	echo "<script>location.href='index.php'</script>";
}
if(isset($_POST['update_img_whatsapp']))
{
	unlink($_POST['unlink']);
	
	$destination='../banners_admin/';
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);

	mysqli_query($con,"UPDATE admin SET whatsapp_pic='$pic_name'")or die('error');

	echo "<script>alert('Image Updated')</script>";
	echo "<script>location.href='whatsapp_image_update.php'</script>";
}

if(isset($_POST['franchisee_update'])) 
{
	mysqli_query($con,"UPDATE `master_franchisee` SET `mas_franch_name`='".$_POST['mas_franch_name']."',`mas_franch_mobile`='".$_POST['mas_franch_mobile']."',`mas_franch_mail`='".$_POST['mas_franch_mail']."',`mas_franch_password`='".$_POST['mas_franch_password']."',`mas_franch_address`='".$_POST['mas_franch_address']."',`mas_franch_city`='".$_POST['mas_franch_city']."',`mas_franch_state`='".$_POST['mas_franch_state']."',`mas_franch_pincode`='".$_POST['mas_franch_pincode']."' WHERE `mas_franch_id`='".$_POST['mas_franch_id']."'")or  die ('error');
	success('Updated');
}
if(isset($_POST['franchisee_add']))
{
	$mas_franch_id="MF".rand(111,999).mysqli_num_rows(mysqli_query($con,"SELECT * FROM master_franchisee"));
	mysqli_query($con,"INSERT INTO `master_franchisee`(`mas_franch_jdate`, `mas_franch_id`, `mas_franch_name`, `mas_franch_mobile`, `mas_franch_mail`, `mas_franch_password`, `mas_franch_address`, `mas_franch_city`, `mas_franch_state`, `mas_franch_pincode`,`is_mater_franches`) VALUES ('$strtime','$mas_franch_id','".$_POST['mas_franch_name']."','".$_POST['mas_franch_mobile']."','".$_POST['mas_franch_mail']."','".$_POST['mas_franch_password']."','".$_POST['mas_franch_address']."','".$_POST['mas_franch_city']."','".$_POST['mas_franch_state']."','".$_POST['mas_franch_pincode']."',1)")or die('query error');
	echo "<script>alert('Franchisee Added')</script>";
	echo "<script>location.href='franchisee_add.php'</script>";

	
                                
}
if(isset($_POST['add_banner']))
{
	
	
	
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],'../banners/');
		
				mysqli_query($con,"INSERT INTO `banner`(`url`) VALUES ('$pic_name')");
			
			echo "<script>alert('Banner Added')</script>";
	echo "<script>location.href='banner.php'</script>";
}

if(isset($_POST['edit_banner']))
{
	//mysqli_query($con,"UPDATE banner SET order_by='".$_POST['order_by']."' WHERE ban_id='".$_POST['id']."'");
	
	if(!empty($_FILES['pic']['name']))
	{
		unlink($_POST['unlink']);
		
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],'../banners/');
		mysqli_query($con,"UPDATE banner SET url='$pic_name' WHERE ban_id='".$_POST['id']."'")or die('IMg update query error');
	}
		
	echo "<script>alert('Banner Updated')</script>";
	echo "<script>location.href='banner.php'</script>";
}
if(isset($_POST['delete_banner']))
{
	unlink($_POST['unlink']);
	mysqli_query($con,"DELETE FROM `banner` WHERE ban_id='".$_POST['id']."'")or die("Query error");
	
echo "<script>alert('Banner Deleted')</script>";
	echo "<script>location.href='banner.php'</script>";
	
	
}

if(isset($_POST['proMultipleImg_delete'])){
	unlink($_POST['unlink']);
	mysqli_query($con,"DELETE FROM `pro_images` WHERE `pi_ai`='".$_POST['proMultipleImg_delete']."'")or die('error 2');
	
	echo "<script>alert('Product Image Deleted Successfully')</script>";
	echo "<script>location.href='product_view.php?id=".$_POST['pro_id']."'</script>";
}


if(isset($_POST['product_update']))
{
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT SUM(pro_qty) as qty FROM `pro_images` WHERE `pro_code`='".$_POST['pro_code']."'"));

	$youtube_link='';

	mysqli_query($con,"UPDATE `product` SET `pro_code`='".$_POST['pro_code']."',`pro_name`='".$_POST['pro_name']."',`pro_desc`='".$_POST['pro_desc']."',`mrp`='".$_POST['mrp']."',`discount`='".$_POST['discount']."',`price`='".$_POST['price']."',`pro_qty`='".$_POST['pro_qty']."',`maincat`='".$_POST['maincat']."',`pv`='".$_POST['pv']."',`subcat`='".$_POST['subcat']."',`youtube_link`='$youtube_link' WHERE `pro_ai`='".$_POST['pro_ai']."'")or die('update error');


	echo "<script>alert('Product Updated')</script>";
		echo "<script>location.href='product_all.php'</script>";
}

if(isset($_POST['add_image'])){
$pro_code=!empty($_POST['pro_code'])?$_POST['pro_code']:'';
$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM pro_images WHERE pro_code='$pro_code'"));
if($cnt==0){

	$destination='../product_image/';
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);
	mysqli_query($con,"INSERT INTO `pro_images`( `pi_pic`,`pro_code`) VALUES ('$pic_name','$pro_code')")or die('error');
	$arr=["res"=>"true"];
} else $arr=["res"=>"false"];
	echo json_encode($arr);


}
if(isset($_POST['product_add']))
{

	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `product` WHERE `pro_code`='".$_POST['pro_code']."'"));

	if($cnt>=1){
		fail('This Code Already exist');
		return;
	}
	else{
		$cnt2=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `pro_images` WHERE `pro_code`=''"));
		if($cnt2==0){
			fail('Add atleast one Image');
			return ;
		}
		else{
			
			$youtube_link='';
			
			$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT SUM(pro_qty) as qty FROM `pro_images` WHERE `pro_code`='' "));
			
			mysqli_query($con,"INSERT INTO `product`(`pro_date`,`pro_code`, `pro_name`, `pro_desc`, `mrp`, `discount`, `price`, `maincat`, `subcat`,`youtube_link`,`pro_qty`,`pv`) VALUES ('$strtime','".$_POST['pro_code']."','".$_POST['pro_name']."','".$_POST['pro_desc']."','".$_POST['mrp']."','".$_POST['discount']."','".$_POST['price']."','".$_POST['maincat']."','".$_POST['subcat']."','$youtube_link','".$_POST['pro_qty']."','".$_POST['pv']."')")or die('error 1');
		
			mysqli_query($con,"UPDATE `pro_images` SET `pro_code`='".$_POST['pro_code']."',`pro_qty`='".$row['qty']."'  WHERE `pro_code`='' ")or die('pro code update error');
			
			success('Product Added');
		}
		
	}

			
}



if(isset($_POST['product_delete']))
{
	$sql=mysqli_query($con,"SELECT  * FROM pro_images WHERE pro_code='".$_POST['pro_code']."'") or die('error');
	while($row=mysqli_fetch_array($sql)){
		unlink('../product_image/'.$row['pi_pic']);
	}
	mysqli_query($con,"DELETE FROM `pro_images` WHERE  pro_code='".$_POST['pro_code']."'") or die('update_product error');
	mysqli_query($con,"DELETE FROM `product` WHERE  pro_ai='".$_POST['pro_ai']."'") or die('update_product error');
	echo "<script>alert('Delete sucessfully')</script>";
		echo "<script>location.href='product_all.php'</script>";
}


if(isset($_POST['check_category']))
{
	$res_cat=mysqli_query($con,"SELECT * FROM category_sub WHERE maincat='".$_POST['maincat']."'")or die("Query error");
	$i=1;
	while($row_cat=mysqli_fetch_array($res_cat))
	{
		echo '<option value='.$row_cat['subcat_ai'].'>'.$row_cat['subcat'].'</option>';
	}
}
if(isset($_POST['sub_cat_delete']))
{
	mysqli_query($con,"DELETE FROM `category_sub` WHERE  subcat_ai='".$_POST['subcat_ai']."'")or die('error');
	echo "<script>alert('Category Deleted')</script>";
	echo "<script>location.href='category_sub.php'</script>";
}

if(isset($_POST['sub_cat_edit']))
{
	mysqli_query($con,"UPDATE category_sub SET subcat='".$_POST['subcat']."' WHERE subcat_ai='".$_POST['subcat_ai']."'")or die('error');
	echo "<script>alert('Category Updated')</script>";
	echo "<script>location.href='category_sub.php'</script>";
}
if(isset($_POST['category_sub_add']))
{
	

	mysqli_query($con,"INSERT INTO `category_sub`(`maincat`, `subcat`) VALUES ('".$_POST['maincat']."','".$_POST['subcat']."')");

	echo "<script>alert('category_added')</script>";
	echo "<script>location.href='category_sub.php'</script>";
}

if(isset($_POST['category_delete']))
{
	mysqli_query($con,"DELETE FROM category WHERE id='".$_POST['id']."'");

	
		unlink($_POST['unlink']);

		echo "<script>alert('Category Deleted')</script>";
	echo "<script>location.href='category_main.php'</script>";
}

if(isset($_POST['category_edit']))
{
	mysqli_query($con,"UPDATE category SET category_name='".$_POST['category_name']."' WHERE id='".$_POST['id']."'");
	
	if(!empty($_FILES['pic']['name']))
	{
		unlink($_POST['unlink']);

		$destination='../category_icon/';
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);
	mysqli_query($con,"UPDATE category SET icon='$pic_name' WHERE id='".$_POST['id']."'")or die('IMg update query error');
	}
		
		echo "<script>alert('Category Updated')</script>";
	echo "<script>location.href='category_main.php'</script>";
}

if(isset($_POST['category_add']))
{
	$category_name=$_POST['category_name'];
	
	$destination='../category_icon/';
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);

	mysqli_query($con,"INSERT INTO `category`(`category_name`, `icon`) VALUES ('$category_name','$pic_name')");

	echo "<script>alert('Category Added')</script>";
	echo "<script>location.href='category_main.php'</script>";
}







if(isset($_POST['delete_category']))
{
	mysqli_query($con,"DELETE FROM `category` WHERE id='".$_POST['id']."'")or die("Query error");
	
	echo "<script>alert('Delete Category Successfully')</script>";
	echo "<script>location.href='category_management.php'</script>";
	
	
}



if(isset($_POST["login"]))
{
	$u_id=$_POST["u_id"];
	$pass=$_POST["pass"];
	if($u_id!=""&&$pass!="")
	{
		
		$sql=mysqli_query($con,"SELECT * FROM `admin` WHERE `name`='$u_id' AND `pass`='$pass'")or die('error1');
		$cnt=mysqli_num_rows($sql);
		if($cnt>=1)
		{
			
			$_SESSION["admin_ssj"]=$u_id;
			
			echo "<script>location.href='index.php'</script>";
			//header("Location:loginindex.php");
		}
		else
		{
			echo "<p>Please enter Correct Details1</p>";
		}
	}
	else
	{
		echo "<p>Please enter all the details2</p>";
	}
}


if(isset($_POST['send_message'])){
	$user_id=$_POST['u_id'];
	$subject=$_POST['subject'];
	$message=$_POST['message'];
	mysqli_query($con,"INSERT INTO `message`(`jdate`, `from_id`, `to_id`, `subject`, `message`) VALUES ('$strtime','admin','$user_id','$subject','$message')") or die("message Query error");
	echo "<script>alert('Message Send Successfully')</script>";
	echo "<script>location.href='create_message.php?id=".$user_id."'</script>";
}



if(isset($_POST['change_pass']))
{
	
	$old_pass=$_POST['old_pass'];
	$cpwd=$_POST['cpwd'];
	$user_name=$_POST['user_name'];
	$sql=mysqli_query($con,"SELECT * FROM admin WHERE pass='$old_pass'");
	$cnt=mysqli_num_rows($sql);

	 if($cnt>=1)
	 {
		 mysqli_query($con,"UPDATE `admin` SET `pass`='$cpwd',`name`='$user_name' ")or die("Query error");
		 $msg="Password Update";
		success($msg);
	 }
	 else{
		 $msg="Wrong Old Password";
		fail($msg);
	 }
	
	
}
function getYoutubeEmbedUrl($url)
	{
		 $shortUrlRegex = '/youtu.be\/([a-zA-Z0-9_-]+)\??/i';
		 $longUrlRegex = '/youtube.com\/((?:embed)|(?:watch))((?:\?v\=)|(?:\/))([a-zA-Z0-9_-]+)/i';

		if (preg_match($longUrlRegex, $url, $matches)) {
			$youtube_id = $matches[count($matches) - 1];
		}

		if (preg_match($shortUrlRegex, $url, $matches)) {
			$youtube_id = $matches[count($matches) - 1];
		}
		return $youtube_id ;
	}


 ?>
