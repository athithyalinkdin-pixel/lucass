
<?php include "include/header.php" ?>

<div class="wrapper">

    <?php include "include/navbar.php" ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
<?php 

switch ($_GET['id']) {
    case 1:
        $head='Accept';
        $status=1;
          break;
          case 2:
            $head='Reject';
            $status=2;
          
    default:
    $head='Waiting';
    $status=2;
        break;
}
?>
        <!-- Content Header (Page header) -->
       <section class="content-header"><h1> <?= $head?> Status Report<small>advanced tables</small></h1>
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#"> <?= $head?> Status</a></li>
                <li class="active"> <?= $head?> Status</li>
            </ol></section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title" style="color:#FF0000;"><b><?= $head?> Status Report</b></h3>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                        <table id="data_table" class="table table-bordered table-striped">  
      <thead>  
           <tr>  
           <th>Sl.No</th>
<th>Date</th>
<th>Customer Details</th>
<th>Order Id </th>
<th>Amount</th>

           </tr>  
      </thead>  
         <tbody>
                <?php 


        $res_pin=mysqli_query($con,"SELECT * FROM `order_entries`  WHERE `status`=$status ORDER BY `ai` DESC  ")or die("Query error");
        $i=1;
      
        while($row1=mysqli_fetch_array($res_pin))
        {
            $row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$row1['user_id']."'"));
            echo '<tr>';
            echo '<td>'.$i++.'</td>';
            echo '<td>'.date('d-m-Y',strtotime($row1['jdate'])).'</td>';
            echo '<td>'.$row1['user_id'].' - ' .$row['name'].' ,<br>'.$row['address'].'<br>'.$row['city'].'<br>'.$row['state'].' - '.$row['pin_code'].'<br>'.$row['mobile'].'</td>';
            echo '<td>'.$row1['order_id'].'</td>';
            echo '<td>'.$row1['amount'].'</td>';
           
            echo '</form></tr>';

?>
    
    <?php
}
        
    ?>
            </tbody>
 </table> 
                        </div>
                        <!-- /.box-body -->
                    </div>
					 
		    <script>  
			 $(document).ready(function(){  
				  $('#employee_data').DataTable();  
			 });  
			 </script>  
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php include "include/footer.php" ?>

