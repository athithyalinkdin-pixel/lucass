<?php include "include/header.php"?>
<?php include "include/navbar.php";

?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">My Plans</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th style="text-align:center;">S.No.</th>
                                        <th style="text-align:center;">Date</th>
                                        <th style="text-align:center;">Plan Amount</th>
                                        <th style="text-align:center;">Income</th>
                                        <th style="text-align:center;">ROI Amount</th>
                                        <th style="text-align:center;">Balance Days</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
					
                    $res_pin=mysqli_query($con,"SELECT * FROM plan WHERE user_id='$user_id'")or die("Query error");
                    $i=1 ;
                    while($row_pin=mysqli_fetch_array($res_pin))
            {
            ?>
                <tr>
                    <td><?php echo $i++; ;?></td>
                    <td><?php echo$row_pin['roi_start_date'];?></td>
                    <td><?php echo$row_pin['roi_start_date'];?></td>
                    <td><?php echo$row_pin['total_income'];?></td>
                    <td><?php echo$row_pin['daily_increment_amount'];?></td>
                    
                    <td><?php echo$row_pin['roi_decrement'];?></td>
                </tr>
                <?php
            }
                    
                ?>
                                                                    </tbody>
                            </table>

                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>