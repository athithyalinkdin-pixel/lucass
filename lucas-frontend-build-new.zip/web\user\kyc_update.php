<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Upload KYC</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"  enctype="multipart/form-data" >
                                            <input type="hidden" class="form-control" name="user_id" value="<?php echo$row['user_id']?>">
				
							
							<div class="form-group">
							<label>Aadhar Card</label>
								<input type="file" class="form-control" name="pic1" required>
							</div>
							<div class="form-group">
							<label>Pan Card</label>
								<input type="file" class="form-control" name="pic2" required>
							</div>
							<div class="form-group">
							<label>Bank Passbook</label>
								<input type="file" class="form-control" name="pic3" required>
							</div>
							
					 <hr>
					 <div class="form-group text-center">
                     <button name="update_kyc" class="btn btn-primary">Update</button>
					 </div>
                                               </form>
                                            
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>