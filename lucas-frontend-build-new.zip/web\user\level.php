<?php include "include/header.php"?>
<?php include "include/navbar.php";

?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->
        <?php $row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM level WHERE user_id='$user_id'"));?>
        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Level Team</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th>Level</th>
								<th>Team</th>
								<th>Income</th>
                                    </tr>
                                </thead>
                               
<tbody>
							<tr>
								<th>Level 1 </th>
								<td><?php echo$row['level_1'];?></td>
								<td><?php echo$row['level_1_income'];?></td>
								
								
							</tr>
							<tr>
								<th>Level 2 </th>
								<td><?php echo$row['level_2'];?></td>
								<td><?php echo$row['level_2_income'];?></td>
								
								
							</tr>
							<tr>
								<th>Level 3 </th>
								<td><?php echo$row['level_3'];?></td>
								<td><?php echo$row['level_3_income'];?></td>
								
							</tr>
                            <tr>
								<th>Level 4 </th>
								<td><?php echo$row['level_4'];?></td>
								<td><?php echo$row['level_4_income'];?></td>
								
							</tr>
                            <tr>
								<th>Level 5 </th>
								<td><?php echo$row['level_5'];?></td>
								<td><?php echo$row['level_5_income'];?></td>
								
							</tr>
                            </tbody>
                            </table>

                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>