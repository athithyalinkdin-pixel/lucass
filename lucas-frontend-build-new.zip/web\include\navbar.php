
<div class="lgx-container ">
        <!-- ***  ADD YOUR SITE CONTENT HERE *** -->


        <!--HEADER-->
        <header>
            <div id="lgx-header" class="lgx-header">
                <div class="lgx-header-position ">
                    <!--lgx-header-position-fixed lgx-header-position-white lgx-header-fixed-container lgx-header-fixed-container-gap lgx-header-position-white-->
                    <div class="lgx-container">
                        <!--lgx-container-fluid-->
                        <nav class="navbar navbar-default lgx-navbar">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                                <div class="lgx-logo">
                                    <a href="index.php" class="lgx-scroll">
                                <img src="assets/logo.png" alt="<?php echo company_name?>" style="width:200px;margin-top:15px"/>
                            </a>
                                </div>
                            </div>
                            <div id="navbar" class="navbar-collapse collapse">
                                <div class="lgx-nav-right navbar-right">
                                    <div class="lgx-cart-area">
                                        <a class="lgx-btn lgx-btn-red" href="user/">Login</a>
                                    </div>
                                </div>
                                <ul class="nav navbar-nav lgx-nav navbar-right">

                                    <li><a class="lgx-scroll" href="index.php">Home</a></li>
                                    <li><a class="lgx-scroll" href="products.php">Products</a></li>
                                    <li><a class="lgx-scroll" href="#about">About</a></li>
                                    <li><a class="lgx-scroll" href="#contact">Contact</a></li>
                                </ul>
                            </div>
                            <!--/.nav-collapse -->
                        </nav>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
            </div>
        </header>
        <!--HEADER END-->
