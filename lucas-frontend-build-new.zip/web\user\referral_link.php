<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-xs-12 col-md-6 ">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Referral Link Left</h5>
                    </div>
                                            
                                            <div class="card-body">
                                               <div class="form-group">
                                               <input type="text" value="<?php echo url ;?>/user/reg.php?id=<?php echo $user_id?>&&pos=LEFT"  class="form-control" required>
							</div>
                            <p id="p1" style="display:none"><?php echo url?>/user/reg.php?id=<?php echo $user_id?>&&pos=LEFT</p>
                    <div class="card-footer">
					 <div class="form-group text-center">
					<button name="user_registration" class="btn btn-primary btn-lg" onclick="copyToClipboard('#p1','Left')" >Copy LEFT</button>
					 </div>
                     </div>
                                   
                                            </div>
                </div>

              
            </div>

            <div class="col-xs-12 col-md-6 ">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Referral Link Right</h5>
                    </div>
                                            
                                            <div class="card-body">
                                               <div class="form-group">
                                               <input type="text" value="<?php echo url ;?>/user/reg.php?id=<?php echo $user_id?>&&pos=RIGHT"  class="form-control" required>
							</div>
                            <p id="p2" style="display:none"><?php echo url?>/user/reg.php?id=<?php echo $user_id?>&&pos=RIGHT</p>
                    <div class="card-footer">
					 <div class="form-group text-center">
					<button name="user_registration" class="btn btn-primary btn-lg" onclick="copyToClipboard('#p2','Right')" >Copy RIGHT</button>
					 </div>
                     </div>
                                   
                                            </div>
                </div>

              
            </div>

            <script type="text/javascript">  
								  function copyToClipboard(element, side) {

var $temp = $("<input>");
$("body").append($temp);
$temp.val($(element).text()).select();
document.execCommand("copy");
alert(side + " Referral link copied");
$temp.remove();
}
								</script> 

        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>