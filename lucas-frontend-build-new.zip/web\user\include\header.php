<?php 
session_start();
if(!isset($_SESSION['user_id']))
{
	header("location:login.php?mes=<p>Please Login Here.</p>");
}

		include "../db.php";	
		include "function.php";	
		
		$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$_SESSION['user_id']."'"));
		$row_spon=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$row['sponsor_id']."'"));
		$row_tree=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree1 WHERE user_id='".$_SESSION['user_id']."'"));
		$user_id=$row['user_id'];
      
      ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo company_name ?> :: Panel</title>

    
<meta content="" name="description">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="../<?php echo logo?>" rel="icon">
<link href="../<?php echo logo?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
<link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
<link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
<!-- For Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<!-- For Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
<style>
        .card-body form .form-group{
    padding:10px 5px;
}

@media print {
   .noprint {
     display: none;
   }
}
     </style>
     
</head>

 
<body>
