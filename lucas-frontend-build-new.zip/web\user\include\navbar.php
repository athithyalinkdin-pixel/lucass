
    <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
        <a href="index.php" class="logo d-flex align-items-center">
            <img src="../<?php echo logo?>" alt="">
            <!-- <span class="d-none d-lg-block">MoneyWorld</span> -->
        </a>
        <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->


    <nav class="header-nav ms-auto noprint">
        <ul class="d-flex align-items-center">

            <!-- <li class="nav-item dropdown">

                                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-bell"></i>
                    <span class="badge bg-primary badge-number">4</span>
                </a>

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                    <li class="dropdown-header">
                        You have 4 new notifications
                        <a href="wallet_history.php"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                                            <li class="notification-item">
                            <i class="bi bi-check-circle text-success"></i>
                            <div>
                                <h4>Credit</h4>
                                <p>900Rs Global Income</p>
                                <p>2023-06-13 09:41:44</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>
                                            <li class="notification-item">
                            <i class="bi bi-check-circle text-success"></i>
                            <div>
                                <h4>Credit</h4>
                                <p>300Rs Global Income</p>
                                <p>2023-02-14 10:39:17</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>
                                            <li class="notification-item">
                            <i class="bi bi-check-circle text-success"></i>
                            <div>
                                <h4>Debit</h4>
                                <p>500Rs Package Active</p>
                                <p>2023-01-27 08:48:49</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>
                                            <li class="notification-item">
                            <i class="bi bi-check-circle text-success"></i>
                            <div>
                                <h4>Credit</h4>
                                <p>500Rs Wallet Recharge</p>
                                <p>2023-01-27 08:48:44</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>
                    
                    <li class="dropdown-footer">
                        <a href="wallet_history.php">Show all notifications</a>
                    </li>

                </ul>

            </li> -->
           <li class="nav-item dropdown">
<?php $msg_cnt= mysqli_num_rows(mysqli_query($con,"SELECT * FROM `message` WHERE to_id='$user_id' AND status=0"));?>
                                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-chat-left-text"></i>
                    <span class="badge bg-danger badge-number"><?php echo $msg_cnt?></span>
                </a>

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
                    <li class="dropdown-header">
                        You have <?php echo $msg_cnt?> new messages
                        <a href="message_inbox.php"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
                    </li>
                                        </li>
                </ul>

            </li> 

            <li class="nav-item dropdown pe-3">

                                <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                    <img src="assets/img/b_silver.png" alt="" class="rounded-circle">
                    <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $row['user_id']?></span>
                </a><!-- End Profile Iamge Icon -->

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                    <li class="dropdown-header">
                        <h6><?php echo $row['user_id']?></h6>
                        <!-- <span>BASIC SILVER</span> -->
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>

                    <li>
                        <a class="dropdown-item d-flex align-items-center" href="profile.php">
                            <i class="bi bi-person"></i>
                            <span>My Profile</span>
                        </a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>

                    <li>
                        <a class="dropdown-item d-flex align-items-center" href="account_update.php">
                            <i class="bi bi-gear"></i>
                            <span>Account Settings</span>
                        </a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>

                    <li>
                        <form action="logout.php" method="post">
                            <button type="submit" name="logout_btn" class="dropdown-item d-flex align-items-center">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </button>
                        </form>
                    </li>

                </ul><!-- End Profile Dropdown Items -->
            </li><!-- End Profile Nav -->

        </ul>
    </nav><!-- End Icons Navigation -->

</header><!-- End Header -->    <!-- ======= Sidebar ======= -->
    <!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link collapsed" href="index.php">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="products.php">
            <i class="bi bi-cart-plus"></i>
                <span>Products</span>
            </a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#agent-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-people"></i><span>Activate</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="agent-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="reg_panel.php">
                        <i class="bi bi-circle"></i><span>New Register</span>
                    </a>
                </li>
               
                <li>
                    <a href="activate.php">
                        <i class="bi bi-circle"></i><span>Activate</span>
                    </a>
                </li>
                <li>
                    <a href="top_up.php">
                        <i class="bi bi-circle"></i><span>Dirstributor</span>
                    </a>
                </li>
               
            </ul>
        </li> -->
        <?php if($row['status']==1){?>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#print" data-bs-toggle="collapse" href="#">
                <i class="bi bi-printer"></i><span>Print</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="print" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="welcome_letter.php">
                        <i class="bi bi-circle"></i><span>Welcome Letter</span>
                    </a>
                </li>
                <!-- <li>
                    <a href="receipt.php">
                        <i class="bi bi-circle"></i><span>Payment Receipt</span>
                    </a>
                </li> -->
            </ul>
        </li>
        <?php }?>
       <!-- <li class="nav-item">
            <a class="nav-link collapsed" href="tree.php?id=<?php echo $user_id?>">
            <i class="bi bi-tree"></i>
                <span>My Tree</span>
            </a>
        </li> -->

        <!-- <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#pin-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-key"></i><span>E-Pin Details</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="pin-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="pin_request.php">
                        <i class="bi bi-circle"></i><span>E-Pin Request</span>
                    </a>
                </li>
                <li>
                    <a href="wallet_to_pin.php">
                        <i class="bi bi-circle"></i><span>Wallet to Pin</span>
                    </a>
                </li>
                <li>
                    <a href="pin_bank.php?id=0">
                        <i class="bi bi-circle"></i><span>Available Pins</span>
                    </a>
                </li>
                <li>
                    <a href="pin_bank.php?id=1">
                        <i class="bi bi-circle"></i><span>Used Pins</span>
                    </a>
                </li>
                <li>
                    <a href="pin_bank.php?id=10">
                        <i class="bi bi-circle"></i><span>Total Pins</span>
                    </a>
                </li>
                <li>
                    <a href="pin_transfer.php">
                        <i class="bi bi-circle"></i><span>E-Pin Transfer</span>
                    </a>
                </li>
                <li>
                    <a href="pin_history.php">
                        <i class="bi bi-circle"></i><span>E-Pin History</span>
                    </a>
                </li>
            </ul>
        </li>  -->
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#wallet-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-wallet2"></i><span>Wallet</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="wallet-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="withdraw.php">
                        <i class="bi bi-circle"></i><span>Withdraw</span>
                    </a>
                </li>
                <li>
                    <a href="withdraw_history.php">
                        <i class="bi bi-circle"></i><span>Withdraw History</span>
                    </a>
                </li>
                <li>
                    <a href="pin_request.php">
                        <i class="bi bi-circle"></i><span>Deposit</span>
                    </a>
                </li>
                <li>
                    <a href="history_deposit.php">
                        <i class="bi bi-circle"></i><span>Deposit History</span>
                    </a>
                </li> 
                <!-- <li>
                    <a href="income_to_purchase_transfer.php">
                        <i class="bi bi-circle"></i><span>Wallet To purchase Trnasfer</span>
                    </a>
                </li>  -->
                <li>
                    <a href="wallet_history.php">
                        <i class="bi bi-circle"></i><span>Wallet History</span>
                    </a>
                </li> 
              
            </ul>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#team-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-bar-chart"></i><span>My Team</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="team-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li> <a href="referral_team.php?id=<?php echo $user_id?>"> <i class="bi bi-circle"></i><span>Referral Team</span></a> </li>
                <li> <a href="tree.php?id=<?php echo $user_id?>"> <i class="bi bi-circle"></i><span>Genealogy Tree</span></a> </li>
                <li> <a href="binary_team.php?id=<?php echo $user_id?>&&pos=1"> <i class="bi bi-circle"></i><span>Left Team</span></a> </li>
                <li> <a href="binary_team.php?id=<?php echo $user_id?>&&pos=2"> <i class="bi bi-circle"></i><span>Right Team</span></a> </li>
                
            </ul>
        </li>
        
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-layout-text-window-reverse"></i><span>Income</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                     <li><a href="income_history.php?type=binary_income"><i class="bi bi-circle"></i><span>Binary Income</span> </a></li>
              
                
            </ul>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="referral_link.php">
            <i class="bi bi-person-plus"></i>
                <span>Refer and Earn</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#setting-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-postcard"></i><span>Profile</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="setting-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="profile.php">
                        <i class="bi bi-circle"></i><span>Profile Update</span>
                    </a>
                </li>
                <li>
                    <a href="account_update.php">
                        <i class="bi bi-circle"></i><span>Account Update</span>
                    </a>
                </li>
                <li>
                    <a href="kyc_update.php">
                        <i class="bi bi-circle"></i><span>Upload KYC</span>
                    </a>
                </li>
                <!-- <li>
                    <a href="nominee.php">
                        <i class="bi bi-circle"></i><span>Nominee Update</span>
                    </a>
                </li> -->
                <li>
                    <a href="change_password.php">
                        <i class="bi bi-circle"></i><span>Change Password</span>
                    </a>
                </li>
               
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#message-nav" data-bs-toggle="collapse" href="#">
                <i class="bi bi-envelope"></i><span>Message&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php
                echo $msg_cnt>=1?'<i class="bi bi-bell text-danger"></i>':'';
                ?> </span>  <i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="message-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
                    <a href="message_send.php">
                        <i class="bi bi-circle"></i><span>Create Message</span>
                    </a>
                </li>
                <li>
                    <a href="message_inbox.php">
                        <i class="bi bi-circle"></i><span>Inbox Messages</span>
                    </a>
                </li>
                <li>
                    <a href="message_sent.php">
                        <i class="bi bi-circle"></i><span>Sent Messages</span>
                    </a>
                </li>
               
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="logout.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
            </a>
        </li>
    </ul>

</aside><!-- End Sidebar-->    
