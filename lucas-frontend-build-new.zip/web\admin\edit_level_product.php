<?php include "include/header.php";?>

<div class="wrapper">

    <?php include "include/navbar.php" ;
	
	$head='Product Level Edit';
    $row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM level_product_value WHERE pro_code='".$_GET['id']."'"));
	?>
 
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1><?= $head?></h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#"> <?= $head?></a></li>
                <li class="active"> <?= $head?></li>
            </ol>
        </section>


        <!-- Main content -->
        <section class="content"> 
            <div class="row">
                <!-- left column -->
                <div class="col-md-9" >
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?= $head?></h3>
                            <label for="inputPassword4">Product Code</label>
                   
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        <form action="action.php" method="post" >
                            <input type="hidden" name="pro_code" value="<?= $row['pro_code']?>">
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="">Enter Product code</label>
                                     <input type="text" class="form-control" id="pro_code" value="<?= isset($_GET['id'])?$_GET['id']:''?>" name="pro_code" readonly>
                                            <p id="to_name" style="color: green;"></p>
                                </div>
                                <table class="table">
                                    <?php 
                                    for($i=1;$i<=4;$i++)
                                    {
                                        $lev='level_'.$i;
                                        echo '<tr>';
                                        echo '<th>Level '.$i.'</th>';
                                        echo '<td><input type="number" value="'.$row[$lev].'" name="level_'.$i.'" id=""></td>';
                                        echo '</tr>';
                                    }
                                    ?>
                           
                        </table>
                                </div>
                                <div class="box-body text-center">
                                    <button class="btn-success btn" name="level_income_update">Update</button>
                                </div>
                        </form>

                        <script>
                            $(document).ready(function() {
                                var to_id=$('#pro_code').val();
                                check_name(to_id);
});

                            	$("#pro_code").keyup(function(){
			
			var to_id=$('#pro_code').val();
			  check_name(to_id);
			 
			});

			function check_name(to_id)
					{
						
					 $.ajax({
						url : "action.php",
						type: "POST",
						chache :false,
						data:{check_product_name:1, to_id:to_id  },
						success:function(res){
					console.log(res);
                             var data=jQuery.parseJSON(res);
							if(data['res']=='true')
							 $("#to_name").html(data['user_id']);
							else
							$("#to_name").html('Wrong Product Code Name');
						}
					  });
					}
                        </script>
                    </div>
                    <!-- /.box -->

                </div>


               
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include "include/footer.php" ?>
