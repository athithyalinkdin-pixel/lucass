<?php include "include/header.php" ?>
<?php include "include/navbar.php";

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
 $full_url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];


        $head = 'Wallet History';


?>
<style>
  .dataTable-pagination a {
    border: 1px solid transparent;
    float: left;
    margin-left: 2px;
    padding: 6px 12px;
    position: relative;
    text-decoration: none;
    color: #d7d7d7;

    }
</style>
<main id="main" class="main">

    <div class="pagetitle">
        <h1><?php echo $user_id ?></h1>
        <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
    </div><!-- End Page Title -->
    <?php

    ?>
    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                        <h5 class=" card-title"><?=  $head?></h5>
                        <form action="<?= $full_url ?>" method="GET">

                            <input type="hidden" name="type" value="wallet" required>
                            <input type="date" name="from_date" id="" required>
                            <input type="date" name="to_date" id="" required>
                            <button class="btn btn-primary btn-sm">Submit</button>
                        </form>
                    </div>

                    <div class="card-body">
                        <div style="overflow-x: scroll;">
                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                        <th style="text-align:center;">S.No.</th>
                                        <th style="text-align:center;">Date</th>
                                        <th style="text-align:center;">Details</th>
                                      
                                        <th style="text-align:center;">Net UNIT</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (isset($_GET['from_date']) && isset($_GET['to_date'])) {
                                        $from_date = strtotime($_GET['from_date']);
                                        $to_date = strtotime($_GET['to_date']);
                                        $to_date_end = $to_date + 86399;
                                        $between = "AND jdate BETWEEN $from_date AND $to_date_end";
                                    } else {
                                        $between = '';
                                    }

                                    $res_pin = mysqli_query($con, "SELECT * FROM transaction_histroy WHERE user_id='$user_id' AND wallet_type='wallet' AND transaction_type='credit'") or die("Query error");
                                    $i = 1;
                                    while ($row_pin = mysqli_fetch_array($res_pin)) {
                                    ?>
                                        <tr>
                                            <td><?php echo $i++;; ?></td>
                                            <td><p style="width: 150px;"><?php echo date('d-m-Y H:i', $row_pin['jdate']); ?></p></td>
                                            <td><?php echo $row_pin['comment']; ?></td>
                                           
                                            <td><?php echo $row_pin['amount']+$row_pin['deduction']; ?></td>

                                        </tr>
                                    <?php
                                    }

                                    ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>


            </div>
    </section>

</main><!-- End #main -->
<?php include "include/footer.php" ?>