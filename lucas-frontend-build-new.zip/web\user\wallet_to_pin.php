<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Wallet TO Pin</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
                                               <div class="form-group">
							<label>Wallet Balance</label> 
								<input type="text" value="<?php echo $row['wallet'];?>" name="wallet" class="form-control" readonly>
							</div>
							
							<div class="form-group"> 
							<label>Admin Charge 10% , TDS 5 % </label>
								<input type="text" value="<?php echo $tds=$row['wallet']*0.15?>" class="form-control" readonly>
							</div>
							<div class="form-group">
							<label>Eligible for Pin Purchase</label>
								<input type="text" name="eligible_amount" value="<?php echo $row['wallet']-$tds?>" class="form-control" readonly>
							</div>
                            <div class="form-group">
							<label>Select Pins</label>
                            <select name="pin_amount" class="form-control" required>
									<option value="">--SELECT--</option>
                                    <option value="15000">15000</option>
									
								  </select>
							</div>
                            <div class="form-group">
							<label>Pin Count</label>
								<input type="number" name="count" value="1" class="form-control" required>
							</div>
					
                  
                    
                      
					 <hr>
					 <div class="form-group text-center">
                     <button  name="pin_generate"  class="btn btn-primary" >Generate Pin</button>
					 </div>
                                               </form>
                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>