<?php include "include/header.php"?>
<?php include "include/navbar.php";

?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Sent Messages</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table id="data_table" class="table table-bordered table-striped">  
                          <thead>  
                               <tr>  
                                   <th style="text-align:center;">S.No.</th>
                                   <th style="text-align:center;">Date</th>
                                        <th style="text-align:center;">From ID</th>
                                        <th style="text-align:center;">Subject</th>
                                        <th style="text-align:center;">Message</th>
                                        
                               </tr>  
                          </thead>  
                             <tbody>
									<?php 
				
							$res_pin=mysqli_query($con,"SELECT * FROM `message` WHERE from_id='$user_id' ORDER BY msd_id DESC")or die("Query error");
							$i=1;
							while($row_pin=mysqli_fetch_array($res_pin))
							{
				
					?>
						<tr>
							<td><?php echo $i++; ;?></td>
							<td><?php echo$row_pin['jdate'];?></td>
							<td><?php echo$row_pin['from_id'];?></td>	
							<td><?php echo$row_pin['subject'];?></td>
							<td><?php echo$row_pin['message'];?></td>
							
						</tr>
						<?php
					}
							
						?>
                                </tbody>
                     </table> 
                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>