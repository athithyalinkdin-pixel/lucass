<?php include "include/header.php" ?>
<?php include "include/navbar.php" ?>


        <section>
            <div id="lgx-about" class="lgx-about">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                           <div class="col-md-6">
                            <div class="card m-3">
                                <div class="card-header">
                                    <h2>Check out</h2>
                                </div>
                                <form action="user/action.php" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="pro_id" value="<?= $_GET['id'] ?>">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="">Sponsor Id</label>
                                            <input type="text" name="s_id" id="s_id" value="<?= isset($_SESSION['sponsor_id'])?$_SESSION['sponsor_id']:NULL ?>" class="form-control" required> 
                                            <p id="to_name" style="color: green;"></p>
                                        </div> 
                                        <div class="form-group">
                                            <label for="">Your Name</label>
                                            <input type="text" name="name"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Mobile No</label>
                                            <input type="mobile" name="mobile"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Mail Id</label>
                                            <input type="text" name="mail"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Password</label>
                                            <input type="text" name="password"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Address</label>
                                           
                                            <textarea class="form-control" name="address"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="">City</label>
                                            <input type="text" name="city"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">State</label>
                                            <input type="text" name="state"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Postel Code</label>
                                            <input type="text" name="postel_coode"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Payment Proof </label>
                                            <input type="file" name="pic"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Transaction ID</label>
                                            <input type="text" name="ref_id"  class="form-control" required> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Amount </label>
                                            <input type="number" name="amount"  class="form-control" readonly value="<?php $row_pro= getProductDetails( $_GET['id']); echo $row_pro['price'] ?>"> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Product Name </label>
                                            <input type="text"  class="form-control" readonly value="<?php  echo $row_pro['pro_name'] ?>"> 
                                        </div>
                                        <div class="form-group">
                                            <label for="">Notes </label>
                 
                                            <textarea name="details"  class="form-control"></textarea>
                                        </div>
                                    </div> 
                                    <div class="card-footer text-center">
                                        <button class="btn-success btn" name="register_from_website">Register</button>
                                    </div>
                                </form>

                                 <script>
                                 
				$("#s_id").keyup(function(){
		
					var to_id=$('#s_id').val();
					  check_name(to_id);
					 
					});
					
					$( document ).ready(function() {
                        
							var to_id=$('#s_id').val();
					  check_name(to_id);
						});
					function check_name(to_id)
					{

					 $.ajax({
						url : "user/action.php",
						type: "POST",
						chache :false,
						data:{check_user_name:1, to_id:to_id  },
						success:function(response){
					
							 $("#to_name").html(response);
						}
					  });
					}
				</script>
                            </div>
                           </div>
                           <div class="col-md-6">
                            <div class="card border--purple mb-2">
                                            <h5 class="card-header bg--gradi-2">Company Account Details</h5>
                                            <div class="card-body">
                                            <table class="table">
    <tr>
        <th>Account Name</th>
        <td class="copyable" data-copy="<?= $row_admin['acc_no'] ?>">
            <?= $row_admin['acc_no'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>Account Number</th>
        <td class="copyable" data-copy="<?= $row_admin['acc_no'] ?>">
            <?= $row_admin['acc_no'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>IFSC Code</th>
        <td class="copyable" data-copy="<?= $row_admin['ifsc'] ?>">
            <?= $row_admin['ifsc'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>Bank</th>
        <td class="copyable" data-copy="<?= $row_admin['bank'] ?>">
            <?= $row_admin['bank'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>Branch</th>
        <td class="copyable" data-copy="<?= $row_admin['branch'] ?>">
            <?= $row_admin['branch'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>Google Pay</th>
        <td class="copyable" data-copy="<?= $row_admin['gpay'] ?>">
            <?= $row_admin['gpay'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>Phone Pe</th>
        <td class="copyable" data-copy="<?= $row_admin['phone_pe'] ?>">
            <?= $row_admin['phone_pe'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <th>UPI ID</th>
        <td class="copyable" data-copy="<?= $row_admin['upi_id'] ?>">
            <?= $row_admin['upi_id'] ?>
            <button class="copy-btn" onclick="copyToClipboard(this)">📋 Copy</button>
        </td>
    </tr>
    <tr>
        <td colspan="2">

            <img src="assets/<?= $row_admin['qr_code'] ?>" alt="" srcset="">
        </td>
    </tr>
</table>

<style>
.copyable {
    position: relative;
}

.copy-btn {
    margin-left: 10px;
    padding: 2px 8px;
    font-size: 12px;
    cursor: pointer;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 3px;
    transition: background-color 0.3s;
}

.copy-btn:hover {
    background-color: #45a049;
}

.copy-btn.copied {
    background-color: #2196F3;
}
</style>

<script>
function copyToClipboard(button) {
    // Get the parent td element
    const td = button.parentElement;
    
    // Get the text to copy (either from data-copy attribute or text content)
    let textToCopy = td.getAttribute('data-copy');
    if (!textToCopy) {
        // If no data-copy attribute, get the text content excluding the button text
        textToCopy = td.childNodes[0].textContent.trim();
    }
    
    // Create a temporary textarea element
    const textarea = document.createElement('textarea');
    textarea.value = textToCopy;
    document.body.appendChild(textarea);
    
    // Select and copy the text
    textarea.select();
    document.execCommand('copy');
    
    // Remove the temporary textarea
    document.body.removeChild(textarea);
    
    // Show feedback
    const originalText = button.textContent;
    button.textContent = '✓ Copied!';
    button.classList.add('copied');
    
    // Reset button text after 2 seconds
    setTimeout(() => {
        button.textContent = originalText;
        button.classList.remove('copied');
    }, 2000);
}
</script>
                                 
                                            </div>
                                        </div>
                           </div>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>

    


<?php include "include/footer.php" ?>