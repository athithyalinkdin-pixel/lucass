<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle"> 
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">  
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Register</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post">
                                               <input type="hidden" name="activator_id" value="<?php echo $user_id?>"  >
                                               <input type="hidden" name="id" value="<?php echo $_GET['id']?>"  >
                                               		
					<div class="form-group">
							<label>Purchase Wallet <a href="pin_request.php">Purchase Wallet</a></label>
								<input type="text" class="form-control" name="purchase_wallet" value="<?php echo $row['purchase_wallet']?>" readonly>
							</div>
					 
					 <div class="form-group">
					 <label>Activate ID</label>
						<input type="text" class="form-control" id="user_id" name="user_id" required>
					 </div>	
					 
					 <div class="form-group">
					 <label>Activate Name</label>
						<input type="text" class="form-control" id="to_name"  readonly required>
					 </div>	
				
			   <div class="form-group">
					 <label>Plan Amount</label>
						<input type="text" class="form-control" name="plan_amount" value="<?= $_GET['amount'] ?>" required readonly>
					 </div>
					
				
                     
                       
					 <hr>
					 <div class="form-group text-center">
                     <button name="self_activation" class="btn btn-success">Activate</button>
					 </div>
                                               </form> 
                                               <script>
						$("#s_id").keyup(function(){
			 
			var to_id=$('#s_id').val();
			var check_user_name='';
			 $.ajax({
				url : "action.php",
				type: "POST",
				chache :false,
				data:{check_user_name:check_user_name, to_id:to_id  },
				success:function(response){
					var data=JSON.parse(response);
		
					 $("#sponosr_name").val(data.name);
				}
			  });
			 
			});

				$("#user_id").keyup(function(){
			
					var to_id=$('#user_id').val();
					var check_user_name='';
					 $.ajax({
						url : "action.php",
						type: "POST",
						chache :false,
						data:{check_user_name:check_user_name, to_id:to_id  },
						success:function(response){
				
							var data=JSON.parse(response);
		
					 $("#to_name").val(data.name);
						}
					  });
					 
					});
					
				
					
						 $('#pin').change(function () {
							 var pin=$('#pin').val();
									var check_pin_value='';
								$.ajax({
										url : "action.php",
										type: "POST",
										chache :false,
										data:{check_pin_value:check_pin_value, pin:pin  },
										success:function(response){
											 document.getElementById("pin_value").value = response;
										
										}
									  }); 
						});
									
</script>
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>