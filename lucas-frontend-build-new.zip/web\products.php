<?php include "include/header.php" ?>
<?php include "include/navbar.php" ;
if(isset($_GET['id']))
    $_SESSION['sponsor_id']=$_GET['id'];
?>
<!-- Add these to your head section -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"/>

<section>
    <style>
        .banner-carousel {
            position: relative;
        }
        
        .banner-carousel .item img {
            width: 100%;
            border-radius: 10px;
        }
        
        @media only screen and (min-width: 1200px) {
            .banner-carousel .item img {
                height: 550px;
                object-fit: cover;
            }
        }
          @media only screen and (min-width: 300px) {
            .banner-carousel .item img {
                height: 300px;
                object-fit: cover;
            }
        }

        /* Custom navigation */
        .owl-nav button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0,0,0,0.5) !important;
            color: white !important;
            font-size: 20px !important;
            width: 40px;
            height: 40px;
            border-radius: 50% !important;
        }
        
        .owl-nav .owl-prev {
            left: 20px;
        }
        
        .owl-nav .owl-next {
            right: 20px;
        }
        
        .owl-dots {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
        }
        
        .owl-dot span {
            background: rgba(255,255,255,0.5) !important;
        }
        
        .owl-dot.active span {
            background: #ff0000 !important;
        }
    </style>
    
    <div class="banner-carousel owl-carousel owl-theme">
        <?php
        $sql_banner = mysqli_query($con, "SELECT * FROM banner");
        while($row_banner = mysqli_fetch_array($sql_banner)) { ?> 
            <div class="item">
                <img src="banners/<?php echo $row_banner['url']; ?>" alt="Banner" >
            </div>
        <?php } ?>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<script>
$(document).ready(function(){
    $('.banner-carousel').owlCarousel({
        loop: true,
        margin: 0,
        nav: true,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        },
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        smartSpeed: 800
    });
});
</script>

<section>
    <style>
        /* Category Slider Container */
        .category-slider {
            background-color: #f8f9fa;  /* Background color */
            padding: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);  /* Box shadow */
        }
        
        /* Scrollable Container */
        .category-scroll {
            overflow-x: auto;
            overflow-y: hidden;
            white-space: nowrap;
            scroll-behavior: smooth;
            padding: 15px 0;
            cursor: grab;
            scrollbar-width: thin;  /* For Firefox */
            scrollbar-color: #007bff #e9ecef;  /* For Firefox */
        }
        
        .category-scroll:active {
            cursor: grabbing;
        }
        
        /* Custom Scrollbar for Webkit browsers (Chrome, Safari, Edge) */
        .category-scroll::-webkit-scrollbar {
            height: 8px;
        }
        
        .category-scroll::-webkit-scrollbar-track {
            background: #e9ecef;
            border-radius: 10px;
        }
        
        .category-scroll::-webkit-scrollbar-thumb {
            background: #007bff;
            border-radius: 10px;
        }
        
        .category-scroll::-webkit-scrollbar-thumb:hover {
            background: #0056b3;
        }
        
        /* Category Item Styling */
        .category-item {
            display: inline-block;
            margin: 0 10px;
            vertical-align: top;
            white-space: normal;
        }
        
        .category-link {
            display: block;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .category-box {
            background: linear-gradient(135deg, #dddddf 0%, #f4f2f7 100%);
            /* Alternative solid colors:
            background-color: #007bff;
            background-color: #28a745;
            background-color: #dc3545;
            */
            border: 2px solid #dee2e6;
            border-radius: 12px;
            padding: 20px 30px;
            min-width: 150px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        /* .category-link:hover .category-box {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.2);
            border-color: #007bff;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        }
         */
        .category-name {
            color: black;
            font-size: 16px;
            font-weight: 600;
            text-transform: capitalize;
            letter-spacing: 0.5px;
        }
        
        /* Different color variations for categories */
        /* .category-item:nth-child(odd) .category-box {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .category-item:nth-child(even) .category-box {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .category-item:nth-child(3n) .category-box {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        } */
        
        
        /* Position relative for button positioning */
        .position-relative {
            position: relative;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .category-box {
                padding: 15px 20px;
                min-width: 120px;
            }
            
            .category-name {
                font-size: 14px;
            }
            
         
        }
        
        /* Optional: Add counter for number of categories */
        .category-count {
            display: inline-block;
            font-size: 12px;
            color: rgba(255,255,255,0.8); 
            margin-top: 5px;
        }
    </style>
    


  <div class="p-2">
        <div class="row">
            <div class="col-12">
                <div class="category-slider">
                 
                      <div class="lgx-heading">
                                        <h2 class="heading">Plans</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                   
                    <!-- Scrollable Categories Container -->
                    <div class="category-scroll" id="categoryScroll">
                        <?php 
                        foreach($planAmount as $plan){
                        ?>
                                <div class="category-item">
                                    <a href="pro_by_amount.php?id=<?= $plan ?>" class="category-link">
                                        <div class="category-box">
                                            <div class="category-name">
                                               Rs . <?= htmlspecialchars($plan) ?>
                                            </div>
                                            <!-- Optional: Add category count or icon -->
                                            <!-- <div class="category-count">View All</div> -->
                                        </div>
                                    </a>
                                </div>
                          
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <div class="">
        <div class="row">
            <div class="col-12">
                <div class="category-slider">
                    
                    <div class="lgx-heading">
                                        <h2 class="heading">Categories</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                    <!-- Scrollable Categories Container -->
                    <div class="category-scroll" id="categoryScroll">
                        <?php 
                        $sql_cat = mysqli_query($con, "SELECT * FROM category ORDER BY RAND()"); 
                        if(mysqli_num_rows($sql_cat) > 0) {
                            while($row_cat = mysqli_fetch_array($sql_cat)) { ?>
                                <div class="category-item">
                                    <a href="pro_by_cat.php?id=<?= $row_cat['id'] ?>" class="category-link">
                                        <div class="category-box">
                                            <div class="category-name">
                                                <?= htmlspecialchars($row_cat['category_name']) ?>
                                            </div>
                                            <!-- Optional: Add category count or icon -->
                                            <!-- <div class="category-count">View All</div> -->
                                        </div>
                                    </a>
                                </div>
                            <?php }
                        } else { ?>
                            <div class="category-item">
                                <div class="category-box">
                                    <div class="category-name">No Categories Found</div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

        <section>
            <div>
                <div>
                    <div >
                        <div class="row " style="margin-top:200px">
                            <div class="lgx-heading">
                                        <h2 class="heading">Products</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                            <?php 
                            $sql_pro=mysqli_query($con,"SELECT * FROM product")or die('error');
                            while($row_pro=mysqli_fetch_array($sql_pro)){
                            ?>
                            <div class="col-xs-12 col-md-4">
                                <div class="card " style="background-color: rgb(160, 114, 114,0.2);;margin:10px;padding:10px" >
                                <div class="card-header text-center " style="padding: 10px;">
                                    <h3><?= $row_pro['pro_name'] ?></h3>
                                </div>
                                <div class="card-body text-center">
                                    <img src="./product_image/<?= getFirtstProImage($row_pro['pro_code'])?>" class="img-thumbnail " style="width:300px;height:400px" alt="" srcset="">
                                    <div style="font-weight: bold;">
                                        <span>MRP : <?= $row_pro['mrp'] ?></span>
                                        <span>Sell Price : <?= $row_pro['price'] ?></span>
                                    </div>
                                    <p><i><?= $row_pro['pro_desc'] ?></i></p>
                                </div>
                                <div class="card-footer mt-3 text-center">
                                    <a href="check_out.php?id=<?= $row_pro['pro_ai'] ?>" class="btn btn-success">BuyNow</a>
                                </div>
                            </div>
                            </div>
                            <?php }?>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>

    


<?php include "include/footer.php" ?>