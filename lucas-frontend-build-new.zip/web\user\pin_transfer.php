<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">E-Pin Transfer</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"  enctype="multipart/form-data">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
                                               <div class="form-group ">
							<label>My ID</label>
								<input type="text" class="form-control" name="from_id" value="<?php echo $row['user_id']?>" readonly>
							</div>
							
						
								
					 <div class="form-group  ">
					 <label>Transferd  ID</label>
						<input type="text" class="form-control" name="to_id" id="user_id" required>
					 </div>

									 <div class="form-group  ">
					 <label>Name</label>
						<input type="text" class="form-control" id="to_name"  readonly required>
					 </div> 
					 <div class="form-group  ">
					 <label>E-Pin Count</label>
						<input type="number" class="form-control" min=1 name="cnt"  required>
					 </div>
                     <div class="form-group">
                                    <label>Select Amount</label>
                                  <select name="amount" class="form-control" required>
                                  <option value="<?php echo plan_amount?>"><?php echo plan_amount?></option>
                                 
									
									
								  </select>
                                </div>
                      
					 <hr>
					 <div class="form-group text-center">
                     <button name="e_pin_transfer"  onclick="return confirm('Are You Want transfer pins?')" class="btn btn-warning btn-min-width btn-glow mr-1 mb-1">Transfer</button>
					 </div>
                                               </form>

                                               <script>
								$('#transfer_amount').keyup(function(){
                                 
									var transfer_amount=$('#transfer_amount').val();
									var tds=transfer_amount*0.03;
									var eligible_amount=transfer_amount-tds;
									$('#tds').val(tds);
									$('#eligible_amount').val(eligible_amount);
								});
								
	$("#user_id").keyup(function(){
		
            var to_id=$('#user_id').val();
              check_name(to_id);
             
            });
            
            $( document ).ready(function() {
               
                    var user_id=$('#user_id').val();
              check_name(to_id);
                });
            function check_name(to_id)
            {
                var check_user_name='';
             $.ajax({
                url : "action.php",
                type: "POST",
                chache :false,
                data:{check_user_name:check_user_name, to_id:to_id  },
                success:function(response){
            
                     $("#to_name").val(response);
                }
              });
            }
</script>
                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>