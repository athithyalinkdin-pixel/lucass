<?php include "include/header.php"?>
<?php include "include/navbar.php";

?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Deposit History</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th style="text-align:center;">S.No.</th>
                                        <th style="text-align:center;">Date</th>
                                        <th style="text-align:center;">Proof</th>
                                        <th style="text-align:center;">Ref ID</th> 
                                        <th style="text-align:center;"> Amount</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
					
                    $res_pin=mysqli_query($con,"SELECT * FROM deposit WHERE user_id='$user_id' ORDER BY ai DESC ")or die("Query error");
                    $i=1 ;
                    while($row_pin=mysqli_fetch_array($res_pin))
            {
               
            ?>
                <tr>
                    <td><?php echo $i++; ;?></td>
                    <td><?php echo date('d-m-Y',$row_pin['jdate']);?></td>
                    <td><img src="../payment_proof/<?php echo$row_pin['pic'];?>" width="300px" height="300px"></td>
                    <td><?php echo$row_pin['ref_id'];?></td>
                    <td><?php echo$row_pin['amount'];?></td>
              
                    
                </tr>
                <?php
            }
                    
                ?>
                                                                    </tbody>
                            </table>

                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>