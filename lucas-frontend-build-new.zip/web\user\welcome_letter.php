<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqprint/0.3.0/jqprint.min.js"></script>
        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-xs-12 col-md-6  " id="print">
                <div class="card  mb-2" >
                    <div class="card-header text-center">
                    <h5 class=" text-danger">CONGRATULATIONS</h5>
                    <h5 class=" text-success">REGISTRATION SUCCESSFULL</h5>
                    <h3 class=" card-title">Welcome TO <?php echo company_registerd_name?></h3>
                    <img src="../<?php echo logo?>" alt="" srcset="" width="200px">
                    </div>
                                            
                                            <div class="card-body">
                                               
                                              <table class="table table-bordered">
                                              <tr>
                                                            <th colspan=2 > <p>Welcome to the Team of <?php echo company_registerd_name?> a company that gives you
                                                            Earning Opportunity through a Wide Range of Products.</p></th>
                                                           
                                                        </tr>
                                                        <tr>
                                                            <th colspan=2 style="text-align: center;"><img src="https://png.pngtree.com/png-vector/20230928/ourmid/pngtree-young-indian-man-png-image_10149659.png" alt="" srcset="" clas="img-thumbnail" style="width:100px"></th>
                                                           
                                                        </tr>
                                                        <tr>
                                                            <th>User Id</th>
                                                            <td><?php echo $row['user_id']?></td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th>Join Date</th>
                                                            <td><?php echo  date('d-m-Y',$row['jdate'])?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Activate Date</th>
                                                            <td><?php echo $row['activate_date']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Name</th>
                                                            <td><?php echo $row['name']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Address</th>
                                                            <td><?php echo $row['address']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>City</th>
                                                            <td><?php echo $row['city']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>State</th>
                                                            <td><?php echo $row['state']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Pin Code</th>
                                                            <td><?php echo $row['pin_code']?></td>
                                                        </tr>

                                                        <tr>
                                                            <th>Sponsor Id</th>
                                                            <td><?php echo $row['sponsor_id']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Sponsor Name</th>
                                                            <td><?php echo $row_spon['name']?></td>
                                                        </tr>
                                                        <tr>
                                                            <th colspan=2 >The user Id No. and password are given here along with other details for accessing your account & any related information at our Official website www.<?php echo domain?> We suggest you to change your password immediately. for any other assistance contact us at our Email Id : <?php echo email_id?><br><br>

Once again Congratulations and Best of Luck for a long and great relation with our <?php echo company_registerd_name?> family.</th>
                                                        </tr>
                                                        <tr>
                                                            <td colspan=2 style="text-align: center;"><button type="submit" class="btn btn-danger"  onclick="window.print()"> <i class="bi bi-printer"></i> Print</button></td>
                                                        </tr>
                                              </table>
                                   
                                            </div>
                </div>

              
            </div>

          <script>
            $('#printButton').on('click', function() {
  $('#print').printThis();
});
          </script>
     


    </main><!-- End #main -->
    <?php include "include/footer.php"?>