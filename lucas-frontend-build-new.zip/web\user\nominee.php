<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->  

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-xs-12 col-md-6">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Nominee Add</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post"  enctype="multipart/form-data" >
                                            <input type="hidden" class="form-control" name="user_id" value="<?php echo$row['user_id']?>">
				
							
							<div class="form-group">
							<label>Name</label>
								<input type="text" class="form-control" name="name" required>
							</div>
							<div class="form-group">
							<label>Relation</label>
                            <select name="relationship" id="" class="form-control" required>
                                        <option value="">--SELECT--</option>
                                        <option value="Father">Father</option>
                                        <option value="Mother">Mother</option>
                                        <option value="Husband">Husband</option>
                                        <option value="Wife">Wife</option>
                                        <option value="Brother">Brother</option>
                                        <option value="Sister">Sister</option>
                                        <option value="Son">Son</option>
                                        <option value="Daughter">Daughter</option>
                                    </select>
							</div>
							<div class="form-group">
							<label>Mobile</label>
								<input type="number" class="form-control" name="mobile" required>
							</div>
							
					 <hr>
					 <div class="form-group text-center">
                     <button name="nominee_add" class="btn btn-primary">Add</button>
					 </div>
                                               </form>
                                            
                                            </div>
                </div>


            </div>

            <div class="col-xs-12 col-md-6">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">My Nominees</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table">
                            <tr>
                                <th>Sl.No</th>
                                <th>Name</th>
                                <th>Relationship</th>
                                <th>Mobile</th>
                                <th>Delete</th>
                            </tr>
                            <?php
                            $sql=mysqli_query($con,"SELECT * FROM nominee WHERE user_id='$user_id'")or die('error');
                            $i=1;
                            while($row=mysqli_fetch_array($sql)){
                                echo '<tr>';
                                echo '<td>'.$i++.'</td>';
                                echo '<td>'.$row['name'].'</td>';
                                echo '<td>'.$row['relationship'].'</td>';
                                echo '<td>'.$row['mobile'].'</td>';
                                echo '<td><form method="POST" action="action.php"><button name="delete_nominee" value="'.$row['n_ai'].'" class="btn btn-danger text-white">Delete</button></form></td>';
                                echo '</tr>';
                            }
                            ?>
                        </table>
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>