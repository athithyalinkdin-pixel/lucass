<?php 
if($_SERVER['HTTP_HOST'] == 'localhost') {
    $servername = "localhost";
    $username = "root"; 
    $password = ""; 
    $db = "lucasagronaturals"; 
} else { 
$servername = "localhost";
$username = "u411420638_ulucasagrona";
$password = "Lucasagronaturals#123"; 
$db = "u411420638_lucasagronat";
//https://auth-db786.hstgr.io/index.php?db=u411420638_lucasagronat
}
$con = mysqli_connect($servername, $username, $password,$db);
 
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
} 

date_default_timezone_set('Asia/Kolkata');
$strtime=strtotime("now") ;
$row_admin=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `admin`"));
$planAmount=[500,1000,2500,5000,10000,25000,50000,100000,250000,500000];

define("company_name", "Lucasagronaturals");
define("domain", "lucasagronaturals.com");
define("email_id", "lucasagronaturalsmedia@gmail.com");
define("user_name", "LAN".rand(11111,99999).mysqli_num_rows(mysqli_query($con,"SELECT * FROM reg")));
define("primary_id", "LAN123123");
define("url", "https://".domain);
define("address", "");
define("mobile", "987654312");
define("logo", "assets/logo.png");
define("fevi", "assets/logo.png");

define("currency", "&#8377;");
define("color1", "#018188");
define("color2", "#14696E");
define("color3", "#14696E");



?>

