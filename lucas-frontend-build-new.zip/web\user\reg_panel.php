<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title --> 
 
        <section class="section ">
            <div class="row"> 
                <!-- Left side columns --> 
                <div class="col-lg-12">
                <div class="card  mb-2 shadow">
                    <div class="card-header">
                    <h5 class=" card-title">Register</h5>
                    </div>
                                            
                                            <div class="card-body">

                                               <form action="action.php" method="post">
                                               <input type="hidden" name="activator_id" value="<?php echo $user_id?>"  >
                                               <div class="form-group">
							<label>Referral ID</label>
								<input type="text" class="form-control" id="s_id" name="s_id" required>
							</div>
							<div class="form-group">
							<label>Referral Name</label>
								<input type="text" class="form-control" id="to_name"  readonly>
							</div>
							<!-- <div class="form-group">
							<label>Purchase Wallet <a href="pin_request.php">Purchase Wallet</a></label>
								<input type="text" class="form-control" name="purchase_wallet" value="<?php echo $row['purchase_wallet']?>" readonly>
							</div> -->
					 <div class="form-group">
					 <label>Name</label>
						<input type="text" class="form-control"  name="name" required>
					 </div>

									 <div class="form-group">
					 <label>Mobile</label>
						<input type="text" class="form-control" name="mobile" required>
					 </div> 
					 <div class="form-group">
					 <label>Mail Id</label>
						<input type="email" class="form-control" name="mail" required>
					 </div> 
					
					 
					 <div class="form-group">
					 <label>Password</label>
						<input type="text" class="form-control" name="password" required>
					 </div>
					 <div class="form-group">
					 <label>Position</label>
						<select name="pos" id="" class="form-control" required>
							<option value="">--SELECT--</option>
							<option value="1">LEFT</option>
							<option value="2">RIGHT</option>
						</select>
					 </div>
			
					
                     <!-- <div class="form-group">
							<label>SELECT Pin <a href="pin_request.php">Purchase Pin</a></label>
								<select name="pin" id="pin" class="form-control"   required>
									<option value="">--SELECT Pin--</option>
									<?php
									$res_pin=mysqli_query($con,"SELECT * FROM pin WHERE u_id='$user_id' AND status=0 ")or die("Query error");
									
									while($row_pin=mysqli_fetch_array($res_pin))
									{ 
									?>
									<option value="<?php echo $row_pin['pin'] ?>"><?php echo $row_pin['pin'] ?></option>
									<?php
									}
									?>
								</select>
							</div>
							<div class="form-group"> 
							<label>E-Pin Value</label>
								<input type="text" class="form-control" name="plan_amount" id="pin_value" readonly required>
							</div> -->
                    <div class="card-footer">
					 <div class="form-group text-center">
					<button name="user_registration" class="btn btn-primary btn-lg">Register</button>
					 </div>
                     </div> 
                                               </form> 
                                               <script>
							$("#s_id").keyup(function(){
			
			var to_id=$('#s_id').val();
			  check_name(to_id);
			 
			});

			function check_name(to_id)
					{
						var check_user_name='';
					 $.ajax({
						url : "action.php",
						type: "POST",
						chache :false,
						data:{check_user_name:check_user_name, to_id:to_id  },
						success:function(response){
					var data=JSON.parse(response);
							 $("#to_name").val(data.name);
						}
					  });
					}
			

$('#pin').change(function () {
							 var pin=$('#pin').val();
									var check_pin_value='';
								$.ajax({
										url : "action.php",
										type: "POST",
										chache :false,
										data:{check_pin_value:check_pin_value, pin:pin  },
										success:function(response){
											 document.getElementById("pin_value").value = response;
										
										}
									  }); 
						});
</script>
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>