<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb"> 
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Wallet Withdraw</h5>
                    </div>
                                             
                                            <div class="card-body">

                                            <form action="action.php" method="post">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
                                               <div class="form-group">
							<label>Wallet Balance</label>  
								<input type="text" value="<?php echo $row['wallet'];?>" name="wallet" class="form-control" readonly>
							</div>
							 <div class="form-group">
							<label>Enter Withdraw Amount</label>
								<input type="number" name="withdraw_amount" min=100 id="amount" class="form-control" >
							</div>
							<div class="form-group"> 
							<label>Admin 5%</label>
								<input type="text" name="tds" id="tds" class="form-control" readonly>
							</div>
							<div class="form-group"> 
							<label>Net Amount</label>
								<input type="text" name="eligible_amount" id="eligible_amount" class="form-control" readonly>
							</div>
                           
					 <hr>
					 <div class="form-group text-center">
                     <button  name="withdraw"  class="btn btn-primary" >Withdraw</button>
					 </div>
                                               </form>
                                               <script> 
								$('#amount').keyup(function(){
									var amount=$('#amount').val();
									var tds=amount*5/100;
									var eligible_amount=amount-tds;
									$('#tds').val(tds);
									$('#eligible_amount').val(eligible_amount);
								});
								</script>
                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>