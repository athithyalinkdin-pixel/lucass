<?php include "include/header.php" ?>
<?php include "include/navbar.php" ?>

 <!--SLIDER-->
 <section>
            <div class="lgx-slider">
                <!--lgx-slider-content -->
                <div class="lgx-banner-style">
                    <div class="lgx-inner">

                        <div id="lgx-main-slider" class="owl-carousel">

                            <!--SLIDER ITEM 1-->

                            <div class="lgx-item-common">
                                <div class="slider-text-single">
                                    <figure>
                                        <img src="assets/img/slider6.png" alt="slide" />
                                        <figcaption>
                                            <div class="lgx-container">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <!--All Animation class-->
                                                        <!--lgx-fadeIn lgx-fadeInDown lgx-fadeInDownBig lgx-fadeInLeft lgx-fadeInLeftBig lgx-fadeInRight lgx-fadeInRightBig lgx-fadeInUp lgx-fadeInUpBig
                                                    lgx-flipInX lgx-flipInY lgx-lightSpeedIn lgx-rotateIn lgx-rotateInDownLeft lgx-rotateInDownRight lgx-rotateInUpLeft lgx-rotateInUpRight lgx-slideInLeft
                                                    lgx-slideInRight lgx-bounceIn lgx-bounceInDown lgx-bounceInLeft lgx-bounceInRight lgx-bounceInUp lgx-zoomIn lgx-zoomInDown lgx-zoomInLeft
                                                    lgx-zoomInRight lgx-zoomInUp-->
                                                        <div class="lgx-banner-info">
                                                            <!--lgx-banner-info-center lgx-banner-info-black lgx-banner-info-big lgx-banner-info-bg-->
                                                            <h3 class="subtitle lgx-delay lgx-fadeInDown">Welcome to </h3>
                                                            <h2 class="title lgx-delay lgx-fadeInDown"><?php echo company_name?></h2>
                                                           
                                                            <div class="action-area lgx-delay lgx-fadeInDown">
                                                                <div class="lgx-video-area">
                                                                    <a class="lgx-btn lgx-btn-red" href="user/reg.php">Register Free</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                            <!--SLIDER ITEM 1 End-->

                            <!--SLIDER ITEM 2-->
                            <div class="lgx-item-common">
                                <div class="slider-text-single">
                                    <figure>
                                        <img src="assets/img/slider4.png" alt="slide" />
                                        <figcaption>
                                            <div class="lgx-container">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <!--All Animation class-->
                                                        <!--lgx-fadeIn lgx-fadeInDown lgx-fadeInDownBig lgx-fadeInLeft lgx-fadeInLeftBig lgx-fadeInRight lgx-fadeInRightBig lgx-fadeInUp lgx-fadeInUpBig
                                                    lgx-flipInX lgx-flipInY lgx-lightSpeedIn lgx-rotateIn lgx-rotateInDownLeft lgx-rotateInDownRight lgx-rotateInUpLeft lgx-rotateInUpRight lgx-slideInLeft
                                                    lgx-slideInRight lgx-bounceIn lgx-bounceInDown lgx-bounceInLeft lgx-bounceInRight lgx-bounceInUp lgx-zoomIn lgx-zoomInDown lgx-zoomInLeft
                                                    lgx-zoomInRight lgx-zoomInUp-->
                                                        <div class="lgx-banner-info">
                                                            <!--lgx-banner-info-center lgx-banner-info-black lgx-banner-info-big lgx-banner-info-bg-->
                                                            <h3 class="subtitle lgx-delay lgx-fadeInDown">Welcome to </h3>
                                                            <h2 class="title lgx-delay lgx-fadeInDown"><?php echo company_name?></h2>
                                                           
                                                            <div class="action-area lgx-delay lgx-fadeInDown">
                                                                <div class="lgx-video-area">
                                                                    <a class="lgx-btn lgx-btn-red" href="user/reg.php">Register Free</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                            <!--SLIDER ITEM 2 End-->

                            <!--SLIDER ITEM 3-->
                            <div class="lgx-item-common">
                                <div class="slider-text-single">
                                    <figure>
                                        <img src="assets/img/slider7.png" alt="slide" />
                                        <figcaption>
                                            <div class="lgx-container">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <!--All Animation class-->
                                                        <!--lgx-fadeIn lgx-fadeInDown lgx-fadeInDownBig lgx-fadeInLeft lgx-fadeInLeftBig lgx-fadeInRight lgx-fadeInRightBig lgx-fadeInUp lgx-fadeInUpBig
                                                    lgx-flipInX lgx-flipInY lgx-lightSpeedIn lgx-rotateIn lgx-rotateInDownLeft lgx-rotateInDownRight lgx-rotateInUpLeft lgx-rotateInUpRight lgx-slideInLeft
                                                    lgx-slideInRight lgx-bounceIn lgx-bounceInDown lgx-bounceInLeft lgx-bounceInRight lgx-bounceInUp lgx-zoomIn lgx-zoomInDown lgx-zoomInLeft
                                                    lgx-zoomInRight lgx-zoomInUp-->
                                                        <div class="lgx-banner-info">
                                                            <!--lgx-banner-info-center lgx-banner-info-black lgx-banner-info-big lgx-banner-info-bg-->
                                                            <h3 class="subtitle lgx-delay lgx-fadeInDown">Welcome to </h3>
                                                            <h2 class="title lgx-delay lgx-fadeInDown"><?php echo company_name?></h2>
                                                           
                                                            <div class="action-area lgx-delay lgx-fadeInDown">
                                                                <div class="lgx-video-area">
                                                                    <a class="lgx-btn lgx-btn-red" href="user/reg.php">Register Free</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                </div>
                            </div>
                            <!--SLIDER ITEM 3 End-->

                        </div>
                        <!--//.lgx-main-slider-->


                        <!-- //.CONTAINER -->
                    </div>
                    <!-- //.INNER -->
                </div>
            </div>
        </section>
        <!--SLIDER END-->

        <section>
            <div id="lgx-about" class="lgx-about">
                <div class="lgx-inner">
                    <div class="container" >
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="lgx-about-content-area">
                                    <div class="lgx-heading" id="about">
                                        <h2 class="heading">About Us</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                                    <div class="lgx-about-content">
                                        <p class="text">MI PROFIT SHARE 
                                        is a transformative and innovative company operating in the field of direct selling and marketing.  Our company specializes in business modeling.   Based on the principles of integrity, transparency and empowerment, we strive to revolutionize business for the better in the way of individuals and communities.</p>
                                        <div class="section-btn-area">
                                            <a class="lgx-btn" href="user/reg.php">Register</a>
                                            <a class="lgx-btn lgx-btn-red lgx-scroll" href="./assets/WonderzWay.pdf" download="">Plan</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="lgx-registration-form-box lgx-about-registration-box">
                                    <h3 class="title">Login</h3>
                                    <div class="lgx-registration-form">
                                        <form action="user/action.php" method="post">
                                        <input name="u_id"  class="wpcf7-form-control form-control" placeholder="Your User id" type="text" fdprocessedid="u6gt59">
                                        <input name="pass"  class="wpcf7-form-control form-control" placeholder="Your Passowrd" type="password" fdprocessedid="m5goyq">
                                       
                                      
                                        <input value="Login" class="wpcf7-form-control wpcf7-submit lgx-submit" type="submit" name="login" fdprocessedid="poa9fc">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>
        <section>
                <style>
        /* Category Slider Container */
        .category-slider {
            background-color: #f8f9fa;  /* Background color */
            padding: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);  /* Box shadow */
        }
        
        /* Scrollable Container */
        .category-scroll {
            overflow-x: auto;
            overflow-y: hidden;
            white-space: nowrap;
            scroll-behavior: smooth;
            padding: 15px 0;
            cursor: grab;
            scrollbar-width: thin;  /* For Firefox */
            scrollbar-color: #007bff #e9ecef;  /* For Firefox */
        }
        
        .category-scroll:active {
            cursor: grabbing;
        }
        
        /* Custom Scrollbar for Webkit browsers (Chrome, Safari, Edge) */
        .category-scroll::-webkit-scrollbar {
            height: 8px;
        }
        
        .category-scroll::-webkit-scrollbar-track {
            background: #e9ecef;
            border-radius: 10px;
        }
        
        .category-scroll::-webkit-scrollbar-thumb {
            background: #007bff;
            border-radius: 10px;
        }
        
        .category-scroll::-webkit-scrollbar-thumb:hover {
            background: #0056b3;
        }
        
        /* Category Item Styling */
        .category-item {
            display: inline-block;
            margin: 0 10px;
            vertical-align: top;
            white-space: normal;
        }
        
        .category-link {
            display: block;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .category-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            /* Alternative solid colors:
            background-color: #007bff;
            background-color: #28a745;
            background-color: #dc3545;
            */
            border: 2px solid #dee2e6;
            border-radius: 12px;
            padding: 20px 30px;
            min-width: 150px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .category-link:hover .category-box {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.2);
            border-color: #007bff;
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        }
        
        .category-name {
            color: white;
            font-size: 16px;
            font-weight: 600;
            text-transform: capitalize;
            letter-spacing: 0.5px;
        }
        
        /* Different color variations for categories */
        .category-item:nth-child(odd) .category-box {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .category-item:nth-child(even) .category-box {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .category-item:nth-child(3n) .category-box {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }
        
        
        /* Position relative for button positioning */
        .position-relative {
            position: relative;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .category-box {
                padding: 15px 20px;
                min-width: 120px;
            }
            
            .category-name {
                font-size: 14px;
            }
            
         
        }
        
        /* Optional: Add counter for number of categories */
        .category-count {
            display: inline-block;
            font-size: 12px;
            color: rgba(255,255,255,0.8); 
            margin-top: 5px;
        }
    </style>


        </section>

                <section>
            <div id="lgx-about" class="lgx-about">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="lgx-heading">
                                        <h2 class="heading">Packages</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                        <div class="row">
                            <?php 
                        foreach($planAmount as $plan){
                        ?>
                          <div class="col-xs-6 col-md-4">
                            <a href="pro_by_amount.php?id=<?= $plan ?>"><img src="./assets/<?= $plan ?>.jpeg" class="img-thumbnail " style="margin-top:5px" alt="" srcset=""></a>
                                    
                          </div>
                           <?php } ?>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>

        <section>
            <div id="lgx-about" class="lgx-about">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                             <img src="https://cdn.pixabay.com/photo/2015/07/17/22/43/student-849822_1280.jpg" class="img-thumbnail" alt="" srcset="">
                            </div>
                            <div class="col-sm-12 col-md-6">
                            <div class="lgx-about-content-area">
                                    <div class="lgx-heading">
                                        <h2 class="heading">VISION</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                                    <div class="lgx-about-content">
                                        <p class="text">Our vission is to become a global leader in the direct selling industry through our company, our unwavering commitment to empowering individuals with their financial and lifestyle economic growth. Our mission is to make business transactions easy and accessible to all entrepreneurs.  Every member of our organization has the tools, resources and support they need to realize their dreams.  Through our innovative approach to business and our relentless pursuit of excellence, we aim to inspire positive change and create lasting impact globally..</p>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>

        <section>
            <div id="lgx-about" class="lgx-about">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            
                            <div class="col-sm-12 col-md-6">
                            <div class="lgx-about-content-area">
                                    <div class="lgx-heading">
                                        <h2 class="heading">MISSION</h2>
                                        <h3 class="subheading"><?php echo company_name?></h3>
                                    </div>
                                    <div class="lgx-about-content">
                                        <p class="text">Our mission at Profitability is to empower individuals to take control of their future through our business opportunity.   We are committed to providing our independent distributors with best-in-class products, state-of-the-art training and unparalleled support, helping them build successful businesses and achieve financial independence.   We strive to foster a culture of collaboration, respect and integrity where our business associates feel that each member is valued and empowered to reach their full potential.   We aim to make a difference in the lives of our distributors, customers and communities around the world by fostering sustainable growth and fostering meaningful relationships.</p>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                             <img src="https://cdn.pixabay.com/photo/2018/03/03/20/02/laptop-3196481_1280.jpg" class="img-thumbnail" alt="" srcset="">
                            </div>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>



        <!--VIDEO
        <section>
            <div id="lgx-video" class="lgx-video lgx-video2">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                               -<h2 class="lgx-video-title"><span>Watch Our Promo video!</span>How to make an online order</h2>
                                <div class="lgx-video-area">
                                    <figure>
                                        <figcaption>
                                            <div class="video-icon">
                                                <div class="lgx-vertical">
                                                    <a id="myModalLabel" class="icon" href="#" data-toggle="modal" data-target="#lgx-modal">
                                                <i class="fa fa-play " aria-hidden="true"></i>
                                            </a>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                  
                                    <div id="lgx-modal" class="modal fade lgx-modal" wfd-invisible="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                </div>
                                                <div class="modal-body">
                                                    <iframe id="modalvideo" src="" allowfullscreen=""></iframe>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
             
            </div>
        </section>
      //.VIDEO END-->


        <!--SCHEDULE
        <section>
            <div id="lgx-schedule" class="lgx-schedule lgx-schedule2 lgx-schedule-white">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-heading">
                                    <h2 class="heading">Event Schedule</h2>
                                    <h3 class="subheading">Welcome to the dedicated to building remarkable Schedule!</h3>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-tab lgx-tab2">
                                 
                                    <ul class="nav nav-pills lgx-nav lgx-nav-nogap">
                                       
                                        <li class="active">
                                            <a data-toggle="pill" href="#home">
                                                <h3>First <span>Day</span></h3>
                                                <p><span>29 </span>Nov, 2019</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a data-toggle="pill" href="#menu1">
                                                <h3>Second <span>Day</span></h3>
                                                <p><span>28 </span>Jul, 2019</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a data-toggle="pill" href="#menu2">
                                                <h3>Third <span>Day</span></h3>
                                                <p><span>29 </span>Nov, 2019</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a data-toggle="pill" href="#menu3">
                                                <h3>Fourth <span>Day</span></h3>
                                                <p><span>30 </span>Dec, 2019</p>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tab-content lgx-tab-content">


                                        <div id="home" class="tab-pane fade in active">

                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingOne">
                                                        <div class="panel-title">
                                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker1.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Wait is Over! Stony Brook Captures Conference</h3>
                                                                        <h4 class="author-info">By <span>Riaz Sagar</span> , Logichunt Inc.</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingTwo">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker2.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">10:30 <span>Am</span> - 11.30 <span>Am</span></h4>
                                                                        <h3 class="title">Team With At Least Three Conference Titles</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingThree">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author author-multi">
                                                                        <img src="assets/img/speaker1.jpg" alt="Speaker" />
                                                                        <img src="assets/img/speaker2.jpg" alt="Speaker" />
                                                                        <img src="assets/img/speaker3.jpg" alt="Speaker" />
                                                                        <img src="assets/img/speaker4.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">11:30 <span>Am</span> - 01.30 <span>Pm</span></h4>
                                                                        <h3 class="title">Building an Awesome Community on Your Website</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , <span>Riaz Sagar</span> & <span>Devid Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingfour">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsefour" aria-expanded="true" aria-controls="collapsefour">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker4.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">02:00 <span>Am</span> - 03.30 <span>Pm</span></h4>
                                                                        <h3 class="title">Hungry Shawnee boys soccer team eyeing conference, sectional title in 2019</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapsefour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingfive">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsefive" aria-expanded="true" aria-controls="collapsefive">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker5.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">03:45 <span>Am</span> - 04.00 <span>Pm</span></h4>
                                                                        <h3 class="title">Business World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapsefive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                        <div id="menu1" class="tab-pane fade">

                                            <div class="panel-group" id="accordion2" role="tablist" aria-multiselectable="true">
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingOne2">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne2" aria-expanded="true" aria-controls="collapseOne2">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author author-multi">
                                                                        <img src="assets/img/speaker1.jpg" alt="Speaker" />
                                                                        <img src="assets/img/speaker2.jpg" alt="Speaker" />
                                                                        <img src="assets/img/speaker3.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">The Wait is Over! Stony Brook Captures First Conference Title</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , <span>Riaz Sagar</span> & <span>Devid Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseOne2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingTwo2">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo2" aria-expanded="true" aria-controls="collapseTwo2">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker4.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseTwo2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingThree2">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree2" aria-expanded="true" aria-controls="collapseThree2">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker5.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseThree2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                        <div id="menu2" class="tab-pane fade">

                                            <div class="panel-group" id="accordion3" role="tablist" aria-multiselectable="true">
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingOne3">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion3" href="#collapseOne3" aria-expanded="true" aria-controls="collapseOne3">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker1.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseOne3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingTwo3">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion3" href="#collapseTwo3" aria-expanded="true" aria-controls="collapseTwo3">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker2.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseTwo3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingThree3">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion3" href="#collapseThree3" aria-expanded="true" aria-controls="collapseThree3">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker3.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseThree3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>


                                        <div id="menu3" class="tab-pane fade">

                                            <div class="panel-group" id="accordion4" role="tablist" aria-multiselectable="true">
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingOne4">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion4" href="#collapseOne4" aria-expanded="true" aria-controls="collapseOne4">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker2.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseOne4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne4">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingTwo4">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion4" href="#collapseTwo4" aria-expanded="true" aria-controls="collapseTwo4">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker1.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseTwo4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo4">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default lgx-panel">
                                                    <div class="panel-heading" role="tab" id="headingThree4">
                                                        <div class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion4" href="#collapseThree4" aria-expanded="true" aria-controls="collapseThree4">
                                                                <div class="lgx-single-schedule">
                                                                    <div class="author">
                                                                        <img src="assets/img/speaker4.jpg" alt="Speaker" />
                                                                    </div>
                                                                    <div class="schedule-info">
                                                                        <h4 class="time">09:00 <span>Am</span> - 10.30 <span>Am</span></h4>
                                                                        <h3 class="title">Digital World Event Introduction</h3>
                                                                        <h4 class="author-info">By <span>Joanna Smith</span> , Design Apple</h4>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div id="collapseThree4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree4">
                                                        <div class="panel-body">
                                                            <p class="text">
                                                                Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse flexitarian Truffaut synth art party deep v chillwave.
                                                            </p>
                                                            <h4 class="location"><strong>Location:</strong> Hall 1, Building A , Golden Street , <span>Southafrica</span> </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                 
                </div>
              
            </div>
        </section>
    SCHEDULE END-->


        <!--SPONSORED
        <section>
            <div id="lgx-sponsors" class="lgx-sponsors lgx-sponsors-black">
                <div class="lgx-inner-bg">
                    <div class="lgx-inner">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="lgx-heading lgx-heading-white">
                                        <h2 class="heading">Offcial Sponsonrs</h2>
                                        <h3 class="subheading">Welcome to the dedicated to building remarkable Sponsores!</h3>
                                    </div>
                                </div>
                            </div>
                         
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="sponsors-area sponsors-area-colorfull-border">
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor-sp3.png" alt="sponsor"></a>
                                        </div>
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor2.png" alt="sponsor"></a>
                                        </div>
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor-sp1.png" alt="sponsor"></a>
                                        </div>
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor5.png" alt="sponsor"></a>
                                        </div>
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor1.png" alt="sponsor"></a>
                                        </div>
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor3.png" alt="sponsor"></a>
                                        </div>
                                        <div class="single">
                                            <a class="" href="#"><img src="assets/img/sponsors/sponsor4.png" alt="sponsor"></a>
                                        </div>
                                    </div>
                                </div>
                             
                            </div>
                            <div class="section-btn-area sponsor-btn-area">
                                <a class="lgx-btn" href="#">Become A Sponsor</a>
                            </div>
                        </div>
                      
                    </div>
                </div>
                
            </div>
        </section>
       SPONSORED END-->





        <!--REGISTRATION
        <section>
            <div id="lgx-registration" class="lgx-registration">
              
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-registration-area lgx-registration-area2">
                                  
                                    <div class="lgx-single-registration">
                                        <div class="lgx-single-registration-inner">
                                            <a class="icon" href="#"><img src="assets/img/icons/4.png" alt="ticket"/></a>
                                            <div class="single-top">
                                                <h3 class="title">Personal</h3>
                                                <h4 class="price"><i>$</i>59</h4>
                                            </div>
                                            <div class="single-bottom">
                                                <ul class="list-unstyled list">
                                                    <li>Regular Seating</li>
                                                    <li>Comfortable Seat</li>
                                                    <li>Coffee Break</li>
                                                    <li>One Workshop</li>
                                                    <li>Certificate</li>
                                                </ul>
                                                <a class="lgx-btn" href="#"><span>Buy Ticket</span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="lgx-single-registration recommended">
                                        <div class="lgx-single-registration-inner">
                                            <a class="icon" href="#"><img src="assets/img/icons/3.png" alt="ticket"/></a>
                                            <div class="single-top">
                                                <h3 class="title">Business</h3>
                                                <h4 class="price"><i>$</i>89</h4>
                                            </div>
                                            <div class="single-bottom">
                                                <ul class="list-unstyled list">
                                                    <li>Regular Seating</li>
                                                    <li>Comfortable Seat</li>
                                                    <li>Coffee Break</li>
                                                    <li>One Workshop</li>
                                                    <li>Certificate</li>
                                                </ul>
                                                <a class="lgx-btn" href="#"><span>Buy Ticket</span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="lgx-single-registration">
                                        <div class="lgx-single-registration-inner">
                                            <a class="icon" href="#"><img src="assets/img/icons/2.png" alt="ticket"/></a>
                                            <div class="single-top">
                                                <h3 class="title">Premium</h3>
                                                <h4 class="price"><i>$</i>99</h4>
                                            </div>
                                            <div class="single-bottom">
                                                <ul class="list-unstyled list">
                                                    <li>Regular Seating</li>
                                                    <li>Comfortable Seat</li>
                                                    <li>Coffee Break</li>
                                                    <li>One Workshop</li>
                                                    <li>Certificate</li>
                                                </ul>
                                                <a class="lgx-btn" href="#"><span>Buy Ticket</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                </div>
              
            </div>
        </section>
        REGISTRATION END-->


        <!--PHOTO GALLERY
        <section>
            <div id="lgx-gallery" class="lgx-gallery-popup lgx-photo-gallery-normal lgx-photo-gallery-black">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-heading lgx-heading-white">
                                    <h2 class="heading">Photo Gallery</h2>
                                    <h3 class="subheading">Welcome to the dedicated to building remarkable Sponsores!</h3>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-gallery-area">
                                    <div class="lgx-gallery-single">
                                        <figure>
                                            <img title="Memories One" src="assets/img/gallery/gallery4.jpg" alt="Memories one">
                                            <figcaption class="lgx-figcaption">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <a title="Memories One" href="assets/img/gallery/gallery4.jpg">
                                                        <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                                    </a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                   
                                    <div class="lgx-gallery-single">
                                        <figure>
                                            <img src="assets/img/gallery/gallery2.jpg" alt="Memories Two" title="Memories Two">
                                            <figcaption class="lgx-figcaption">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <a title="Memories Two" href="assets/img/gallery/gallery2.jpg">
                                                        <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                                    </a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    
                                    <div class="lgx-gallery-single">
                                        <figure>
                                            <img src="assets/img/gallery/gallery3.jpg" alt="Memories Three" title="Memories Three">
                                            <figcaption class="lgx-figcaption">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <a title="Memories Three" href="assets/img/gallery/gallery3.jpg">
                                                        <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                                    </a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                   
                                    <div class="lgx-gallery-single">
                                        <figure>
                                            <img src="assets/img/gallery/gallery4.jpg" alt="Memories Four" title="Memories Four">
                                            <figcaption class="lgx-figcaption">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <a title="Memories Four" href="assets/img/gallery/gallery4.jpg">
                                                        <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                                    </a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                   
                                    <div class="lgx-gallery-single">
                                        <figure>
                                            <img src="assets/img/gallery/gallery5.jpg" alt="Memories Five" title="Memories Five">
                                            <figcaption class="lgx-figcaption">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <a title="Memories Five" href="assets/img/gallery/gallery5.jpg">
                                                        <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                                    </a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                   
                                    <div class="lgx-gallery-single">
                                        <figure>
                                            <img src="assets/img/gallery/gallery6.jpg" alt="Memories Six" title="Memories Six">
                                            <figcaption class="lgx-figcaption">
                                                <div class="lgx-hover-link">
                                                    <div class="lgx-vertical">
                                                        <a title="Memories Six" href="assets/img/gallery/gallery6.jpg">
                                                        <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                                    </a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                   

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
       PHOTO GALLERY END-->


        <!--News
        <section>
            <div id="lgx-news" class="lgx-news">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-heading">
                                    <h2 class="heading">From Our Blog</h2>
                                    <h3 class="subheading">Conferences dedicated to building remarkable events.</h3>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-4">
                                <div class="lgx-single-news">
                                    <figure>
                                        <a href="news-single.html"><img src="assets/img/news/news1.jpg" alt=""></a>
                                    </figure>
                                    <div class="single-news-info">
                                        <div class="meta-wrapper">
                                            <span>April 25, 2021</span>
                                            <span>by <a href="#">Riazsagar</a></span>
                                            <span><a href="#">Design</a></span>
                                        </div>
                                        <h3 class="title"><a href="news-single.html">Brooklyn Beta was the most important conferen best tristique</a></h3>
                                        <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-4">
                                <div class="lgx-single-news">
                                    <figure>
                                        <a href="news-single.html"><img src="assets/img/news/news3.jpg" alt=""></a>
                                    </figure>
                                    <div class="single-news-info">
                                        <div class="meta-wrapper">
                                            <span>April 25, 2021</span>
                                            <span>by <a href="#">Riazsagar</a></span>
                                            <span><a href="#">Design</a></span>
                                        </div>
                                        <h3 class="title"><a href="news-single.html">Brooklyn Beta was the most important conferen best tristique</a></h3>
                                        <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-4">
                                <div class="lgx-single-news">
                                    <figure>
                                        <a href="news-single.html"><img src="assets/img/news/news2.jpg" alt=""></a>
                                    </figure>
                                    <div class="single-news-info">
                                        <div class="meta-wrapper">
                                            <span>April 25, 2021</span>
                                            <span>by <a href="#">Riazsagar</a></span>
                                            <span><a href="#">Design</a></span>
                                        </div>
                                        <h3 class="title"><a href="news-single.html">Brooklyn Beta was the most important conferen best tristique</a></h3>
                                        <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="section-btn-area">
                            <a class="lgx-btn" href="news.html">View More Blogs</a>
                        </div>
                    </div>
                   
                </div>
               
            </div>
        </section>
        -News END-->



        <!--TRAVEL INFO-->
        <section>
            <div id="lgx-travelinfo" class="lgx-travelinfo">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-heading">
                                    <h2 class="heading">Contact Us</h2>
                                    <h3 class="subheading">For more Infomation.</h3>
                                </div>
                            </div>
                            <!--//main COL-->
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-travelinfo-content">
                                    <div class="lgx-travelinfo-single">
                                        <img src="assets/img/info-icon1.png" alt="location" />
                                        <h3 class="title">Venue</h3>
                                        <p class="info">Docklands Convention Centre 58 Wurundjeri Way Dablin, 3000</p>
                                    </div>
                                    <div class="lgx-travelinfo-single">
                                        <img src="assets/img/info-icon2.png" alt="Transport" />
                                        <h3 class="title">Transport</h3>
                                        <p class="info">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do incididunt</p>
                                    </div>
                                    <div class="lgx-travelinfo-single">
                                        <img src="assets/img/info-icon3.png" alt="Hotel & Restaurant" />
                                        <h3 class="title">Hotel & Restaurant</h3>
                                        <p class="info">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do incididunt</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--//.ROW-->
                    </div>
                    <!-- //.CONTAINER -->
                </div>
            </div>
        </section>
        <!--TRAVEL INFO END-->




        <!--VIDEO-->
        <section>
            <div id="lgx-video" class="lgx-video">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <!--<h2 class="lgx-video-title"><span>Watch Our Promo video!</span>How to make an online order</h2>-->
                                <div class="lgx-video-area">
                                    <figure>
                                        <figcaption>
                                            <div class="video-icon">
                                                <div class="lgx-vertical">
                                                    <a id="myModalLabel" class="icon" href="#" data-toggle="modal" data-target="#lgx-modal">
                                                <i class="fa fa-play " aria-hidden="true"></i>
                                            </a>
                                                </div>
                                            </div>
                                        </figcaption>
                                    </figure>
                                    <!-- Modal-->
                                    <div id="lgx-modal" class="modal fade lgx-modal">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                </div>
                                                <div class="modal-body">
                                                    <iframe id="modalvideo" src="https://www.youtube.com/embed/oSPR5Go05Vg" allowfullscreen></iframe>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //.Modal-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>
        <!--//.VIDEO END-->
        <section>
            <div class="lgx-inner" id="lgx-contact">
                <div class="container" id="contact">
                    <div class="row">
                        
                        <div class="col-sm-12 col-md-6 " style=" padding:20px 10px;border-radius:10px;background-color:darkgray"> 
                        <div class="lgx-heading" >
                                <h2 class="heading">GET IN TOUCH</h2>
                            </div>

                            <form method="POST" class="lgx-contactform" action="user/action">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control lgxname" placeholder="Enter Your Name" required>
                                </div>

                                <div class="form-group">
                                    <input type="email" name="Mail" class="form-control lgxemail" id="lgxemail" placeholder="Enter email" required>
                                </div>

                                <div class="form-group">
                                    <input type="text" name="mobile" class="form-control lgxsubject" id="lgxsubject" placeholder="Subject" required>
                                </div>

                                <div class="form-group">
                                    <textarea class="form-control lgxmessage" name="message" id="lgxmessage" rows="5" placeholder="We expect drop some line from you..." required></textarea>
                                </div>


                                <button name="contact_us" value="contact-form" class="lgx-btn hvr-glow hvr-radial-out lgxsend lgx-send"><span>Send Massage</span></button>
                            </form>

                            <!-- MODAL SECTION -->
                      
                            <!-- //MODAL -->

                        </div>
                        <div class="col-sm-12 col-md-6 ">
                    
                      <img src="https://cdn.pixabay.com/photo/2018/10/10/20/44/team-3738261_1280.jpg" alt="" srcset="" class="img-thumbnail">
                        </div>
                        <!--//.COL-->
                    </div>
                </div>
                <!-- //.CONTAINER -->
            </div>
        </section>
        <!--News END-->

<?php include "include/footer.php" ?>