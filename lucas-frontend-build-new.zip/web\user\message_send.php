<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Send Message</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <form action="action.php" method="post">
                                               <input type="hidden" name="user_id" value="<?php echo $user_id?>"  >
											   <div class="box-body">

<div class="form-group">
								<input type="text" class="form-control" placeholder="Subject" name="subject" required>
							</div>
							<div class="form-group">
								<textarea  class="form-control" placeholder="Message" name="message"></textarea>								</div>
                    
                      
					 <hr>
					 <div class="form-group text-center">
					 <button name="send_message" class="btn btn-success">Send</button>
					 </div>
                                               </form>
                                            
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>