
    <!-- ======= Footer ======= -->
    <style>
    .bottomright {
        position: absolute;
        position: fixed;
        bottom: 75px;
        right: 16px;
        font-size: 15px;
    }
    .bottomright a {
        padding: 5px;
        border-radius: 10px;
        background-color: #4154f1;
        color: white;
    }

</style>
<div class="bottomright">
    <a href="mailto:<?php echo email_id?>?subject=REPORT">REPORT</a>
</div>

<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span><?php echo date("Y")?></span></strong> <?php echo company_name?> reserved
    </div>
    <div class="credits">
        <a href="#"><i style="font-size: 20px; padding-right:5px;" class="bi bi-instagram"></i></a>
        <a href="#"><i style="font-size: 20px; padding-right:5px;" class="bi bi-facebook"></i></a>
        <a href="#"><i style="font-size: 20px; padding-right:5px;" class="bi bi-telegram"></i></a>
        <a href="#"><i style="font-size: 20px;" class="bi bi-youtube"></i></a>
    </div>
</footer><!-- End Footer -->
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/chart.js/chart.min.js"></script>
<script src="assets/vendor/echarts/echarts.min.js"></script>
<script src="assets/vendor/quill/quill.min.js"></script>
<script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
<script src="assets/vendor/tinymce/tinymce.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
</body>

</html>