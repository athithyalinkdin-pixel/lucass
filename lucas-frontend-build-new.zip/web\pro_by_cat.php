<?php include "include/header.php" ?>
<?php include "include/navbar.php" ?>
<!-- Add these to your head section -->




        <section>
            <div id="lgx-about" class="lgx-about">
                <div class="lgx-inner">
                    <div class="container">
                        <div class="row">
                            <?php 
                            $sql_pro=mysqli_query($con,"SELECT * FROM product WHERE maincat='".$_GET['id']."'")or die('error');
                            while($row_pro=mysqli_fetch_array($sql_pro)){
                            ?>
                            <div class="col-xs-12 col-md-4">
                                <div class="card " style="background-color: rgb(160, 114, 114,0.2);;margin:10px;padding:10px" >
                                <div class="card-header text-center " style="padding: 10px;">
                                    <h3><?= $row_pro['pro_name'] ?></h3>
                                </div>
                                <div class="card-body text-center">
                                    <img src="./product_image/<?= getFirtstProImage($row_pro['pro_code'])?>" class="img-thumbnail " style="width:300px;height:400px" alt="" srcset="">
                                    <div>
                                        <span>MRP : <?= $row_pro['mrp'] ?></span>
                                        <span>Sell Price : <?= $row_pro['price'] ?></span>
                                    </div>
                                </div>
                                <div class="card-footer mt-3 text-center">
                                    <a href="check_out.php?id=<?= $row_pro['pro_ai'] ?>" class="btn btn-success">BuyNow</a>
                                </div>
                            </div>
                            </div>
                            <?php }?>
                        </div>
                    </div>
                    <!-- //.CONTAINER -->
                </div>
                <!-- //.INNER -->
            </div>
        </section>

    


<?php include "include/footer.php" ?>