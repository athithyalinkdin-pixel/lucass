<?php include "include/header.php"?>
<?php include "include/navbar.php";

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
echo $full_url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

switch ($_GET['type']) {
    case 'ref_income':
        $head = 'Affliate Reward';
        break;
    case 'franchise_income':
        $head = 'Franchise Income';
        break;
    case 'roi_income':
        $head = 'Roi Income';
        break;
        case 'binary_income': 
            $head = 'Binary Income';
            break;
            case 'reward_income':
                $head = 'Reward Wallet';
                break;
    default:
        $head = '';
        break; 
}
?>

                    <div class="all_opage">
                        <div class="page-header">
                            <div class="page-leftheader">
                                <!-- <h4 class="page-title mb-0">Welcome <span id="name1"></span></h4> -->
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index"><i class="fa fa-home mr-2 fs-14"></i>Home</a></li>
                                 
                                </ol>
                            </div>
                        </div>
 
<div class="container">
                           <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                   <div class="card-header">
                        <h5><?=  $head?></h5><br>
                        
                    </div>
                                            
                                          <div class="card-body">
                                         
                        <div style="overflow-x: scroll;">
                            <form action="<?= $full_url ?>" method="GET">
    <div style="display: flex; gap: 10px; align-items: center;">
        <input type="hidden" name="type" value="<?= $_GET['type'] ?>">
        <input type="date" name="from_date"  required>
        <input type="date" name="to_date" required>
        <button class="btn btn-primary btn-sm">Submit</button>
    </div>
</form>
                            <table class="table table-borderless datatable">
                                <thead>
                                     <tr>
                                        <th style="text-align:center;">S.No.</th>
                                        <th style="text-align:center;">Date</th>
                                        <th style="text-align:center;">Details</th>
                                        <th style="text-align:center;">Admin 5%</th>
                                        <th style="text-align:center;">Income</th>
                                      
                                        <th style="text-align:center;">Net UNIT</th> 
                                    </tr> 
                                </thead>
                                <tbody>
                                    <?php
                                    if (isset($_GET['from_date']) && isset($_GET['to_date'])) {
                                        $from_date = strtotime($_GET['from_date']);
                                        $to_date = strtotime($_GET['to_date']);
                                        $to_date_end = $to_date + 86399;
                                        $between = "AND jdate BETWEEN $from_date AND $to_date_end";
                                    } else {
                                        $between = '';
                                    }

                                    $res_pin = mysqli_query($con, "SELECT * FROM transaction_histroy WHERE user_id='$user_id' AND wallet_type='" . $_GET['type'] . "' AND transaction_type='credit'") or die("Query error");
                                    $i = 1;
                                    while ($row_pin = mysqli_fetch_array($res_pin)) {
                                    ?>
                                        <tr>
                                            <td><?php echo $i++;; ?></td>
                                            <td><p style="width: 150px;"><?php echo date('d-m-Y H:i', $row_pin['jdate']); ?></p></td>
                                            <td><?php echo $row_pin['comment']; ?></td>
                                           
                                            <td><?php echo $row_pin['deduction']; ?></td>
                                            <td><?php echo $row_pin['amount'] ?></td>
                                            <td><?php echo $row_pin['amount']+$row_pin['deduction']; ?></td>

                                        </tr>
                                    <?php
                                    }

                                    ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>


            </div>
</div>




                    </div>
                </div>




            </div>
        </div>
    </div>
    <!-- End app-content-->
    </div>






 <?php include "include/footer.php"?>