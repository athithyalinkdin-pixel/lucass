<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main " >

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqprint/0.3.0/jqprint.min.js"></script>
        <section class="section dashboard">

        <div class="row">
            <div class=" col-xs-12 col-md-8 " >
              
                    <div>
                        <style>
                               table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ddd;
            background-color: white;
        }

        td {
            padding: 10px;
            border: 1px solid #ddd;
            vertical-align: top;
            font-size: 12px;
        }

        img {
            width: 100%; /* Make the image responsive */
            height: auto; /* Maintain aspect ratio */
        }

        /* Optional: Add some styling for the table header */
        th {
            background-color: #f2f2f2;
        }
                        </style>
                    <table class="table table-bordered">
        <tr>
            <td colspan="2">
                <img src="../assets/receipt_top.jpg" alt="Receipt Top Image">
            </td>
        </tr>
        <tr>
            <td><b>Date: <?php echo date('d-m-Y', strtotime($row['activate_date'])); ?></b></td>
            <td style="text-align:right"><b>Receipt No: <?php echo "0000" . $row['id']; ?></b></td>
        </tr>
        <tr>
            <td>Received with Thanks From: <b><?php echo $row['name']; ?></b></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">The Amount of <b><?php echo plan_amount?>/-</b> is received against Purchase Order for <b>NEXT-VV Marketers PVT.LTD. MULTI BRAND ELECTRIC VEHICLES.</b> The purchase order Amount is Non Transferable and Non refundable and will be adjusted against your Final Payment for the Vehicle.
                Please Note: You have to pay Remaining Amount of E-bike in 3 Months and Purchase the Vehicle.
            </td>
        </tr>
        <tr>
            <td>User ID: <b><?php echo $row['user_id']; ?></b></td>
            <td>Payment Date: <b><?php echo date('d-m-Y', strtotime($row['activate_date'])); ?></b></td>
        </tr>
        <tr>
            <td>Amount In <b>Rs <?php echo plan_amount?>/-</b><br>
                Amount in words: <?php echo amountToWords(plan_amount);?>
            </td>
            <td><b>GST NO:</b><br>(Please Note: GST Invoice will be Generated for the P.O. Amount On Purchase Vehicle)</td>
        </tr>
        <tr>
            <td>Please Note- <br>You can buy Next-VV vehicle with Discount of Rs-<?php echo plan_amount?>/- or can transfer the same Coupon to Other Individual & Can also avail 3 Coupons Worth of Rs. 2666/- each, that he/she can sell the coupon or redeem it for themselves. 1 Coupon for each Bike. (T&C Apply)</td>
            <td>
                <ol>
                    <li>Please Note You have to buy the vehicle within 3 Months from the Purchase Order after making Remaining Final Payment.</li>
                    <li>This is a computer-generated statement, hence signature is not required.</li>
                </ol>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <img src="../assets/receipt_bottom.jpg" alt="Receipt Top Image">
            </td>
        </tr>
    </table>
                    </div>
                    
               
                <div style="text-align: center;">
                <button type="submit" class="btn btn-danger text-center"  onclick="window.print()"> <i class="bi bi-printer"></i> Print</button>
                </div>
                
            </div>

          
        </div>
         


      
     


    </main><!-- End #main -->
    <?php include "include/footer.php"?>