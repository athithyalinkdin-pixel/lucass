<?php
include "db.php";
include "user/function.php";
cuttOff();
?>