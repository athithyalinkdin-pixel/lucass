<?php session_start();
include "../db.php";
include "function.php";
/*
DELETE from reg where id!=1;
ALTER table reg AUTO_INCREMENT=1;

TRUNCATE TABLE transcation_history;
UPDATE reg set ref_income=0,total_income=0, wallet=0,ref_count=0,binary_income=0;


TRUNCATE TABLE deposit ; 
TRUNCATE TABLE binary_team; 

	DELETE FROM  tree1 WHERE ai!=1;
ALTER TABLE tree1 AUTO_INCREMENT=1;
UPDATE tree1 set 1_place='',2_place='',1_count=0,2_count=0,pair=0,payment_pair=0,washout_pair=0,total_income=0,wallet=0,1_biz=0,2_biz=0,1_carry=0,2_carry=0,left_right_fill=0,1_bv=0,2_bv=0;

TRUNCATE TABLE message;
TRUNCATE TABLE binary_team;
TRUNCATE TABLE wallet_histroy;

*/ 

if(isset($_REQUEST['user_registration'])) {
	
	$s_id= strtoupper($_REQUEST['s_id']);
 
	$name=$_REQUEST['name'];
	$mobile=$_REQUEST['mobile'];
	$password=$_REQUEST['password']; 
	$mail=$_REQUEST['mail'];
	
	$plan_amount=0;
	$pos=$_REQUEST['pos'];
	$user_id=user_name; 


	mysqli_query($con,"INSERT INTO `reg`(`jdate`,`user_id`, `name`, `mail`, `password`, `mobile`, `sponsor_id`) VALUES ('$strtime','$user_id','$name','$mail','$password','$mobile','$s_id')")or die("reg Query error <br>");

	mysqli_query($con,"INSERT INTO `tree1` (`user_id`, `sponsor_id`,`position`) VALUES ('$user_id','$s_id','$pos')")or die('tree insert error');
			placement_id_free_reg($user_id,$s_id,$pos,1);


	$msg1='Welcome Mr/Mr.'.$name.' to '.company_name.' Your user id : '.$user_id.' Your Password: '.$password.' Login Link :'.url.'/login.php';
	mail_label($mail,'New Register',$msg1);

	echo "<script>location.href='welcome.php?user_id=".$user_id."&&name=".$name."&&mobile=".$mobile."&&password=".$password."&&mail=".$mail."&&plan_amount=$plan_amount'</script>";

  } 

if(isset($_POST['self_activation'])){

	$user_id=$_POST['user_id'];

	$s_id=find_sponsor_id($user_id);
	$plan_amount= $_POST['plan_amount'];
	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `reg` WHERE `user_id`='$user_id' AND `status`=0"));
	if($cnt>=1){
		if(checkPurchaseWallet($_REQUEST['activator_id'],$plan_amount)){
			mysqli_query($con,"UPDATE `reg` SET `investment`=`investment`+'$plan_amount' , `plan_amount`='$plan_amount' , `status`=1,`activate_date`='$strtime' WHERE `user_id`='$user_id'")or die('update reg error');
	
		 $row_tree=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree1 WHERE user_id='$user_id'"));
			mysqli_query($con,"UPDATE tree1 SET status=1 WHERE user_id='$user_id' ")or die('tree statu update error');
			binary_count_for_activation($user_id,$row_tree['position'],$plan_amount);
	
		   echo "<script>alert('Activate Successfully')</script>";
		   echo "<script>location.href='index.php?theme=4'</script>";
		  }
		  else
		  fail('Insuffcient Balance');
	}
	else
	fail('This id Already Activated or Wrong ID');	

}

if(isset($_POST['top_up_submit'])){

	$user_id=$_POST['user_id'];

	$s_id=find_sponsor_id($user_id);
	$plan_amount= $_POST['plan_amount'];

	if(checkUserId($user_id)){
	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `reg` WHERE `user_id`='$user_id' AND `plan_amount`=$plan_amount"));
	if($cnt==0){
		if(checkPurchaseWallet($_REQUEST['activator_id'],$plan_amount)){
			mysqli_query($con,"UPDATE `reg` SET `investment`=`investment`+'$plan_amount' ,`plan_amount`='$plan_amount' WHERE `user_id`='$user_id'")or die('update reg error');
		 ref_income($user_id,(300));
		 $row_tree=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree1 WHERE user_id='$user_id'"));
			mysqli_query($con,"UPDATE tree1 SET status=1 WHERE user_id='$user_id' ")or die('tree statu update error');
	binary_count_for_topup($user_id,$row_tree['position'],$plan_amount);
	
		   echo "<script>alert('Activate Successfully')</script>";
		   echo "<script>location.href='index.php?theme=4'</script>";
		  }
		  else
		  fail('Insuffcient Balance');
	}
	else
	fail('This id Already Distributor ID');	
	}
	else
	fail('Enter Correct ID');	


}

 
if(isset($_POST['delete_nominee'])){
	mysqli_query($con,"DELETE FROM nominee WHERE n_ai='".$_POST['delete_nominee']."'")or die('error');
	echo "<script>alert('Nominee Deleted Successfully')</script>";
			echo "<script>location.href='nominee.php?theme=4'</script>";
}

if(isset($_POST['nominee_add'])){

	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM nominee WHERE user_id='".$_SESSION['user_id']."'"));
	if($cnt==1)
	fail('Already Added nominee');
else{
	mysqli_query($con,"INSERT INTO `nominee`(`user_id`, `name`, `relationship`, `mobile`) VALUES ('".$_SESSION['user_id']."','".$_POST['name']."','".$_POST['relationship']."','".$_POST['mobile']."')")or die('insert error');
	echo "<script>alert('Nominee Added')</script>";
			echo "<script>location.href='nominee.php?theme=4'</script>";
}
	
}



  if(isset($_POST['update_kyc'])){
$user_id=$_POST['user_id'];
$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='$user_id'"));
if(!empty($row['aadhar_card'])){
	unlink('../kyc_doc/'.$row['aadhar_card']);
	unlink('../kyc_doc/'.$row['pan_card']);
	unlink('../kyc_doc/'.$row['bank_book']);
}
	$destination='../kyc_doc/';
	
	$pic_name1=img_validate($_FILES['pic1']['type'],$_FILES['pic1']['size'],$_FILES['pic1']['tmp_name'],$destination);
	$pic_name2=img_validate($_FILES['pic2']['type'],$_FILES['pic2']['size'],$_FILES['pic2']['tmp_name'],$destination);
	$pic_name3=img_validate($_FILES['pic3']['type'],$_FILES['pic3']['size'],$_FILES['pic3']['tmp_name'],$destination);

	mysqli_query($con,"UPDATE reg SET aadhar_card='$pic_name1',pan_card='$pic_name2',bank_book='$pic_name3' WHERE user_id='$user_id'")or die('error 2');
	success('Update');

  }
  
  if(isset($_POST['get_tree_values'])){
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg INNER JOIN tree ON tree.user_id=reg.user_id WHERE reg.user_id='".$_POST['user_id']."'"));
	echo '<table class="table text-white">
	<tr>
	<th>Name</th>
	<td>'.$row['name'].'</td>
	</tr>
	<tr>
	<th>Sponsor ID</th>
	<td>'.$row['sponsor_id'].'</td>
	</tr>
	<tr>
	<th>Join Date</th>
	<td>'.$row['join_date'].'</td>
	</tr> 
	<tr>
	<th>Left Team</th>
	<td>'.$row['1_count'].'</td>
	</tr>
	<tr>
	<th>Right Team</th>
	<td>'.$row['2_count'].'</td>
	</tr>
	</table>';
}

if(isset($_POST['pin_generate'])){

	$user_id=$_POST['user_id'];
	$eligible_amount=$_POST['eligible_amount'];
	$pin_amount=$_POST['pin_amount'];
	$count=$_POST['count'];
$tot_pin=$pin_amount*$count;

if($eligible_amount>=$tot_pin){
mysqli_query($con,"UPDATE reg SET wallet=wallet-$tot_pin WHERE user_id='$user_id'")or die('wallet update error');
	for($i=0;$i<$count;$i++)
	{
	$length = 7;
				$getNumber = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, $length).$pin_amount;
				mysqli_query($con,"INSERT INTO `pin`(`pin`, `amount`, `u_id`,`pin_date`) VALUES ('$getNumber','".$pin_amount."','$user_id','$dt')")or die("Query Error Pin");

				echo "<script>alert('Pins Generated Successfully')</script>";
		echo "<script>location.href='wallet_to_pin.php?theme=4'</script>";
	}
}
else{
	fail('Insufficient Wallet Balance');
}

	

}

if(isset($_POST['wallet_to_purchase_transfer'])){
	$user_id=$_POST['user_id'];
	$wallet=$_POST['wallet'];
	$tds=$_POST['tds'];
	$eligible_amount=$_POST['eligible_amount'];
	mysqli_query($con,"UPDATE reg SET wallet=0,purchase_wallet=purchase_wallet+'$eligible_amount' WHERE user_id='$user_id'")or die('error 1');

	transaction_history($user_id,'credit','wallet','Income wallet to purchase wallet trasfer ',0);
		echo "<script>alert('Transfer Successfully ')</script>";
			echo "<script>location.href='index.php?theme=4'</script>";

}









if(isset($_POST['check_user_name']))
{
	$sql=mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$_POST['to_id']."'");
	$cnt=mysqli_num_rows($sql);
	if($cnt==0)
	$arr = array('res' => 'false' );
else
{
	$row=mysqli_fetch_assoc($sql);
	$arr = array('res' => 'true','name'=>$row['name'] );
}
	
echo json_encode($arr);
}

 

if(isset($_POST['send_pin_to_id']))
{ 
	$u_id=$_POST['u_id'];
	$to_id=$_POST['to_id'];
	$tranfer_amount=$_POST['tranfer_amount'];
	$wallet=$_POST['wallet'];
	
	if($wallet>=$tranfer_amount)
	{
		mysqli_query($con,"UPDATE reg SET wallet=wallet+$tranfer_amount WHERE user_id='$to_id'")or die('Transfer query error1');
		mysqli_query($con,"UPDATE reg SET wallet=wallet-$tranfer_amount WHERE user_id='$u_id'")or die('Transfer query error2');
		$type='wallet';
		$comment='Amount of '.$tranfer_amount.' tranfer to : '.$to_id;
	
		 transaction_history($u_id,'debit',$type,$comment,$tranfer_amount);
		
		$comment2='Amount of '.$tranfer_amount.' Recived  From : '.$u_id;
	
		 transaction_history($to_id,'credit',$type,$comment2,$tranfer_amount);
	
		echo "<script>alert('Send Amount Successfully')</script>";
		echo "<script>location.href='wallet_transfer.php'</script>";
	}
	else
	{
		fail('Insufficent Balance');
	}

}



if(isset($_POST['login']))
	{
		$u_id=$_POST['u_id'];
		$pass=$_POST['pass'];
		if($u_id!=""&&$pass!="")
		{
			$sql=mysqli_query($con,"SELECT * FROM reg WHERE  user_id='$u_id' AND password='$pass'") or die("query error");
			$row=mysqli_fetch_assoc($sql);
			
			//print_r($result);
			if($sql->num_rows>=1)
			{
					if($row['is_blockid']==1){
						fail('Your Account Blocked : Contact our Team');
					}
					else{
						$_SESSION["user_id"]=$u_id;
					echo "<script>location.href='index.php'</script>";
					}
			}
			else
			{
				echo "<p style='color:red'>Please Enter Correct Details</p>";
			}
		}
		
	}
	
if(isset($_POST['send_message']))
{
	$user_id=$_POST['user_id'];
	$subject=$_POST['subject'];
	$message=$_POST['message'];
	

	mysqli_query($con,"INSERT INTO `message`(`jdate`, `from_id`, `to_id`, `subject`, `message`) VALUES ('$dt','$user_id','admin','$subject','$message')") or die("message Query error");
	echo "<script>alert('Message Send Successfully')</script>";
	echo "<script>location.href='message_send.php?'</script>";
	
	$msg='Message Send';
	success($msg);
}




if(isset($_POST['check_pin_value']))
{
	$pin=$_POST['pin'];
	
	$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM pin WHERE pin='$pin'"));
	
	echo $row['amount'];
}

if(isset($_POST['deposit_amount']))
{
	$user_id=$_POST['user_id']; 

	$ref_id=$_POST['ref_id'];
	$amount=$_POST['amount'];
	
	$cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM `deposit` WHERE `ref_id`='$ref_id'"));
	
	if($cnt>=1)
	fail('This Proof Already Exist');
else{
	$destination='../payment_proof/';
	$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);
   mysqli_query($con,"INSERT INTO `deposit`(`jdate`,`user_id`, `ref_id`, `pic`, `amount`) VALUES ('$strtime','$user_id','$ref_id','$pic_name','$amount')") Or die("pin Insert Query error");
   
	success('Amount Sent');
}
	

	
	
}

	
if(isset($_POST['withdraw']))
{
	
	$user_id=$_POST['user_id'];
	$wallet=$_POST['wallet'];
	$withdraw_amount=$_POST['withdraw_amount'];
	$tds=$_POST['tds'];
	$eligible_amount=$_POST['eligible_amount'];
	
	
	if($wallet>=$withdraw_amount)
	{
			mysqli_query($con,"UPDATE reg SET wallet=wallet-'$withdraw_amount' WHERE user_id='$user_id'")or die("Update Query error");
	
			mysqli_query($con,"INSERT INTO `withdraw`(`user_id`, `jdate`, `withdraw_amount`,`tds`,`net_amount`) VALUES ('$user_id','$strtime','$withdraw_amount','$tds','$eligible_amount')") or die("withdraw_request Insert query error");

	 transaction_history($user_id,'debit','wallet','Withdraw Amount Successfully',$withdraw_amount); 
	echo '<script>alert("Withdraw Request Successfully")</script>';
echo "<script>location.href='withdraw.php'</script>";
	}
	else
	{
		$msg_fail='Enter Valuble Amount';
		fail($msg_fail);
	}

}
	



	
if(isset($_POST['update_profile']))
{
	$id=$_POST['id'];
	$name=$_POST['name'];
	$mobile=$_POST['mobile'];
	$address=$_POST['address'];
	$city=$_POST['city'];
	$state=$_POST['state'];
	$pin_code=$_POST['pin_code'];
	$mail=$_POST['mail'];
	
	
	if(!empty($_FILES['pic']['name']))
	{
		unlink($_POST['unlink']);
		$destination='../profile/';
		$pic_name=img_validate($_FILES['pic']['type'],$_FILES['pic']['size'],$_FILES['pic']['tmp_name'],$destination);
		mysqli_query($con,"UPDATE `reg` SET `profile_pic`='$pic_name' WHERE  id='$id'");
	}
	
	
	mysqli_query($con,"UPDATE `reg` SET `name`='$name',`mail`='$mail',`mobile`='$mobile',`address`='$address',`city`='$city',`state`='$state',`pin_code`='$pin_code' WHERE id='$id'")or die("update_profile Query error");
	$msg="Update";
	success($msg);
	
}

if(isset($_POST['update_account']))
{
	$id=$_POST['id'];
	
	$acc_num=$_POST['acc_num'];
	$acc_name=$_POST['acc_name'];
	$ifsc=$_POST['ifsc'];
	$bank=$_POST['bank'];
	$branch=$_POST['branch'];
	$google_pay=$_POST['google_pay'];
	$phone_pe=$_POST['phone_pe'];
	$pay_tm=$_POST['pay_tm'];
	$upi=$_POST['upi'];
	$aadhar_number=$_POST['aadhar_number'];
	$pan_number=$_POST['pan_number'];
	
	
	
	mysqli_query($con,"UPDATE `reg` SET `acc_num`='$acc_num',`acc_name`='$acc_name',`ifsc`='$ifsc',`bank`='$bank',`branch`='$branch',`google_pay`='$google_pay',`phone_pe`='$phone_pe',`pay_tm`='$pay_tm',`upi`='$upi',`pan_number`='$pan_number',`aadhar_number`='$aadhar_number' WHERE id='$id'")or die("update_profile Query error");
	$msg="Update";
	success($msg);
	
}

if(isset($_POST['change_pass']))
{
	$id=$_POST['id'];
	$old_pass=$_POST['old_pass'];
	$cpwd=$_POST['cpwd'];
	
	 $pass_count=mysqli_num_rows(mysqli_query($con,"select * from reg where id='$id' AND password='$old_pass'"));
	 
	 if($pass_count>=1)
	 {
		 mysqli_query($con,"UPDATE `reg` SET `password`='$cpwd' where id='$id'")or die("Query error");
		 $msg="Password Update";
		success($msg);
	 }
	 else{
		 $msg="Wrong Old Password";
		fail($msg);
	 }
	
	
}

if(isset($_POST['payment_proof']))
{
	$id=$_POST['id'];
	$amount=$_POST['amount'];
	
	$picture_name=$_FILES['pic']['name'];
	$picture_type=$_FILES['pic']['type'];
	$picture_tmp_name=$_FILES['pic']['tmp_name'];
	$picture_size=$_FILES['pic']['size'];	
	if($picture_type=="image/jpeg" || $picture_type=="image/jpg" || $picture_type=="image/png" || $picture_type=="image/gif")
	{
	if($picture_size<=50000000)
		{
		$pic_name=time()."_".$picture_name;
		
		move_uploaded_file($picture_tmp_name,"../payment_proof/".$pic_name);
		mysqli_query($con,"INSERT INTO `transcation_history`(`u_id`, `trans_date`, `type`, `comment`, `creadit`) VALUES ('$id','$today','Payment_Proof','$pic_name','$amount') ")or die("Query eror");
		$msg="Payment Proof Submit";
		success($msg);
		}
		else{
			 $msg="Uplaod Below 5 MB";
		fail($msg);
		}
		
	}
}

	if(isset($_POST['submit_payment_proof']))
	{
		$u_id=$_POST['u_id'];
		$amount=$_POST['amount'];
		$details=$_POST['details'];
		//picture1 coding
		$picture_name=$_FILES['pic']['name'];
		$picture_type=$_FILES['pic']['type'];
		$picture_tmp_name=$_FILES['pic']['tmp_name'];
		$picture_size=$_FILES['pic']['size'];	

		if($picture_type=="image/jpeg" || $picture_type=="image/jpg" || $picture_type=="image/png" || $picture_type=="image/gif")
		{
		if($picture_size<=50000000)
			{
			$pic_name=time()."_".$picture_name;
			
			$pic_name2=$pic_name;
			
			move_uploaded_file($picture_tmp_name,"../payment_proof/".$pic_name);
			
		mysqli_query($con,"INSERT INTO `payment_proof`(`payment_proof_date`, `u_id`, `payment_proof_pic`, `amount`, `details`, `status`) VALUES ('$today','$u_id','$pic_name2','$amount','$details',1)") or die ("query error1");
		
		mysqli_query($con,"UPDATE reg  SET status=4 WHERE user_id='$u_id'")or die("Query error");
		$msg="Payment Proof Submit sucessfully";
			
			success($msg);

					
		}
		else 
		{
			$msg="Image uploade Below 5 MB";
			fail($msg);
		}

		}
	}
	

	if(isset($_POST['contact_us']))
	{
		$msg='Name : '.$_POST['name'].' Mobile : '.$_POST['mobile'].' Mail : '.$_POST['mail'].' Message : '.$_POST['message'];
		mail_label('amazooads@gmail.com','Contact form',$msg);
		success('Contact our Team Shortly');
	}


	if(isset($_POST['register_from_website'])){


	$ref_id=!empty($_POST['s_id'])?$_POST['s_id']:primary_id;
	
	  $name=$_POST['name'];
	  $mobile=$_POST['mobile'];
	  $mail=$_POST['mail'];
	  $pos=$_POST['pos'];
	  $password=$_POST['password'];
	 
	 

	  $cnt=mysqli_num_rows(mysqli_query($con,"SELECT * FROM reg WHERE user_id='$ref_id'"));
	  if($cnt>=1)
	  {
		  $cnt2=mysqli_num_rows(mysqli_query($con,"SELECT * FROM reg WHERE mail='$mail'"));
		if($cnt2>=1)
		{
			fail('This id Already Exist');
		}
		else
		{ 
			$user_id=user_name;
	
		   mysqli_query($con,"INSERT INTO `reg`(`user_id`, `jdate`, `sponsor_id`, `name`, `mail`, `mobile`, `password`) VALUES ('$user_id','$strtime','$ref_id','$name','$mail','$mobile','$password')")or die("Query error");

		   mysqli_query($con,"INSERT INTO `tree1` (`user_id`, `sponsor_id`,`position`) VALUES ('$user_id','$ref_id','$pos')")or die('tree insert error');
		   placement_id_free_reg($user_id,$ref_id,$pos,1); 
		$subject='Register';
	 $msg1='Welcome to '.company_name.', Your user id: '.$user_id.' Password is :'.$password ;
		
		$msg='
		<style>
		
		table{
			width:400px;
			 margin-left: auto;
	  margin-right: auto;
	   border: 1px solid black;
	   text-align:center;
		}
		h1{
			 margin-left: auto;
	  margin-right: auto;
	  
	   color:green;
		  text-align:center;
		}
		p{
			
			background-color:green;
			color:white;
			font-size:30px;
			 margin-left: auto;
	  margin-right: auto;
			padding:10px;
		}
		</style>
		<h1>Welcome to '.company_name.'</h1>
		<table class="center">
				<tr>
					<td colspan="2" >
						<h3>Your Login Details</h3>
					</td>
				</tr>
				<tr>
					<th>User ID</th>
					<td>'.$user_id.'</td>
				</tr>
				<tr>
					<th>Password</th>
					<td>'.$password.'</td>
				</tr>
				<tr>
					<th>E-Mail ID</th>
					<td>'.$mail.'</td>
				</tr>
				<tr>
					<th colspan="2" ><h2><a href="login.php">Click Here To Login</a></h2></th>
					
				</tr>
				
			</table>
			<p>For Login Details Check Your Mail</p>';
			
			echo $msg;
		//	$msg1='Welcome Mr/Mr.'.$name.' to '.company_name.' Your user id : '.$user_id.' Your Password: '.$password.' Login Link :'.url.'/login.php';
		mail_label($mail,$subject,$msg1);
	
		}
		   
	  }
	  else{
		  $msg="Wrong Sponcer";
			  fail($msg);
	  }
	
	}
	
	if(isset($_POST['forget_password']))
	{
		$sql=mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$_POST['user_id']."'")or die("Query error");
		$cnt=mysqli_num_rows($sql);
		if($cnt>=1)
		{
			$row=mysqli_fetch_assoc($sql);
			$subject='Recovery Password';
			$name='';
	 $msg1='Your Password is :'.$row['password'].' Login Link :'.url.'/login.php';
		
	
		mail_label($row['mail'],$subject,$msg1);
		success('Check Your Mail id');
		}
		else{
		
			fail('Wrong User id');
		}
	}


	if(isset($_POST['contact_us_mail'])){
print_r($_POST);
$msg=$_POST['subject'].'   '.$_POST['message'].' FROM : '.$_POST['firstn'].' '.$_POST['lastn'].' Email id : '.$_POST['email'].' Mobile No : '.$_POST['phone'];
		mail_label(email_id,'Enquiery From Website',$msg);
		success('Our Team Will Contact You Shortly');
	}
 ?>
