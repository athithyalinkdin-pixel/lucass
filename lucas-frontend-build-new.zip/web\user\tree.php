<?php include "include/header.php"?>
<?php include "include/navbar.php"?>
<main id="main" class="main">

        <div class="pagetitle"> 
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->
<style>
	
@media only screen and (min-width: 1224px) {
    div#pop-up {
        display:none;
        position: fixed;
        width: 350px;
        padding: 10px;
        background: #1213a0;
        color: #fff;
        border: 1px solid #4041c9;
        font-size: 90%;
        left: 50%;
        top: 300px
    }

    div#pop-up td {
        color: #fff
    }
}

@media only screen and (min-device-width: 320px)and (max-device-width:480px) {
    div#pop-up {
        display:none;
        position: fixed;
        width: 350px;
        padding: 10px;
        background: #1213a0;
        color: #fff;
        border: 1px solid #4041c9;
        font-size: 90%;
        left: 10%;
        top: 100px
    }

    div#pop-up td {
        color: #fff
    }
}
</style>
        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">My Tree</h5>
                    </div>
                                            
                                            <div class="card-body">
                                            <form method="GET" action="tree.php?id=<?php echo $_GET['id']?>">
								<input type="hidden" name="theme" value=4>
								

								<div class="input-group m-3">
								<input type="text" class="form-control" style="color:black" placeholder="Enter Correct ID" name="id"  required><input type="submit" name="tree_check"  style="color:black" value="Find ID" class="btn btn-primary">
								
								</div>
							</form>

							<?php 
 $tree_id=$_GET['id'];
						function check_tree_img($user_id)
						{
							global $con;
							$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree1 INNER JOIN reg ON reg.user_id=tree1.user_id WHERE reg.user_id='$user_id'"));
							$color=$row['status']==1?'green':'red';
							return '<img src="green.png" class="popoverdata tree_img" value="'.$user_id.'" style="background-color:'.$color.';padding:8px;width:50px;"><br>
							<a   href="tree.php?id='.$user_id.'">'.$row['user_id'].' <br> '.$row['name'].'</a>
							
							';
						}

						function empty_tree($user_id,$pos)
						{
							

							return '<img src="red.png" class="tree_img" style="width:50px;"><br>
							';
							/*<a style="margin-left:5px;" href="reg_from_tree.php?pid='.$user_id.'&&pos='.$pos.'" class="btn btn-danger"></a>*/
						}
						function check_tree_leg($user_id,$leg)
						{
							global $con;
							$row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tree1 INNER JOIN reg ON reg.user_id=tree1.user_id WHERE reg.user_id='$user_id'"));
							return $row[$leg];
						}

?>
                                              

                            <?php $row1=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$_GET['id']."'")); ?>
                          <div style="overflow-x: scroll; height:500px" >
						  <style>
 .tree_table td{
	 height:150px;
 }
 .tree_table img{
	  border-radius: 50%;
 }
 </style>
                          <table class="table tree_table">
					<tr>
						<td class="text-center" colspan="4"><?php echo check_tree_img($_GET['id'])?></td>
						
					</tr>
					<tr>
						
				

 

						<td class="text-center" colspan="2">
						<?php if(!empty(check_tree_leg($tree_id,'1_place'))) 
												{
													$id1=check_tree_leg($tree_id,'1_place');
													echo check_tree_img($id1);
												}
												else
												{
													echo empty_tree($tree_id,1);
												}
										?>
										
						</td>
						<td class="text-center" colspan="2">
						<?php if(!empty(check_tree_leg($tree_id,'2_place'))) 
												{
													$id2=check_tree_leg($tree_id,'2_place');
													echo check_tree_img($id2);
												}
												else
												{
													echo empty_tree($tree_id,2);
												}
										?>
						</td>
					
								    
					</tr>	
					<tr>
						<td class="text-center">
						<?php if(!empty($id1))
														{
															if(!empty(check_tree_leg($id1,'1_place'))) 
															{
																$id11=check_tree_leg($id1,'1_place');
																echo check_tree_img($id11);
															}
															else
															{
																echo empty_tree($id1,1);
															}
														} 
														
												?>
						</td>
						
						<td class="text-center">
						<?php if(!empty($id1))
														{
															if(!empty(check_tree_leg($id1,'2_place'))) 
															{
																$id12=check_tree_leg($id1,'2_place');
																echo check_tree_img($id12);
															}
															else
															{
																echo empty_tree($id1,2);
															}
														} 
														
												?>
						</td>
						
					
						
						<td class="text-center">
						<?php if(!empty($id2))
														{
															if(!empty(check_tree_leg($id2,'1_place'))) 
															{
																$id21=check_tree_leg($id2,'1_place');
																echo check_tree_img($id21);
															}
															else
															{
																echo empty_tree($id2,1);
															}
														} 
														
												?>
						</td>
						
						<td class="text-center">
						<?php if(!empty($id2))
														{
															if(!empty(check_tree_leg($id2,'2_place'))) 
															{
																$id22=check_tree_leg($id2,'2_place');
																echo check_tree_img($id22);
															}
															else
															{
																echo empty_tree($id2,2);
															}
														} 
														
												?>
						</td>
						
					
						
						
						
					
						
				
						
					</tr>	
					</table>

					
					<div id="pop-up">
    <p>
        This div only appears when the trigger link is hovered over. Otherwise it is hidden from view.
    </p>

</div>
							<script>
						  $(function () {
            var moveLeft = 20;
            var moveDown = 10;

            $('.popoverdata').hover(function (e) {
				var user_id=$(this).attr("value");
				console.log(user_id);
				var get_tree_values=''
                $('div#pop-up').show(); 
                var position = $(this).position();
                $("div#pop-up").appendTo('body');
               
				$.post('action.php',{get_tree_values:get_tree_values,user_id:user_id}).done(function(res){
				
                $('div#pop-up').html(res);
				});

				
            }, function () {
                $('div#pop-up').hide();
            });

            $('a.trigger').mousemove(function (e) {
                $("div#pop-up").css('top', e.pageY + moveDown).css('left', e.pageX + moveLeft);
            });

        });
					</script>
                          </div>
                                            </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>