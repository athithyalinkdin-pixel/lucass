<?php include "include/header.php"?>
<?php include "include/navbar.php";

?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title">Received Message</h5>
                    </div>
                                            
                                            <div class="card-body">

                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th>Sl.No</th>
								<th>Date</th>
								<th>Subject</th>
								<th>Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
							$row_msg=mysqli_query($con,"SELECT * FROM message WHERE u_id='$user_id' AND type='recive' AND status=1");
							$i=1;
							while($res_message=mysqli_fetch_array($row_msg))
							{
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td><?php echo $res_message['msg_date'];?></td>
								<td><?php echo $res_message['subject'];?></td>
								<td><?php echo $res_message['message'];?></td>
							</tr>
							<?php
							}
							?>
                                                                    </tbody>
                            </table>

                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>