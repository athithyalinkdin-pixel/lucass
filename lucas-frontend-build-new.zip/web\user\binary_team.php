<?php include "include/header.php"?>
<?php include "include/navbar.php";
if($_GET['pos']==1){
    $head='LEFT';
}
else{
    $head='RIGHT';
}
?>
<main id="main" class="main">

        <div class="pagetitle">
            <h1><?php echo $user_id?></h1>
            <!-- <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav> -->
        </div><!-- End Page Title -->
       

        <section class="section dashboard">
            <div class="row"> 
                <!-- Left side columns -->
                <div class="col-lg-12">
                <div class="card  mb-2">
                    <div class="card-header">
                    <h5 class=" card-title"><?php echo $head?> Team</h5>
                    </div>
                                            
                                            <div class="card-body">
                                    <div style="overflow-x: scroll;">
                                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                    <th>SL.No</th>
					<th>ID</th>
					<th>Name</th>
					<th>Mobile</th>
					<th>Investment</th>
					
					
					<th>Join Date</th>
					<th>Position</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
				
                $s_id=isset($_GET['id'])?$_GET['id']:$user_id;
    
                        $res=mysqli_query($con,"SELECT * FROM binary_team INNER JOIN reg ON binary_team.tree_id=reg.user_id WHERE binary_team.user_id='$s_id' AND binary_team.pos='".$_GET['pos']."'")or die('error'); 
                        $i=0;
                        
                        while($row=mysqli_fetch_array($res))
                        {
                            $i++;
                           $pos=$row['pos']==1?'LEFT':'RIGHT';
                    ?>
                    <tr>
                        <td><?php echo$i;?></td>
                        <td><?php echo$row['tree_id'];?></td>
                        <td><?php echo$row['name'];?></td>
                        <td><?php echo$row['mobile'];?></td>
                        <td><?php echo$row['plan_amount'];?></td>
                
                        
                        <td><?php echo date('d-m-Y',$row['jdate']);?></td>
                        <td><?php echo$pos;?></td>
                      
                    </tr>
                    <?php
                        }
                        
                    ?>
                                                                    </tbody>
                            </table>


                                                </div>
                                                </div>
                </div>


            </div>
        </section>

    </main><!-- End #main -->
    <?php include "include/footer.php"?>