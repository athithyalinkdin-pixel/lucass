<?php include '../db.php'?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/12d5428/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome Letter </title>
</head>
<body >
  <div align="center"> 
<table  cellpadding="0" cellspacing="0" bordercolor="#1a1e8b" width="704" >
<tbody style="font-family:Verdana, Geneva, sans-serif;font-size:12px;color:#1a1e8b;" >
<table  cellpadding="0" bordercolor="#1a1e8b" width="704" border="0" style="border-collapse: collapse" >
<tbody style="font-family:Verdana, Geneva, sans-serif;color:#1a1e8b;font-size:12px;"  >

<tr>
    <td width="100%" align="center" >
    <table  width="100%" >
    <!--<tr><td align="left" width="30%"><img src="../images/logo.png"  width="200" border="0"/></td>
    <td align="right" width="70%" style="color:#000;font-size:11px;font-weight: bold;"> </td>
    </tr>--->

<tr>
<td colspan="5" style="border: #1a1e8b 1px dashed;padding:20px;" align="left"><b>CONGRATULATIONS:</b><br/><br/>Your  <?php echo $_GET['user_id']?> </b>has been created successfully . Welcome to <?php echo company_name?>, now you can start sponsoring/referring your contacts to share this wonderful opportunity
</td>                         
</tr>
<tr>
<td colspan="5" style="border: #1a1e8b 1px dashed;padding:20px;" align="left">
<table cellpadding="5" cellspacing="0" width="100%">
<tr>

<td width="60%" style="padding-left:10px;border:1px solid #1a1e8b;">Member Id :- <?php echo $_GET['user_id']?></td>
<td width="40%" style="padding-left:10px;border:1px solid #1a1e8b;">Package : - <?php echo $_GET['plan_amount']?></td>
</tr>

<tr>
<td style="padding-left:10px;border:1px solid #1a1e8b;">Name :-<?php echo $_GET['name']?></td>
<td style="padding-left:10px;border:1px solid #1a1e8b;">Date of Joining :-<?php echo date('d-m-Y')?></td>

</tr>

<tr>
<td style="padding-left:50px;border:1px solid #1a1e8b;" rowspan="4" valign="top">
  <h4>Address</h4><?php echo company_registerd_name .',<br>'.address?>
</td>
<td style="padding-left:10px;border:1px solid #1a1e8b;">Mobile no :-<?php echo $_GET['mobile']?> </td>
</tr>
<tr>
<td style="padding-left:10px;border:1px solid #1a1e8b;" >Password  :- <?php echo $_GET['password']?></td>
</tr>	
<tr>
<td style="padding-left:10px;border:1px solid #1a1e8b;" >Transaction Password  :- <?php echo $_GET['password']?></td>
</tr>	
<tr>
<td style="padding-left:10px;border:1px solid #1a1e8b;" >Email id :- <?php echo $_GET['mail']?></td>
</tr>	
</table>
</td></tr>


<tr>
<td colspan="2" style="border: #1a1e8b 1px dashed;height: 50px;" align="center"><a href="index.php"> Back To Home</a></td>
               					
</tr>		
</table>    
    </td></tr>
    </table>
      </td>
</tr>   

     </table>
 
</tbody>
</table>
</div>

</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh-oh'},{'server':'sg2plzcpnl487151'},{'id':'8500930'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>
