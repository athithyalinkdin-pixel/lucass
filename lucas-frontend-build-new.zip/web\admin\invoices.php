
<?php include "include/header.php" ?>

<div class="wrapper">

    <?php include "include/navbar.php" ;
  
  $id=$_GET['id'];

  if($id=='COD')
  {
      $head='COD Bills';
      $where='WHERE order_type="COD"';
  }
  else if($id==='ONLINE'){
      $head='Online Bills';
      $where='WHERE order_type="ONLINE"';
  }
  else{
    $head='Total Bills';
    $where='';
  }
   
    ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
       <section class="content-header">
            <h1>
               <?php echo $head?>
                <small>advanced tables</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">  <?php echo $head?></a></li>
                <li class="active"> <?php echo $head?></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">

                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title" style="color:#FF0000;"><b>  <?php echo $head?></b></h3>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                             <table id="data_table" class="table table-bordered table-striped">  
                          <thead>  
                               <tr>  
                               <th>Sl.No</th>
                               <th>Date</th>
				<th>Invoice Number</th>
				<th>User Details</th>
				<th>Price</th>
				<th>Discount </th>
				<th>Net Amount</th>
				
                               </tr>  
                          </thead>  
                             <tbody>
									<?php 
					
				
							$res_pin=mysqli_query($con,"SELECT * FROM invoice ORDER BY inv_ai  DESC  ")or die("Query error");
							$i=1;
                            $stot=0;
							while($row1=mysqli_fetch_array($res_pin))
							{
                                $row_user=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM reg WHERE user_id='".$row1['inv_user']."'"));
                               
            
                                $order_date='';
                                echo '<tr>';
                                echo '<td>'.$i++.'</td>';
                                echo '<td>'.date('d-m-Y',($row1['inv_jdate'])).'</td>';
                                echo '<td>'.$row1['inv_number'].'</td>';
                                echo '<td>'.$row_user['user_id'].' - '.$row_user['name'].',<br>'.$row_user['address'].',<br>'.$row_user['city'].','.$row_user['postel_code'].',<br>'.$row_user['mobile'].'<br><a href="view.php?id='.$row_user['user_id'].'" target="_blank" class="btn btn-primary btn-sm">View user</a></td>';
                                echo '<td>'.$row1['inv_price'].'</td>';
                                echo '<td>'.$row1['inv_discount'].'</td>';
                                echo '<td>'.$row1['inv_total'].'</td>';
                            
                                echo '</tr>';
					
					?>
						
						<?php
					}
							
						?>
                                </tbody>
                     </table> 
                        </div>
                        <!-- /.box-body -->
                    </div>
					 
		  
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php include "include/footer.php" ?>

