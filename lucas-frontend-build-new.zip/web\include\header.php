
<?php include "db.php";
session_start();
include "user/function.php";
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!-- The above 3 meta tags *must* come first in the head -->

    <!-- SITE TITLE -->
    <title><?php echo company_name?></title>
    <meta name="description" content=" " />
    <meta name="keywords" content=" " />
    <meta name="author" content=" " />

    <!-- twitter card starts from here, if you don't need remove this section -->
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@yourtwitterusername" />
    <meta name="twitter:creator" content="@yourtwitterusername" />
    <meta name="twitter:url" content="http://yourdomain.com" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <meta name="twitter:title" content=" " />
    <!-- maximum 140 char -->
    <meta name="twitter:description" content=" " />
    <!-- maximum 140 char -->
    <meta name="twitter:image" content="" />
    <!-- when you post this page url in twitter , this image will be shown -->
    <!-- twitter card ends from here -->

    <!-- facebook open graph starts from here, if you don't need then delete open graph related  -->
    <meta property="og:title" content=" " />
    <meta property="og:url" content=" " />
    <meta property="og:locale" content="en_US" />
    <meta property="og:site_name" content=" " />
    <!--meta property="fb:admins" content="" /-->
    <!-- use this if you have  -->
    <meta property="og:type" content="website" />
    <meta property="og:image" content=" " />
    <!-- when you post this page url in facebook , this image will be shown -->
    <!-- facebook open graph ends from here -->

    <!--  FAVICON AND TOUCH ICONS -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png" />
    <!-- this icon shows in browser toolbar -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
    <!-- this icon shows in browser toolbar -->


    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="assets/libs/bootstrap/css/bootstrap.min.css" media="all" />
    

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="assets/libs/fontawesome/css/font-awesome.min.css" media="all" />

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="assets/libs/maginificpopup/magnific-popup.css" media="all" />

    <!-- Time Circle -->
    <link rel="stylesheet" href="assets/libs/timer/TimeCircles.css" media="all" />

    <!-- OWL CAROUSEL CSS -->
    <link rel="stylesheet" href="assets/libs/owlcarousel/owl.carousel.min.css" media="all" />
    <link rel="stylesheet" href="assets/libs/owlcarousel/owl.theme.default.min.css" media="all" />

    <!-- GOOGLE FONT -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Oswald:400,700%7cRaleway:300,400,400i,500,600,700,900" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- MASTER  STYLESHEET  -->
    <link id="lgx-master-style" rel="stylesheet" href="assets/css/style-default.min.css" media="all" />

    <!-- MODERNIZER CSS  -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>

    <style>
        .lgx-registration-form-box {
            background: url(assets/img/registrationbox-bg.jpg) center center no-repeat;
            -webkit-background-size: cover;
            -o-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            padding: 4.2rem 3rem;
            text-align: center;
            z-index: 2;
        }

        .lgx-video2 {
            background: url(assets/img/milestone-bg.jpg) top center no-repeat !important;
            -webkit-background-size: cover;
            -o-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
        }

        .lgx-sponsors {
            background: url(assets/img/sponsor-bg.jpg) bottom center no-repeat;
            -webkit-background-size: cover;
            -o-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
        }

        .lgx-photo-gallery-black {
            background: url(assets/img/registration-bg.jpg) bottom center no-repeat fixed;
            -webkit-background-size: cover;
            -o-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
        }

        .lgx-video {
            background: url(assets/img/video-bg.jpg) top center no-repeat;
            -webkit-background-size: cover;
            -o-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
        }

        .lgx-footer {
            background: url(assets/img/footer-bg.jpg) bottom center no-repeat;
            -webkit-background-size: cover;
            -o-background-size: cover;
            -moz-background-size: cover;
            background-size: cover;
            color: #fff;
            text-align: center;
        }

        .lgx-video-area {
            padding: 0;
            display: block;
        }

        .lgx-inner {
            padding: 7rem 0;
        }

        .lgx-about-registration-box {
            position: relative;
            margin-top: -170px;
        }

        @media (max-width: 480px) {
            .slider-text-single figure img {
                height: auto;
                height: auto;
            }
        }

        @media (max-width: 767px) {
            .slider-text-single figure img {
                -ms-transform: scale(1.2);
                -moz-transform: scale(1.2);
                -webkit-transform: scale(1.2);
                -o-transform: scale(1.2);
                transform: scale(1.2);
                -webkit-transition: all .3 ease;
                transition: all .3s linear;
                height: auto;
            }
        }
    </style>


</head>

<body class="home">

    <!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience.</p>
<![endif]-->